[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II, SECTION 3, SUB-SECTION (i)]

Government of India
Ministry of Finance
(Department of Revenue)
Notification No. 09/2024- Central Tax (Rate)
New Delhi, the $8^{\text {th }}$ October, 2024
GSR......(E).- In exercise of the powers conferred by sub-section (3) of section 9 of the Central Goods and Services Tax Act, 2017 (12 of 2017), the Central Government, on the recommendations of the Council, hereby makes the following further amendments in the notification of the Government of India, in the Ministry of Finance (Department of Revenue), number 13/2017-Central Tax (Rate), dated the 28th June, 2017, published in the Gazette of India, Extraordinary, Part II, Section 3, Subsection (i), vide number G.S.R. 692(E), dated the 28th June, 2017, namely: -

1. In the said notification, in the Table, after serial number 5AA and the entries relating thereto, the following serial number and entries relating thereto in columns (2), (3) and (4) shall be inserted, namely: -

| (1) | (2) | (3) | (4) |
| :--: | :-- | :--: | :--: |
| "5AB | Service by way of renting of any <br> property other than residential <br> dwelling. | Any unregistered <br> person | Any registered <br> person." |

2. This notification shall come into force with effect from the $10^{\text {th }}$ day of October, 2024.
[F.No. 190354/149/2024-TO(TRU-II) - Part-I CBEC]
(Dilmil Singh Soach)
Under Secretary to the Government of India

Note: -The principal notification number 13/2017 -Central Tax (Rate), dated the 28th June, 2017 was published in the Gazette of India, Extraordinary, vide number G.S.R. 692 (E), dated the 28th June, 2017 and was last amended vide notification number 14/2023 -Central Tax (Rate), dated the $19^{\text {th }}$ October, 2023 published in the Gazette of India vide number G.S.R. 765(E), dated the $19^{\text {th }}$ October, 2023.

