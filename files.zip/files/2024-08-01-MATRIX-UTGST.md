# UTGST: Matrix of Legal Provisions 

## About Colour Coding Scheme Used in the Document

| Indicates currently valid notification |  | Currently valid Circulars/Orders |  | Chapter No and heading |
| :--: | :--: | :--: | :--: | :--: |
| Indicates Superceded/Rescinded <br> notification/Order/ Circulars |  | Indicates that no notification/circular/order <br> issued so far |  | Section No. and Its heading |

## CONTENT:

Chapter-I PRELIMINARY ..... 4
Section 1 ..... 4
Short title, extent and commencement. ..... 4
Section 2 ..... 5
Definitions ..... 5
Chapter-II ADMINISTRATION ..... 5
Section 3 ..... 5
Officers under this Act. ..... 5
Section 4 ..... 5
Authorisation of officers. ..... 5
Section 5 ..... 5
Power of Officers. ..... 5
Section 6 ..... 5
Authorisation of Officers of Central Tax as proper officers in Certain Circumstances ..... 5
Chapter-III LEVY AND COLLECTION OF TAX ..... 5
Section 7 ..... 5
Compiled by the GSTINDIAPATHWAY.ORG Team ..... 1

Levy and collection. ..... 5
Issued under section 7(4) of the UTGST Act, 2017 ..... 9
Section 8 ..... 10
Power to grant exemption from tax. ..... 10
Chapter-IV PAYMENT OF TAX ..... 15
Section 9 ..... 15
Payment of Tax ..... 15
Section 10 ..... 15
Transfer of Input Tax Credit ..... 15
Chapter-V INSPECTION, SEARCH, SEIZURE AND ARREST ..... 15
Section 11 ..... 15
Officers required to assist proper officers. ..... 15
Section-VI DEMANDS AND RECOVERY ..... 15
Section 12 ..... 15
Tax wrongfully collected and paid to Central Government or Union Territory Government ..... 15
Section 13 ..... 15
Recovery of Tax ..... 15
Chapter-VII ADVANCE RULING ..... 15
Section 14 ..... 15
Definitions ..... 15
Section 15 ..... 15
Constitution of Authority for Advance Ruling ..... 15
Compiled by the GSTINDIAPATHWAY.ORG Team ..... 15
Page 2 of 25

Section 16. ..... 15
Constitution of Appellate Authority for Advance Ruling. ..... 15
CHAPTER-VIII TRANSITIONAL PROVISIONS ..... 15
Section 17. ..... 16
Migrating of Existing tax payers ..... 16
Section 18. ..... 16
Transitional arrangements for input tax credit. ..... 16
Section 19. ..... 16
Transitional provisions relating to Job Work. ..... 16
Section 20. ..... 16
Miscellaneous transitional provisions ..... 16
CHAPTER-IX MISCELLANEOUS ..... 16
Section 21. ..... 16
Application of provisions of Central Goods and Services Tax Act. ..... 16
Section 22. ..... 21
Power to make rules. ..... 21
Section 23. ..... 22
General Power to make regulations. ..... 22
Section 24. ..... 22
Laying of rules, regulations and notifications. ..... 22
Section 25. ..... 22
Power to issue instructions or directions ..... 22

Section 25 ..... 22
Removal of difficulties. ..... 22
Other Notifications Issued ..... 23
Rule 46 of the CGST Rules, 2017 as amended ..... 23
List of Rescinded or Superceded LITGST Notification ..... 24
UTI means Union Territory Tax
Table

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Chapter-I PRELIMINARY |  |  |  |  |
| Section 1 | Short title, extent and commencement. | Notification No. 1/2017-UTT, dated 21.06.2017. | It brought into force the provisions of sections 1, $2,3,4,5,17,21$ and section 22 of the UT GST Act, 2017 with effect from 22.06.2017. |  |
|  |  | Notification No. 3/2017-UTT, dated 28.06.2017. | It brought into force the provisions of sections 6 to 16, 18 to 20 and 23 to 26 of the UT GST Act, 2017 with effect from 01.07.2017. |  |
|  |  | Notification No. 1/2019-UTT, dated 29.01.2019 | It brought into force the provisions of the Union Territory GST (Amendment) Act, 2018 (No. 33 of 2018) with effect from 01.02.2019. |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 2 | Definitions. |  |  |  |
| Chapter-II ADMINISTRATION |  |  |  |  |
| Section 3 | Officers under this Act. |  |  |  |
| Section 4 | Authorisation of officers. |  |  |  |
| Section 5 | Power of Officers |  |  |  |
| Section 6 | Authorisation of Officers of Central Tax as proper officers in Certain Circumstances |  |  |  |
| Chapter-III LEVY AND COLLECTION OF TAX |  |  |  |  |
| Section 7 | Levy and collection. | Notification No. 1/2017- UTT (Rate), dated 28.06.2017 (read with corrigendum dated 30.06.2017, 12.07.2017, and 27.07.2017) as amended vide notification No. 18/2017- UTT (Rate), dated 30.06.2017; No. 19/2017-UTT (Rate), dated 18.08.2017; No. 27/2017-UTT (Rate), dated 22.09.2017; No. 34/2017-UTT ( Rate), dated 13.10.2017; No. 41/2017-UTT ( Rate), dated 14.11.2017; No. 6/2018-UTT ( Rate), dated 25.01.2018; No. 8/2018-UTT (Rate), dated 25.01.2018; No. 18/2018-UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 24/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 08/2019-UTT (Rate), dated 29.03.2019 (w.e.f. | It notifies rate of UTT on intra-Union Territory taxable supply of goods. | Issued under Section 7(1) of the UTGST Act, 2017 |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 01.04.2019); No. 12/2019-UTT (Rate), dated 31.07.2019 (w.e.f. 01.08.2019); No. 14/2019-UTT (rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 27/2019-UTT (Rate), dated 30.12.2019 (w.e.f. 01.01.2020); No. 01/2020-UTT (Rate), dated 21.02.2020 (01.03.2020); No. 03/2020-UTT (Rate), dated 25.03.2020 (w.e.f. 01.04.2020); No. 01/2021UTT (Rate), dated 02.06.2021 (w.e.f. 02.06.2021); No. 8/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 13/2021-UTT (Rate), dated 27.10.2021 (w.e.f. 27.10.2021); No. 14/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022 but superseded before coming into force); No. 18/2021-UTT (Rate), dated 28.12.2021 (w.e.f. 01.01.2022); No. 21/2021-UTT (Rate), dated 31.12.2021 (w.e.f. 01.01.2022); No. 01/2022UTT(Rate), dated 31.03.2022 (w.e.f. 01.04.2022); No. 06/2022-UTT (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 12/2022-UTT(Rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 03/2023UTT(Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 09/2023-UTT(Rate), dated 26.07.2023 (w.e.f. 27.07.2023); No. 11/2023-UTT (Rate), dated 29.09.2023 (w.e.f. 01.10.2023); No. 17/2023UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023); No. 01/2024-UTT (Rate), dated 03.04.2024 (w.e.f.04.01.2024) read with corrigendum dated 05.01.2024; and No. 02/2024-UTT (Rate), dated 12.07.2024 (15.07.2024). |  |
|  |  | Notification No. 11/2017-UTT (Rate), dated 28.06.2017 as amended vide notification No. 20/2017-UTT (Rate), dated 22.08.2017; No. | It prescribes rate of UTT on intra-UT supplies of taxable services. | Issued under Section 7(1) of the UTGST Act, 2017 |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 24/2017-UTT (Rate), dated 21.09.2017; No. 31/2017-UTT (Rate), dated 13.10.2017; No.46/2017- UTT (Rate), dated 14.11.2017; No. 1/2018-UTT ( Rate), dated 25.01.2018; No. 13/2018UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 17/2018-UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 27/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 30/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 03/2019-UTT (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 10/2019-UTT (Rate), dated 10.05.2019; No. 20/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 26/2019-UTT (Rate), dated 22.11.2019; No. 02/2020-UTT (Rate), dated 26.03.2020 (w.e.f. 01.04.2020); No. 02/2021UTT (Rate), dated 02.06.2021 (w.e.f. 02.06.2021); No. 04/2021-UTT (Rate), dated 14.06.2021; No. 06/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 15/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022 but superceded before coming into force); No. 22/2021-UTT (Rate), dated 31.12.2021 (w.e.f. 01.01.2022); No. 03/2022UTT(Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 05/2023-UTT(Rate), dated 09.05.2023 (w.e.f. 09.05.2023); No. 06/2023-UTT(Rate), dated 26.07.2023 (w.e.f. 27.07.2023); and No. 12/2023UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023). |  |  |
|  |  | Notification No. 37/2017- UTT (Rate), dated 13.10.2017 | It notifies UTT on intra-state supplies of motor vehicles purchased by lesser prior to 1.7.2017 or by registered supplier of motor vehicle who purchased motor vehicle prior to 1.7.2017 and did |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | not avail ITC on such vehicle. |  |
|  |  | Notification No. 2/2019-UTT (Rate), dated 07.03.2019 (with effect from 1.4.2019) as amended vide notification No. 09/2019-UTT (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 18/2019-UTT (Rate), dated 30.09.2019 (01.10.2019); | It provides composition scheme for supplier of services with a tax rate of $6 \%$ having annual turnover in preceding year up to Rs. 50 lakhs. | Also issued under section 8(1) and section 21(v) of the UTGST Act, 2017. |
|  |  | Notification No. 4/2017- UTT (Rate), dated 28.06.2017 (w.e.f.1.7.2017) as amended vide notification No. 36/2017-UTT (Rate), dated 13.10.2017; No. 43/2017- UTT (Rate), dated 14.11.2017; No. 11/2018-UTT (Rate), dated 28.05.2018; No. 10/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 14/2022UTT(Rate), dated 30.12.2022 (w.e.f. 01.01.2023); and No. 19/2023-UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | It specifies certain intra-UT supplies of goods when supplied by specified supplier and received by specified recipient on which UTT is to be paid by such recipient of such intra-state supplies on reverse charge basis. | Issued under Section 7(3) of the UTGST Act, 2017. |
|  |  | Notification No. 13/2017-UTT (Rate), dated 28.06.2017 (effective from 1.7.2017) as amended vide notification No. 22/2017-UTT ( Rate), dated 22.08.2017; No. 33/2017-UTT ( Rate), dated 13.10.2017; No. 3/2018-UTT ( Rate), dated 25.01.2018; No. 15/2018-UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 29/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 05/2019-UTT (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 22/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 29/2019-UTT (Rate), dated 31.12.2019 (w.e.f. 01.01.2020); No. 05/2022-UTT(Rate), dated 13.07.2022 (w.e.f. | It notified categories of supply of services when supplied by specified supplier to specified recipient of supply, where whole of UTT is required to be paid by the recipient of supply under Section 7(3) of UTGST Act, 2017. | Issued under Section 7(3) of the UTGST Act, 2017. |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 18.07.2022); No. 02/2023-UTT(Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 08/2023UTT(Rate), dated 26.07.2023 (w.e.f. 27.07.2023); and No. 14/2023-UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023) |  |  |
|  |  | Notification No. 17/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) as amended vide notification No. 23/2017-UTT (Rate), dated 22.08.2017; No. 17/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022); and No. 16/2023UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | It notifies the categories of services for which UTT on intra-state supplies is to be paid by the electronic Commerce operator. | Issued under Section 7(5) of the UTGST Act, 2017. |
|  |  | Notification No. 39/2017-UTT (Rate), dated 18.10.2017 as amended vide notification No. 11/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021). | It notifies UTT rate of $2.5 \%$ on inter-state supplies of goods, namely, food preparation (chapter 19 or 21) put up in retail container and intended for free distribution to EWS under Central Government to Economically weaker section under Central Government/State Government Programme subject to fulfillment of prescribed condition. |  |
|  | Issued under section 7(4) of the UTGST Act, 2017 | Notification No. 07/2019-UTT (Rate), dated 29.03.2019 (w.e.f. 01.04.2019) as amended vide notification No. 24/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); | It specifies certain services relating to Real Estate Sector to be taxed under Reverse Charge Mechanism under section 7(4) of the UTGST Act, 2017. |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 8 | Power to grant exemption from tax. | Notification No. 2/2017-UTT (Rate), dated 28.06.2017 (read with corrigendum dated 12.07.2017 and 27.07.2017) as amended vide notification No. 28/2017-UTT (Rate), dated 22.09.2017; No. 35/2017-UTT (Rate), dated 13.10.2017; No. 42/2017-UTT (Rate), dated 14.11.2017; No. 7/2018-UTT (Rate), dated 25.01.2018; No. 19/2018-UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 25/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 15/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 9/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 19/2021-UTT (Rate), dated 28.12.2021 (w.e.f. 01.01.2022); No. 7/2022-UTT(Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 10/2022-UTT(Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 13/2022-UTT(Rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 04/2023-UTT(Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 18/2023-UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023); and No. 03/2024UTT (Rate), dated 12.07.2024 (w.e.f. 15.07.2024). | It provides full exemption from payment of UTT to certain intra-Union Territory supplies of goods. |  |
|  |  | Notification No. 3/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) as amended vide No. 16/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 08/2022-UTT(Rate), dated 13.07.2022 (w.e.f. 18.07.2022); | It provides conditional exemption from payment of UTT in excess of $2.5 \%$ for specified supplies of goods for the purpose of petroleum exploration and production. |  |
|  |  | Notification No. 7/2017- UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) | It provides full exemption from payment of UTT to intra-supplies of goods when supplied by |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | Central Supply Department to unit run canteens /Authorized customers or by unit run canteens to the authorized customers. |  |
|  |  | Notification No. 8/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 38/2017-UTT (Rate), dated 13.10.2017; and notification No. 10/2018-UTT (Rate), dated 23.03.2018; No. 12/2018-UTT (Rate), dated 29.06.2018 and last amended vide notification No. 22/2018-UTT (Rate), dated 06.08.2018. | It provides exemption to registered person from payment of Union Territory Tax on supplies received from supplier, who are not registered, from payment of tax under section 7(4) of UTGST Act, 2017. | Rescinded vide notification No. 01/2019-UTT (Rate), dated 29.01.2019 (w.e.f. 01.02.2019) |
|  |  | Notification No. 9/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) | It fully exempts intra-Union Territory supplies of goods or services or both received by Tax Deductor (under Section 51 of CGST Act, 2017) from any supplier, who is not registered, from payment of whole of UTT subject to fulfillment of conditions prescribed therein. |  |
|  |  | Notification No. 10/2017-UTT (Rate), dated 28.06.2017 (effective from 1.7.2018) | It wholly exempts intra-state supplies of second hand goods received by a registered person, dealing in buying or selling of second hand goods and pay central tax on outward supplies of such goods, from any suppliers, who is not registered from payment of Union Territory Tax leviable under section 7 (4) of the UT GST Act, 2017. |  |
|  |  | Notification No. 12/2017-UTT (Rate), dated 28.06.2017 as amended vide notification No. 21/2017-UTT (Rate), dated 22.08.2017; No. 25/2017-UTT (Rate), dated 21.09.2017; No. 30/2017-UTT (Rate), dated 29.09.2017; No. 32/2017-UTT (Rate), dated 13.10.2017;No. 47/2017UTT (Rate), dated 14.11.2017; No. 2/2018-UTT | It exempts specified Intra-Union Territory supply of services subject to fulfillment of conditions prescribed in the notification. |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (Rate), 25.01.2018; No. 14/2018-UTT (Rate), dated 26.07.2018 (w.e.f. 27.07.2018); No. 23/2018-UTT (Rate), dated 20.09.2018; No. 28/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019); No. 04/2019UTT (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 13/2019-UTT (Rate), dated 31.07.2019 (w.e.f. 01.08.2019); No. 21/2019-UTT(Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 28/2019-UTT (Rate), dated 31.12.2019 (w.e.f. 01.01.2020); No. 04/2020-UTT (Rate), dated 30.09.2020 (w.e.f. 01.10.2020); No. 05/2020-UTT (Rate), dated 16.10.2020; No. 07/2021-UTT (Rate), dated 30.09.2021 (w.e.f 01.10.2021); No. 16/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022); No. 04/2022-UTT (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 15/2022-UTT (Rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 01/2023UTT(Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 07/2023-UTT(Rate), dated 26.07.2023 (w.e.f. 27.07.2023); No. 13/2023-UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023); and Notification No. 04/2024-UTT (Rate), dated 12.07.2024 (w.e.f. 15.07.2024). |  |  |
|  |  | Notification No. 26/2017-UTT (Rate), dated 21.09.2017. | It wholly exempts intra-Union Territory supply of heavy water and nuclear fuels (Chapter 28) by Department of Atomic Energy to the Nuclear Power Corporation of India Ltd. from payment of Union Territory Tax. |  |
|  |  | Notification No. 45/2017-UTT (Rate), dated 14.11.2017 as amended vide notification No. 9/2018- UTT (Rate), dated 25.01.2017. | It prescribes concessional rate of Union Territory tax of $2.5 \%$ on scientific and technical equipment, apparatus, equipment (including computers) when supplied to public funded Research | Rescinded vide notification No. 11/2022-UTT(Rate), dated 13.07.2022 |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | institution. | (w.e.f. 18.07.2022). |
|  |  | Notification No. 40/2017-UTT (Rate), dated 23.10.2017. | It prescribes Union Territory Tax rate of $0.05 \%$ on Intra-UT supplies of taxable goods by a registered supplier to a registered recipient for export subject to specified conditions. |  |
|  |  | Notification No. 5/2018-UTT (Rate), dated 25.01.2018. | It exempts intra-Union Territory supply of services by way of grant of license or lease to explore or mine petroleum crude or natural gas or both, from so much of the Union Territory Tax as is leviable on the consideration paid to Central Government in the form of Central Government share of profit petroleum as defined in the contract. |  |
|  |  | Notification No. 21/2018-UTT (Rate), dated 26.07.2018 as amended vide notification No. 20/2021-UTT (Rate), dated 28.12.2021 (w.e.f. 01.01.2022). | It partially exempts the intra-state supplies of specified handicraft goods from payment of UTT. |  |
|  |  | Notification No. 26/2018-UTT (Rate), dated 31.12.2018 (w.e.f. 01.01.2019) (read with corrigendum dated 31.01.2019) as amended vide notification No. 17/2019-UTT (Rate), dated 30.09.2019 (01.10.2019); and No. 10/2023UTT(Rate), dated 26.07.2023 (w.e.f. 27.07.2023) read with corrigendum dated 31.07.2023. | It exempts the intra-state supply of gold falling in heading 7108 when supplied by Nominated Agency under the Scheme for "Export against Supply by nominated agency" from whole of Union Territory Tax (UTT) subject to fulfillment of conditions specified in the notification. |  |
|  |  | Notification No. 19/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019). | It exempts all the goods supplied to the Food and Agricultural Organisation of the United Nations (FAO) for execution of specified projects subject to fulfillment of condition specified therein. |  |
|  |  | Notification No. 05/2021-UTT (Rate), dated | It exempts (in excess of rate specified) to certain |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 14.06.2021 read with corrigendum dated 15.06.2021. | specified goods relating to COVID-19 for limited period up to 30.09.2021. |  |
|  |  | Notification No. 12/2021-UTT (Rate), dated 30.09.2021 (w.e.f. 01.10.2021). | It exempts (in excess of rate specified) to certain specified goods relating to COVID-19 for limited period up to 31.12.2021 (inclusive). |  |
|  |  | Notification No. 02/2022-UTT (Rate), dated 31.03.2022(w.e.f. 01.04.2022); |  |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Chapter-IV PAYMENT OF TAX |  |  |  |  |
| Section 9 | Payment of Tax |  |  |  |
| Section 10 | Transfer of Input Tax Credit |  |  |  |
| Chapter-V INSPECTION, SEARCH, SEIZURE AND ARREST |  |  |  |  |
| Section 11 | Officers required to assist proper officers |  |  |  |
| Section-VI DEMANDS AND RECOVERY |  |  |  |  |
| Section 12 | Tax wrongfully collected and paid to Central Government or Union Territory Government |  |  |  |
| Section 13 | Recovery of Tax |  |  |  |
| Chapter-VII ADVANCE RULING |  |  |  |  |
| Section 14 | Definitions |  |  |  |
| Section 15 | Constitution of Authority for Advance Ruling | Notification No. 14/2018-UTT, dated 08.10.2018. | It notified the constitution of the Authority for Advance Ruling in the Union Territories. |  |
| Section 16 | Constitution of Appellate Authority for Advance Ruling | Notification No. 15/2018-UTT, dated 08.10.2018. | It notified the constitution of the Appellate Authority for Advance Ruling in the Union Territories. |  |
| CHAPTER-VIII TRANSITIONAL PROVISIONS |  |  |  |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 17 | Migrating of Existing tax payers |  |  |  |
| Section 18 | Transitional arrangements for input tax credit |  |  |  |
| Section 19 | Transitional provisions relating to Job Work. |  |  |  |
| Section 20 | Miscellaneous transitional provisions |  |  |  |
| CHAPTER-IX MISCELLANEOUS |  |  |  |  |
| Section 21 | Application of provisions of Central Goods and Services Tax Act. |  |  |  |
| (i) Scope of supply |  | Notification No. 14/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) as amended vide notification No. 16/2018-UTT (Rate), dated 26.07.2018 | It notifies supplies which shall be treated neither as a supply of goods nor a supply of services under UTGST Act, 2017. | Also relates to section 7(2). |
|  |  | Notification No. 25/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019). | IT notifies Service by way of grant of liquor licence, against consideration undertaken by the state government to be treated as treated neither as a supply of goods nor a supply of service. | Also relates to section 7(2). |
| (ii) Composition levy |  | The UT GST (Removal of Difficulties) Order, 2019, No. 01/2019-UTT, dated 01.02.2019. | It was issued to remove the difficulties being faced in implementing the provisions of Composition Scheme. | It superceded the UT GST (Removal of Difficulties) Order, 2017, No. 1/2017-UTT, dated 13.10.2017. |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 2/2017-UTT, dated 27.06.2017 (w.e.f. 01.07.2017) as amended vide notification No. 16/2017-UTT, dated 13.10.2017; and No. 01/2018-Union Territory Tax, dated 01.01.2018; No. 02/2022-UTT, dated 31.03.2022 (w.e.f. 01.04.2022); and No. 04/2022-UTT, dated 13.07.2022 (w.e.f. 18.07.2022); | It notified turnover limit for composition levy for UTGST. |  |
| (iii) Composite supply and mixed supply |  |  |  |  |
| (iv) time and value of supply |  |  |  |  |
| (v) Input tax credit |  | The Union Territory GST (Removal of Difficulties) Order No. 03/2019-UTT, dated 29.03.2019 ( w.e.f. 01.04.2019) | It removes difficulties in case of supply of Services covered by clause (b) of paragraph 5 of Schedule II of the CGST Act, 2017. | Issued in context of Section 17(2) of the CGST Act, 2017. |
| (vi) registration |  | Notification No. 04/2018-UTT (Rate), dated 25.01.2018 as amended vide notification No. 23/2019-UTT (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); | It notifies certain classes of registered person who shall be liable to pay UTT in respect of certain construction services. |  |
|  |  | Notification No. 4/2017-UTT, dated 30.06.2017 (effective from 22.06.2017). | It notified www.gst.gov.in as the common goods and services tax electronic portal for facilitation registration, payment of tax, furnishing of returns, computation and settlement of Integrated tax and electronic way bill. |  |
|  |  | Notification No. 02/2019-UTT, dated 07.03.2019 as amended vide notification No. 01/2022-UTT, dated 31.03.2022 (w.e.f. 01.04.2022); and No. 03/2022-UTT, dated 13.07.2022 (w.e.f. 18.07.2022); | It exempts from registration for any person engaged in exclusive supply of goods and whose aggregate turnover in the financial year does not exceed Rs. 40 lakhs. |  |
| (vii) tax invoice, credit and debit notes. |  | The Union Territory GST (Removal of Difficulties) Order No. 02/2019-UTT, dated | It removes difficulties in implementation of notification No. 2/2019-UTT (Rate), dated | Issued in the context of Section $31(3) \odot$ of the |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 08.03.2019. | 07.03.2019 (effective from 01.04.2019). | CGST Act, 2019. |
| (viii) accounts and records |  |  |  |  |
| (ix) returns |  |  |  |  |
| (x) Payment of tax. |  | Notification No. 10/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) as amended vide notification No. 01/2020-UTT, dated 08.04.2020 (w.e.f. 20.03.2020); No. 02/2020-UTT, dated 24.06.2020; No. 01/2021-UTT, dated 01.05.2021 (w.e.f. 18.04.2021); and No. 02/2021-UTT, dated 01.06.2021 (w.e.f. 18.05.2021) | It fixes the rate of interest per annum for the purposes of section 21 of UTGST Act, 2017 read with section 50(1), 50(3), 54(12), 56 and proviso to section 56 of CGST Act, 2017. |  |
| (xi) tax deduction at source |  |  |  |  |
| (xii) collection of tax at Source |  | Notification No. 12/2018-UTT, dated 28.09.2018 ( w.e.f. 01.10.2018) as amended vide notification No. 01/2024-UTT, dated 10.07.2024 (w.e.f. 10.07.2024). | It notified the amount of $0.25 \%$ to be collected by ECO, not being an agent, of intra-union territory (without legislature) supplies made through it by other suppliers where consideration for such supplies is collected by ECO. |  |
|  |  | Notification No. 13/2018-UTT, dated 28.09.2018 ( w.e.f. 01.10.2018) | It notified the amount to be collected by ECO, not being an agent, of inter-union territory (without legislature) supplies made through it by other suppliers where consideration for such supplies is collected by ECO. |  |
| (xiii) assessment |  |  |  |  |
| (xiv) refunds |  |  |  |  |
|  |  | Notification No. 10/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) as amended vide | It fixes the rate of interest per annum for the purposes of section 21 of UTGST Act, 2017 read |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | notification No. 01/2020-UTT, dated 08.04.2020 (w.e.f. 20.03.2020); and No. 02/2020-UTT, dated 24.06.2020; No. 01/2021-UTT, dated 01.05.2021 (w.e.f. 18.04.2021); and No. 02/2021-UTT, dated 01.06.2021 (w.e.f. 18.05.2021). | with section 50(1), 50(3), 54(12), 56 and proviso to section 56 of CGST Act, 2017. |  |
|  |  | Notification No. 5/2017-UTT (Rate), dated 28.06.2017 (effective from 1.7.2017) as amended vide notification No. 29/2017-UTT (Rate), dated 22.09.2017; No. 44/2017-UTT (Rate), dated 14.11.2017; No. 20/2018-UTT (Rate), dated 26.07.2018; No. 09/2022-UTT(Rate), dated 13.07.2022 (w.e.f.18.07.2022); and No. 20/2023UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023) | It notifies certain goods failing into specified tariff heading in respect of which refund of un-utilized input tax credit is not allowed where the credit has accumulated on account of inverted duty structure. |  |
|  |  | Notification No. 6/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) | It notifies the Canteen Stores Department, as a person entitled to claim a refund of $50 \%$ of the applicable UTT paid by it on the inward supplies of goods received by it for the purposes of subsequent supply of such goods to the Unit Run Canteens of the CSD or to the authorized customers of the CSD |  |
|  |  | Notification No. 15/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) as amended vide No. 15/2023-UTT(Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | It notifies that refund of un-utilised input tax credit is not allowed in case of supplies of services of construction of a complex, building or a part there of, intended for sale to a buyer in certain condition specified therein. |  |
|  |  | Notification No. 16/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) | It notifies specialized agencies entitled to claim a refund of taxes paid on the notified supplies of goods or services or both received by them under UTGST Act, 2017. |  |
|  |  | Notification No. 11/2019-UTT (Rate), dated 29.06.2019 (w.e.f. 01.07.2019). | It specifies retail outlets established in the departure area of an international airport, beyond |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | the immigration counters, making tax free supply of goods to an outgoing international tourist, as class of persons, entitled to claim refund of applicable UTT paid on inward supply of such goods. |  |
| (xv) audit |  |  |  |  |
| (xvi) Inspection, search, seizure and arrest. |  |  |  |  |
| (xvii) Demands and recovery |  |  |  |  |
| (xvviii) liability to pay in certain cases. |  |  |  |  |
| (xix) advance ruling |  |  |  |  |
| (xx) appeals and revision |  |  |  |  |
| (xxi) presumption as to documents |  |  |  |  |
| (xxii) offences and penalties |  |  |  |  |
| (xxiii) job work |  |  |  |  |
| (xiv) electronic commerce |  |  |  |  |
| (xxv) settlement of funds |  |  |  |  |
| (xxvi) transitional provisions |  |  |  |  |
| (xxvii) miscellaneous provisions including the provisions relating to the imposition of interest and penalty |  | Notification No. 06/2019-UTT <br> 29.03.2019 (w.e.f. 01.04.2019) as amended vide | It notifies certain class of persons relating to Real Estate Sector by exercising powers under Section 149 of the CGST Act, 2017. |  |
|  |  | notification No. 03/2021-UTT (Rate), dated 02.06.2021 (w.e.f. 02.06.2021). |  |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 22 | Power to make rules. | Notification No. 17/2017-UTT, dated 24.10.2017 (effective from 22.06.2017) | It notified that subject to provision of UTGST Act, 2017 and rules made thereunder, the notifications issued under CGST Act, 2017 relating to subject mentioned in section 21 of the UTGST Act, 2017 are to be automatically extended to the UTGST Act, 2017. |  |
|  |  | Notification No. 5/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) | It notified the Union Territory Goods and Services Tax (Andaman and Nicobar) Rules, 2017. |  |
|  |  | Notification No. 06/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) | It notified the Union Territory Goods and Services Tax (Chandigarh) Rules, 2017. |  |
|  |  | Notification No. 07/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) | It notified the Union Territory Goods and Services Tax (Dadra and Nagar Haveli) Rules, 2017. |  |
|  |  | Notification No. 08/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) | It notified the Union Territory Goods and Services Tax (Daman and Diu) Rules, 2017. |  |
|  |  | Notification No. 09/2017-UTT, dated 30.06.2017 (effective from 01.07.2017) | It notified the Union Territory Goods and Services Tax (Lakshadweep) Rules, 2017. |  |

| Section No. | Chapter /Section /heading | Notification Issued | Subject of the notification in brief | Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 23 | General Power to make regulations. |  |  |  |
| Section 24 | Laying of rules, regulations and notifications. |  |  |  |
| Section 25 | Power to issue instructions or directions |  |  |  |
| Section 25 | Removal of difficulties. | The UT GST (Removal of Difficulties) Order, 2019, No. 1/2019-UTT, dated 01.02.1019. | It was issued to remove the difficulties being faced in implementing provisions of Composition Scheme. | It superceded the UT GST (Removal of Difficulties) Order, 2017, No. 1/2017-UTT, dated 13.10.2017. |
|  |  | The Union Territory GST (Removal of Difficulties) Order No. 02/2019-UTT, dated 08.03.2019. | It removes difficulties in implementation of notification No. 2/2019-UTT (Rate), dated 07.03.2019 (w.e.f. 01.04.2019). | Issued in the context of Section 31 (3) © of the CGST Act, 2019. |
|  |  | The Union Territory GST (Removal of Difficulties) Order No. 03/2019-UTT, dated 29.03.2019 (w.e.f. 01.04.2019) | It removes difficulties in case of supply of Services covered by clause (b) of paragraph 5 of Schedule II of the CGST Act, 2017. | Issued in context of Section 17(2) of the CGST Act, 2017. |
|  |  | The UT GST (Removal of Difficulties) Order, 2017, No. 1/2017-UTT, dated 13.10.2017. | It was issued to remove the difficulties being faced in implementing provisions of composition scheme. | Superceded vide the UT GST <br> (Removal of <br> Difficulties) Order <br> 2019, No. 1/2019- <br> UTT, dated <br> 01.02.2019. |

# Other Notifications Issued 

|  | Rule 46 of the CGST Rules, 2017 as amended | Notification No. 11/2017-UTT, dated 30.06.2017 | It notified number of digits of harmonized System of Nomenclature Code for Andaman and Nicobar Islands. |  |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 12/2017-UTT, dated 30.06.2017 | It notified number of digits of harmonized System of Nomenclature Code for Chandigarh. |  |
|  |  | Notification No. 13/2017-UTT, dated 30.06.2017 | It notified number of digits of harmonized System of Nomenclature Code for Dadra and Nagar Haveli. |  |
|  |  | Notification No. 14/2017-UTT, dated 30.06.2017 | It notified number of digits of harmonized System of Nomenclature Code for Daman and Diu. |  |
|  |  | Notification No. 15/2017-UTT, dated 30.06.2017 | It notified number of digits of harmonized System of Nomenclature Code for Lakshadweep. |  |

# List of Rescinded or Superceded UTGST Notification 

| Notification No and date (Rescinded or superceded ) | Subject |  | Rescinding /Superceding notification No. and date |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: |
| Notification No. 2/2018-UTT, dated 31.03.2018 (effective from 1.4.2018) | It notified that no e-way bill to be generated in case of movement of goods within Union territory of Andaman and Nicobar. |  | Rescinded vide | notification 21.05.2018. | No. |
| Notification No. 3/2018-UTT, dated 31.03.2018 (effective from 1.4.2018) | It notified that no e-way bill to be generated in case of movement of goods within Union territory of Chandigarh. |  | Rescinded vide | notification 18.05.2018 | No. |
| Notification No. 4/2018-UTT, dated 31.03.2018 (effective from 1.4.2018) | It notified that no e-way bill to be generated in case of movement of goods within Union territory of Dadra and Nagar Haveli. |  | Rescinded vide | notification 18.05.2018 | No. |
| Notification No. 5/2018-UTT, dated 31.03.2018 (effective from 1.4.2018) | It notified that no e-way bill to be generated in case of movement of goods within Union territory of Daman and Diu. |  | Rescinded vide | notification 18.05.2018 | No. |
| Notification No. 6/2018-UTT, dated 31.03.2018 (effective from 1.4.2018) | It notified that no e-way bill to be generated in case of movement of goods within Union territory of Lakshadweep. |  | Rescinded vide | Notification 11/2018-UTT, dated 21.05.2018 | No. |
| Notification No. 8/2017-UTT (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 38/2017-UTT (Rate), dated 13.10.2017; and notification No. 10/2018-UTT (Rate), dated 23.03.2018; No. 12/2018-UTT (Rate), dated 29.06.2018 and last amended vide notification No. 22/2018-UTT (Rate), dated 06.08.2018. | It provided exemption to registered person from payment of Union Territory Tax on supplies received from supplier, who are not registered, from payment of tax under section 7(4) of UTGST Act, 2017. |  | Rescinded vide | notification 29.01.2019 (w.e.f. 01.02.2019) | No. <br> No. <br> 29.01.2019 |
| Notification No. 45/2017-UTT (Rate), dated 14.11.2017 as amended vide notification No. 9/2018- UTT (Rate), dated 25.01.2017. | It prescribes concessional rate of Union Territory tax of $2.5 \%$ on scientific and technical equipment, apparatus, equipment (including computers) when supplied to public funded Research institution. |  | Rescinded vide | notification 11/2022-UTT(Rate), dated 13.07.2022 (w.e.f. 18.07.2022). | No. <br> No. <br> 13.07.2022 |
| UTT (Removal of Difficulties) Order, 2017, No. 1/2017-UTT, dated 13.10.2017 | It was issued to remove the difficulties being faced in implementing provisions of composition scheme. |  | Superceded vide the UT GST (Removal of Difficulties) Order 2019, No. 1/2019UTT, dated 01.02.2019. |  |  |

| Notification No and date (Rescinded or superceded ) | Subject | Rescinding /Superceding notification No. and date |
| :--: | :--: | :--: |
| Notification No. 14/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022). | It sought to amend notification No. 01/2017-UTT (Rate), dated 28.06.2017 which specify rate of tax on intra Union Territory supply of goods with effect from 01.01.2022. | Superceded vide notification No. 21/2021-UTT (Rate), dated 31.12.2021 (w.e.f. 01.01.2022). |
| Notification No. 15/2021-UTT (Rate), dated 18.11.2021 (w.e.f. 01.01.2022). | It sought to amend notification No. 11/2017-UTT (Rate), dated 28.06.2017 which specify rate of tax on intra-Union Territory supply of services with effect from 01.01.2022. | Superceded vide notification No. 22/2021-UTT (Rate), dated 31.12.2021 (w.e.f. 01.01.2022). |

# Caution Note: 

- Though all precautions have been taken to make this document error free, still some errors might have crept into this document. Therefore, users of this document are requested to exercise due caution before using it for any legal purpose.
- This document has been prepared using the information available on CBIC website.
- Use of this document is restricted for non-commercial purposes only.

