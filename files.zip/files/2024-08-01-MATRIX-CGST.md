# COST: Matrix of Legal Provisions 

## About Colour Coding Scheme Used in the Document

| Indicates currently valid notification |  | Currently valid Circulars/Orders |  | Chapter No and heading |
| :-- | :-- | :-- | :-- | :-- |
| Indicates Superceded/Rescinded notification/Order/ Circulars |  | Indicates that no notification/circular/order /instruction issued so far |  | Section No. and Its heading |

## INDEX

The CGST Act, 2017 ..... 12
CHAPTER I - PRELIMINARY ..... 12
Section 1 ..... 12
Section 2 ..... 14
2(01) ..... 15
2(01) ..... 15
CHAPTER II - ADMINISTRATION ..... 15
Section 3 ..... 15
Section 4 ..... 16
Section 5 ..... 16
Section 6 ..... 17
Section 7 ..... 18
Section 8 ..... 19
Section 9 ..... 19
Section 9(1) ..... 20
Compiled by the GSTINDIAPATHWAY,ORG Team
Page 1 of 127

Section 9(6) ..... 24
Section 9(4) ..... 25
Section 9(5) ..... 25
Section 10 ..... 29
Section 11 ..... 30
Sub-section (1) ..... 30
CHAPTER IV - TIME AND VALUE OF SUPPLY ..... 37
Section 12 ..... 37
Section 13 ..... 37
Section 14 ..... 37
Section 15 ..... 38
CHAPTER V - INPUT TAX CREDIT ..... 39
Section 16 ..... 39
Section 17 ..... 40
Section 18 ..... 40
Section 19 ..... 40
Section 20 ..... 40
Section 21 ..... 40
CHAPTER VI - REGISTRATION ..... 41
Section 22 ..... 41
Section 23 ..... 41
Section 24 ..... 42
Compiled by the GSTINDIAPATHWAY.ORG Team
Page 2 of 127

|  COST: Matrix of Legal Provisions | (Updated on 01.08.2024)  |
| --- | --- |
|  Section 25 | 42  |
|  Section 26 | 43  |
|  Section 27 | 43  |
|  Section 28 | 43  |
|  Section 29 | 43  |
|  Section 30 | 44  |
|  CHAPTER VII - TAX INVOICE, CREDIT AND DEBIT NOTES | 44  |
|  Section 31 | 44  |
|  Section 31A | 46  |
|  Section 32 | 46  |
|  Section 33 | 47  |
|  Section 34 | 47  |
|  CHAPTER VIII - ACCOUNTS AND RECORDS | 47  |
|  Section 35 | 47  |
|  Section 36 | 47  |
|  CHAPTER IX - RETURNS | 47  |
|  Section 37 | 47  |
|  Section 38 [= substitutedvide finance Act, 2022] | 51  |
|  Section 39 | 52  |
|  Section 40 | 57  |
|  Section 41 [= substitutedvide finance Act, 2022] | 57  |
|  Section 42 | 57  |
|  Compiled by the GSTINDIAPATHWAY,ORG Team | Page 3 of 127  |
|   | ASME 3  |

Section 43 ..... 57
Section 43A [Effective Date is yet to be notified] ..... 57
Section 44 ..... 58
Section 45 ..... 60
Section 46 ..... 60
Section 47 ..... 60
Section 48 ..... 60
Section 49 ..... 60
Section 49A ..... 60
Section 49B ..... 60
Section 50 ..... 60
Section 51 ..... 61
Section 52 ..... 62
Section 53 ..... 62
Section 53A ..... 62
CHAPTER XI - REFUNDS ..... 62
Section 54 ..... 62
Section 55 ..... 66
Section 56 ..... 68
Section 57 ..... 68
Section 58 ..... 68
CHAPTER XII - ASSESSMENT ..... 68

|  66 | Section 59 | 68  |
| --- | --- | --- |
|  Section 60 |   | 68  |
|  Section 61 |   | 68  |
|  Section 62 |   | 68  |
|  Section 63 |   | 68  |
|  Section 64 |   | 68  |
|  CHAPTER XIII - AUDIT |   | 68  |
|  Section 65 |   | 68  |
|  Section 66 |   | 68  |
|  CHAPTER XIV - INSPECTION, SEARCH, SEIZURE AND ARREST |   | 69  |
|  Section 67 |   | 69  |
|  Section 68 |   | 69  |
|  Section 69 |   | 70  |
|  Section 70 |   | 70  |
|  Section 71 |   | 70  |
|  Section 72 |   | 70  |
|  CHAPTER XV - DEMANDS AND RECOVERY |   | 70  |
|  Section 73 |   | 70  |
|  Section 74 |   | 70  |
|  Section 75 |   | 71  |
|  Section 76 |   | 71  |
|  Section 77 |   | 71  |
|  Compiled by the GSTINDIAPATHWAY,ORG Team |   | Page 5 of 127  |
|   |   | ASMES  |

Section 78 ..... 71
Section 79 ..... 71
Section 80 ..... 72
Section 81 ..... 72
Section 82 ..... 72
Section 83 ..... 72
Section 84 ..... 72
CHAPTER XVI - LIABILITY TO PAY IN CERTAIN CASES ..... 72
Section 85 ..... 72
Section 86 ..... 72
Section 87 ..... 72
Section 88 ..... 72
Section 89 ..... 72
Section 90 ..... 72
Section 91 ..... 73
Section 92 ..... 73
Section 93 ..... 73
Section 94 ..... 73
CHAPTER XVII- ADVANCE RULING ..... 73
Section 95 ..... 73
Section 96 ..... 73
Section 97 ..... 73

Section 98 ..... 73
Section 99 ..... 73
Section 100 ..... 73
Section 101 ..... 73
Section 102 ..... 73
Section 103 ..... 74
Section 104 ..... 74
Section 105 ..... 74
Section 106 ..... 74
CHAPTER XVIII - APPEALS AND REVISION ..... 74
Section 107 ..... 74
Section 108 ..... 74
Section 109 ..... 74
Section 110 ..... 75
Section 111 ..... 75
Section 112 ..... 75
Section 113 ..... 76
Section 114 ..... 76
Section 115 ..... 76
Compiled by the GSTINDIAPATHWAY.ORG Team
Page 7 of 127

Section 116 ..... 76
Section 117 ..... 76
Section 118 ..... 76
Section 119 ..... 76
Section 120 ..... 77
Section 121 ..... 77
CHAPTER XIX - OFFENCES AND PENALTIES ..... 77
Section 122 ..... 77
Section 123 ..... 77
Section 124 ..... 77
Section 125 ..... 77
Section 126 ..... 77
Section 127 ..... 77
Section 128 ..... 77
Section 129 ..... 82
Section 130 ..... 82
Section 131 ..... 82
Section 132 ..... 82
Section 133 ..... 83
Section 134 ..... 83
Section 135 ..... 83
Section 136 ..... 83
Section 138 ..... 83

Section 137. ..... 83
Section 138. ..... 83
CHAPTER XX- TRANSITIONAL PROVISIONS. ..... 83
Section 139. ..... 83
Section 140. ..... 83
Section 141. ..... 84
Section 142. ..... 84
CHAPTER XXI - MISCELLANEOUS ..... 84
Section 143. ..... 84
Section 144. ..... 84
Section 145. ..... 84
Section 146. ..... 84
Section 147. ..... 85
Section 148. ..... 86
Section 149. ..... 95
Section 150. ..... 95
Section 151. ..... 95
Section 152. ..... 95
Section 153. ..... 95
Section 154. ..... 95
Section 155. ..... 95
Section 156. ..... 95
Compiled by the GSTINDIAPATHWAY.ORG Team
Page 9 of 127

Section 157. ..... 95
Section 158. ..... 95
Section 158A (inserted vide Finance Act, 2023 with effect from 1.10.2023) ..... 95
Section 159. ..... 95
Section 160. ..... 96
Section 161. ..... 96
Section 162. ..... 96
Section 163. ..... 96
Section 164. ..... 96
Section 165. ..... 99
Section 166. ..... 99
Section 167. ..... 99
Section 168. ..... 99
Section 169. ..... 111
Section 170. ..... 113
Section 171. ..... 113
Section 172. ..... 113
Section 173. ..... 114
Section 174. ..... 115
Section 175. ..... 115
SCHEDULE I - Activities to be treated as supply even if made without consideration. ..... 115
SCHEDULE II - Activities to be treated as supply of goods or supply of services ..... 115

SCHEDULE III - Activities or transactions which shall be treated neither as a supply or goods nor as supply of services. ..... 115
Central Tax Rate Notifications (Superceded or Rescinded) ..... 116
Central Tax Non-Rate Notifications (Superceded or Rescinded) ..... 117
The CGST (Removal of Difficulties) Order Issued under Section 172 of the CGST Act, 2017 (Superceded/Rescinded) ..... 125
Central Tax Circulars (Rescinded /Superceded) ..... 125
Order Issued under Section 168 of the CGST Act, 2017 (Superceded/ Rescinded) ..... 126

# Table 

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| CHAPTER I - PRELIMINARY |  |  |  |  |
| Section 1 | Short title, extent and commencement. | Notification No. 1/2017-Central Tax, dated 19.6.2017. | It brought into effect the sections 1 to $5,10,22$ to 30,139 , 146 and 164 of the CGST Act, 2017 with effect from 22.06.2017. |  |
|  |  | Notification No. 9/2017-Central Tax, dated 28.6.2017. | It brought into effect sections 6 to 9,11 to 21,31 to 41,42 (except proviso to 42(9)), 43 (except proviso to 43(9)), 44 to 50,53 to 138,140 to 145,147 to 163,165 to 174 with effect from 1.7.2017. |  |
|  |  | Notification No. 33/2017-Central Tax, dated 15.9.2017 | It brought into effect provision of the Section 51 (1) of the CGST Act, 2017 with regard to persons specified in clause (a), (b) and (d) with effect from 18.09.2017. | Superceded notification No. 50/2018 Central Tax, dated |
|  |  | Notification No. 50/2018-Central Tax, dated 13.09.2018 as amended vide notification No. 57/2018-Central Tax, dated 23.10.2018; No. 61/2018-Central Tax, dated 05.11.2018; and last amended vide notification No. 73/2018-Central Tax, dated 31.12.2018. | It brought into force the provisions of Section51 (1) (a), (b), (c) and (d) of the CGST Act, 2017 with effect from 1.10.2018. It also specified persons under clause (d) of sub-section (1) of Section 51 of the CGST Act, 2017. |  |
|  |  | Notification No. 51/2018-Central Tax, dated 13.09.2018 | It brought into force the provisions of Section 52 of the CGST Act, 2017 with effect from 01.10.2018. |  |
|  | Amendment effected vide the CGST (Amendment) Act, 2018 (No. 31 of 2018) | Notification No. 02/2019-Central Tax, dated 29.01.2019. | It brought into force the provisions of the CGST (Amendment) Act, 2018 ( 31 of 2018) except clause (b) of section 8, section 17, section 18, clause (a) of section 20, sub-clause (i) of clause (b) and sub-clause (i) of clause (c) of section 28 with effect from 01.02.2019. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  | Amendment effected vide Finance (No.2) Act, 2019 (No. 23 of 2019). | Notification No. 39/2019-Central Tax, dated 31.08.2019 | It brought into force the section 103 of the Finance (No. 2) Act, 2019 (No. 23 of 2019) with effect from 01.09.2019. |  |
|  | Amendment effected vide Finance (No.2) Act, 2019 (No. 23 of 2019) | Notification No. 01/2020-Central Tax, dated 01.01.2020 | It brought into force the provisions of sections 92 to 112, except section 92, section 97, section 100 and sections 103 to 110 of the Finance (No. 2) Act, 2019 (23 of 2019) with effect from 01.01.2020. |  |
|  | Amendment effected vide section 128 of the Finance Act, 2020 (12 of 2020) | Notification No. 43/2020-Central Tax, dated 16.05.2020 | It brought into force the provision of section 128 of the Finance Act, 2020 (12 of 2020) with effect from 18.05.2020. |  |
|  | Amendment effected vide Section 118, 125, 129 and 130 of the Finance Act, 2020 (12 of 2020) | Notification No. 49/2020-Central Tax, dated 24.06.2020 | It brought into force the provisions of section 118, 125, 129 and 130 of the Finance Act, 2020 (12 of 2020) with effect from 30.06.2020. |  |
|  | Amendment effected vide Section 100 of the Finance (No. 2) Act, 2019 (23 of 2019). | Notification No. 63/2020-Central Tax, dated 25.08.2020 | It brought into force the provisions of section 100 of the Finance (No. 2) Act, 2019 (23 of 2019) with effect from 01.09.2020. |  |
|  | Amendment effected vide Section 97 of the Finance (No. 2) Act, 2019. | Notification No. 81/2020-Central Tax, dated 10.11.2020. | It brought into force the amendment effected in subsection (1), (2), and (7) of Section 39 vide Finance (No.2) Act, 2019 with effect from 10.11.2020. |  |
|  | Amendment effected vide Section 119, 120, 121, 122, 123, 124, 126, 127 and 131 of the Finance Act, 2020 (12 of 2020). | Notification No. 92/2020-Central Tax, dated 22.12.2020. | It brought into force the amendment effected vide section 119, 120, 121, 122, 123, 124, 126, 127 and 131 of the Finance Act, 2020 (12 of 2020) with effect from 01.01.2021. |  |
|  | Amendment effected vide section 112 of the Finance Act, 2021 (13 of 2021). | Notification No. 16/2021-Central Tax, dated 01.06.2021. | It brought into force the amendment effected vide section 112 of the Finance Act, 2021 (13 of 2021) with effect from 01.07.2017. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  | Amendment effected vide section 110 and 111 of the Finance Act, 2021 (13 of 2021). | Notification No.29/2021-Central Tax, dated 30.07.2021 | It brought into force the amendment effected vide section 110 and 111 of the Finance Act, 2021 (13 of 2021) with effect from 01.08.2021. |  |
|  | Amendment effected vide section 108, 109 and 113 to 122 of the Finance Act, 2021 (13 of 2021) | Notification No. 39/2021-Central Tax, dated 21.12.2021 | It brought into force the amendment effected vide section 108, 109 and 113 to 122 of the Finance Act, 2021 (13 of 2021) with effect from 01.01.2022. |  |
|  | Amendment effected vide section 123 of the Finance Act, 2021 (13 of 2021) | Notification No. 27/2023-Central Tax, dated 31.07.2023 | It brought into force the amendment effected vide section 123 of the Finance Act, 2021 (13 of 2021) with effect from 01.10.2023. |  |
|  | Amendment effected vide clause (c) of section 110 and section 111 of the Finance Act, 2022 (6 of 2022). | Notification No. 09/2022-Central Tax, dated 5.07.2022 | It brought into force the amendment effected vide clause (c) of section 110 and section 111 of the Finance Act, 2022 (6 of 2022) with effect from 05.07.2022. |  |
|  | Amendment effected vide section 100 to 114, except clause (c) of section 110 and section 111 of the Finance Act, 2022 (6 of 2022). | Notification No. 18/2022-Central Tax, dated 28.09.2022 | It brought into force the amendment effected section 110 to 114, except clause (c) of section 110 and section 111 of the Finance Act, 2022 (6 of 2022) with effect from 01.10.2022. |  |
|  | Amendment effected vide sections 137 to 162 of the Finance Act, 2023 (8 of 2023) | Notification No. 28/2023-Central Tax, dated 31.07.2023 | It brought into force the amendment effected vide sections 137 to 162 (except sections 149 to 154) of the Finance Act, 2023 (8 of 2023) with effect from 01.10.2023. <br> It also brought into force the amendments effected vide sections 149 to 154 of the Finance Act, 2023 with effect from 01.08.2023. |  |
|  | The CGST <br> (Amendment) Act, 2023 (30 of 2023). | Notification No. 48/2023-Central Tax, dated 29.09.2023 | It brought into force the provision of the CGST (Amendment) Act, 2023 (30 of 2023) with effect from 01.10.2023. |  |
| Section 2. | Definitions |  |  |  |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  | Page 14 of 127 |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| 2(13) | Intermediary | Circular No. 159/15/2021-GST | Clarification on doubts related to scope of "Intermediary". |  |
| 2(01) | Proper <br> Officer | Circular No. 1/1/2017-GST, dated 26.06.2017 | It specifies proper officer for provisions relating to registration and composition levy under the CGST Act, 2017 or the rules made thereunder. | It has been amended vide circular No. 223/17/224GST, dated 10.07.2024. |
|  |  | Circular No. 3/3/2017-GST, dated 05.07.2017 | It specifies proper officer in respect of provisions other than registration and composition levy under the CGST Act, 2017 | It has been further amended vide Circular No. 31/5/2018-GST, dated 09.02.2018. |
|  |  | Circular No. 9/9/2017-GST, dated 18.10.2017 | It authorizes officers for enrolling or rejecting applications for enrolment of GST Practitioners. | Also issued under Section 20 of the IGST Act, 2017 |
|  |  | Circular No. 31/05/2018-GST, dated 09.02.2018 as amended vide Circular No. 169/01/2022, dated 12.03.2022. | It specifies Proper Officer under Sections 73 and 74 of the CGST Act, 2017. It also amended Circular No. 3/3/2017GST, dated 05.07.2017. | Also issued under section 20 of the IGST Act, 2017. |
|  |  | Circular No. 223/17/2024-GST, dated 10.07.2024. | Amendment in circular No. 1/1//2017 in respect of Proper officer for provisions relating to Registration and Composition levy under the Central Goods and Services Tax Act, 2017 or the rules made thereunder. |  |
| CHAPTER II - ADMINISTRATION |  |  |  |  |
| Section 3 | Officers under this Act. | Notification No. 2/2017-Central Tax, dated 19.06.2017 as amended vide notification No. 79/2018-Central Tax, dated 31.12.2018; No. 04/2019-Central Tax, dated 29.01.2019 (effective from 01.02.2019); No. 51/2019-Central Tax, dated 31.10.2019; No. 2/2021-Central Tax, dated 12.01.2021; No. 02/2022-Central Tax, dated 11.03.2022; No. 39/2023-Central Tax, dated 17.08.2023; No. 05/2024-Central Tax, dated 30.01.2024 (w.e.f. 05.08.2023); No. 10/2024-Central Tax, dated 29.05.2024; and notification No. | It appoints officers of Central Tax and specifies territorial jurisdiction of Principal Chief Commissioner of Central tax and Chief Commissioner of Central Tax. <br> It empowered certain JC/ADC of Central Tax to adjudicate the Show cause notices issued by DGGI (Inserted Paragraph 3A along with Table V vide Notification No. 02/2022-Central Tax, dated 11.03.2022). | Also issued under section 3 of the IGST Act, 2017. |

Compiled by the GSTINDIAPATHWAY,ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 11/2024-Central Tax, dated 30.05.2024 |  |  |
|  |  | Notification No. 14/2017-Central Tax, dated 1.7.2017 (effective from 1.7.2017) as amended vide notification No. 01/2023-Central Tax, dated 4.1.2023. | It appoints officers of Directorate General of GST intelligence, Directorate General of GST, Directorate General of Audit as Central Tax officers and invests them with all the powers under CGST Act, 2017 and IGST Act, 2017. <br> It assigned powers of Superintendent of Central Tax to the Additional Assistant Directors in DGGI, DGGST and DG, Audit (Ref: Notification No. 01/2023-Central Tax, dated 04.01.2023). |  |
| Section 4 | Appointment of officers. |  |  |  |
| Section 5 | Powers of officers. |  |  |  |
|  |  | Notification No. 2/2017-Central Tax, dated 19.06.2017 as amended vide notification No. 79/2018-Central Tax, dated 31.12.2018; No. 04/2019-Central Tax, dated 29.01.2019 (effective from 01.02.2019); No. 51/2019-Central Tax, dated 31.10.2019; No. 2/2021-Central Tax, dated 12.01.2021; No. 02/2022-Central Tax, dated 11.03.2022; No. 39/2023-Central Tax, dated 17.08.2023; No. 05/2024-Central Tax, dated 30.01.2024 (w.e.f. 05.08.2023); No. 10/2024-Central Tax, dated 29.05.2024; and notification No. 11/2024-Central Tax, dated 30.05.2024. | It appoints officers of Central Tax and specifies territorial jurisdiction of Principal Chief Commissioner of Central tax and Chief Commissioner of Central Tax. <br> It empowered certain JC/ADC of Central Tax to adjudicate the Show cause notices issued by DGGI (Inserted Paragraph 3A along with Table V vide Notification No. 02/2022-Central Tax, dated 11.03.2022). | Also issued under section 3 of the IGST Act, 2017. |
|  |  | Notification No. 14/2017-Central Tax, dated 1.7.2017 (effective from 1.7.2017) as amended vide notification No. 01/2023-Central Tax, dated 4.1.2023. | It appoints officers of Directorate General of GST intelligence, Directorate General of GST, Directorate General of Audit as Central Tax officers and invests them with all the powers under the CGST Act, 2017 and the IGST Act, 2017. ${ }^{7}$ <br> It assigned powers of Superintendent of Central Tax to the Additional Assistant Directors in DGGI, DGGST and DG, Audit (Ref: Notification No. 01/2023-Central Tax, dated 04.01.2023). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 05/2020-Central Tax, dated 13.01.2020. | It authorized Pr. Commissioner/Commissioner and Additional Commissioner/ Joint Commissioner as Revisionary Authority under section 108 of the CGST Act, 2017. |  |
|  |  | Notification No. 35/2023-Central Tax, dated 31.07.2023 | It appointed common adjudicating authority to adjudicate the multiple SCNs pertaining to different jurisdictional States in the case of M/s BSH Household appliance manufacturing Pvt. Limited, Mumbai. | also issued under section 3 of the IGST Act, 2017). |
|  |  | Notification No. 40/2023-Central Tax, dated 17.08.2023 | It appointed common adjudicating authority to adjudicate the multiple SCNs pertaining to different jurisdictional States in the case of M/s United Spirits Limited, Mumbai . |  |
|  |  | Circular No. 1/1/2017-GST, dated 26.06.2017 | It specifies proper officer for provisions relating to registration and composition levy under the CGST Act, 2017 or the rules made thereunder. |  |
|  |  | Circular No. 3/3/2017-GST, dated 05.07.2017 | It specifies proper officer in respect of provisions other than registration and composition levy under the CGST Act, 2017 | It has been further amended vide Circular No. 31/5/2018-GST, dated 09.02.2018. |
|  |  | Circular No.9/ 9/2017-GST, dated 18.10.2017 | It authorizes officers for enrolling or rejecting applications for enrolment of GST Practitioners. | Also issued under section 20 of the IGST Act, 2017. |
|  |  | Circular No. 31/05/2018-GST, dated 09.02.2018 | It specifies Proper Officer under Sections 73 and 74 of the CGST Act, 2017. It also amended Circular No. 3/3/2017GST, dated 05.07.2017. | Also issued under section 20 of the IGST Act, 2017. |
|  |  | Order No. 2/2019-GST, dated 12.03.2019 | It assigns the specified cases to the Commissioner of Central Tax, Mumbai Central for the purpose of exercise of powers under section 73, 74, 75 and 76 of the CGST Act, 2019. |  |
| Section 6 | Authorization of officers of State tax or Union territory tax as proper officer in certain circumstances. | Notification No. 39/2017-Central Tax, dated 13.10.2017 as amended vide notification No. 10/2018-Central Tax, dated 23.01.2018. | It empowers the State/ UT tax officers to exercise powers under section 54 or Section 55 of the CGST Act, 2017. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| CHAPTER-III - LEVY AND COLLECTION OF TAX |  |  |  |  |
| Section 7 | Scope of Supply | Notification No. 14/2017-Central Tax (Rate), dated 28.06.2017 as amended vide notification No. 16/2018-Central Tax (Rate), dated 26.07.2018 (effective 27.07.2018) | It notifies certain activities or transactions undertaken by the Central Government or state Government or any local authority, engaged as public authority, which shall neither be treated as a supply of goods nor a supply of services. |  |
|  |  | Notification No. 25/2019-Central Tax (Rate), dated 30.09.2019. | It notified "service by way of grant of alcoholic liquor license, against consideration in the form of license fee or application fee or by whatever name it is called" undertaken by the State Governments in which they are engaged as public authorities, to be treated neither as a supply of goods nor a supply of service. |  |
|  |  | Circular No. 12/12/2017-GST, dated 26.10.2018 | Clarification regarding applicability of GST on the superior Kerosene Oil (SKO) retained for the manufacture of Linear Alkyl Benzene (LAB). |  |
|  |  | Circular No. 22/22/2017-GST, dated 21.12.2017 | Clarification on Issues regarding treatment of Supply by an Artist in Various States and Supply of Goods by Artists from Galleries. |  |
|  |  | Circular No. 29/03/2018-GST, dated 25.01.2018 | Clarification regarding applicability of GST on Polybutylene feedstock and Liquefied petroleum Gas Retained for the manufacture of Poly Iso- Butylene and Propylene or Di-butyl para Cresol-Reg. |  |
|  |  | Circular No. 53/27/2018-GST, dated 09.08.2018 | Clarification regarding applicability of GST on the Petroleum gases retained for manufacture of petroleum and Chemical Products. |  |
|  |  | Circular No. 76/50/2018-GST, dated 31.12.2018 | Clarification on certain issues (sale by Government departments to unregistered person; leviability of penalty under section 73(11) of the CGST Act; rate of tax in case of debit notes / credit notes issued under section 142(2) of the CGST Act; applicability of notification No. 50/2018- |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | Central Tax; valuation methodology in case of TCS under Income Tax Act and definition of owner of goods) related to GST. |  |
|  |  | Circular No. 196/08/2023-GST, dated 17.07.2023 | Clarification on taxability of shares held in a subsidiary company by the holding Company |  |
|  |  | Circular No. 199/11/2023-GST, dated 17.07.2023 | Clarification regarding taxability of services provided by an office of any organization in one state to the office of that organization in another state, both being distinct persons. |  |
|  |  | Circular No. 201/13/2023-GST, dated 01.08.2023 | Clarification regarding applicability of GST on certain services. |  |
|  |  | Circular No. 213/07/2024-GST, dated 26.06.2024 | Clarification on the taxability of ESOP/ESPP/RSU provided by a company to its employees through its overseas holding company-Reg |  |
|  |  | Circular No. 215/9/2024-GST, dated 26.06.2024 | Clarification on taxability of Salvage/ wreck value earmarked in the claim assessment of the damage caused to the motor vehicle-Reg |  |
|  |  | Circular No 218/12/2024-GST, dated 26.06.2024 | Clarification regarding taxability of the transaction of providing loan by an overseas affiliate to its Indian affiliate or by a person to a related person. |  |
|  |  | Circular No. 228/22/2024-GST, dated 15.07.2024 | Clarification regarding applicability of GST on certain services |  |
|  |  | Circular No. 229/23/2024-GST, dated 15.07.2024 | Clarification regarding GST rates \& classification (goods) based on the recommendations of the GST Council in its $53^{\text {rd }}$ meeting held on $22^{\text {nd }}$ June, 2024 at New Delhi-Reg |  |
| Section 8 | Tax liability on composite and mixed supplies |  |  |  |
| Section 9 | Levy and collection |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 9(1) |  | Notification No. 1/2017-Central Tax (Rate), dated 28.06.2017 (effective from 01.07.2017) as amended vide notification No. 18/2017-Central Tax (Rate), dated 30.06.2017; No. 19/2017-Central Tax (Rate), dated 18.08.2017; No. 27/2017-Central Tax (Rate), dated 22.09.2017; No. 34/2017-Central Tax (Rate), dated 13.10.2017; No. 41/2017Central Tax (Rate), dated 14.11.2017; No. 6/2018Central Tax (Rate), dated 25.01.2018; No. 18/2018Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 24/2018-Central Tax (Rate), dated 31.12.2018 (effective from 1.1.2019); No. 08/2019-Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 12/2019-Central Tax (Rate), dated 30.07.2019 (w.e.f. 01.08.2019); No. 14/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 27/2019-Central Tax (Rate), dated 30.12.2019 (w.e.f. 01.01.2020); No. 1/2020-Central Tax (Rate), dated 21.02.2020 (w.e.f.01.03.2020); No. 3/2020-Central Tax (Rate), dated 25.03.2020 (w.e.f. 01.04.2020); No. 01/2021Central Tax, dated 2.6.2021 ( w.e.f. 2.6.2021); No. 8/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 13/2021-Central Tax (Rate), dated 27.10.2021 (w.e.f. 27.10.2021); No. 14/2021-Central Tax (Rate), dated 18.11.2021 (w.e.f. 01.01.2022); No. 18/2021-Central Tax (Rate), dated 28.12.2021 (w.e.f. 01.01.2022); No.21/2021-Central Tax (Rate), dated 31.12.2021. (w.e.f. 01.01.2022); No. 01/2022-Central Tax (Rate), dated 31.03.2022 (w.e.f. 01.04.2022); No. 06/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 12/2022-Central Tax (Rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 03/2023-Central Tax | It notifies rate of Central Tax leviable on Intra-State taxable supply of goods. |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 09/2023-Central Tax (Rate), dated 26.07.2023 (w.e.f. 27.07.2023); No. 17/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023); No. 01/2024-Central Tax (rate), dated 03.01.2024 (w.e.f. 04.01.2024); and No. 02/2024-Central Tax (Rate), dated 12.07.2024 (w.e.f. 15.07.2024). |  |  |
|  |  | Circular No. 155/11/2021-GST, dated 17.06.2021 | Clarification regarding GST Rate on Laterals/Parts of Sprinklers or Drip Irrigation System-Reg (Entry No. 195B of notification No. 01/2017-Central Tax (Rate), dated 28.06.2017). |  |
|  |  | Notification No. 11/2017-Central Tax (Rate), dated 28.06.2017 as amended vide notification No. 20/2017-Central Tax (Rate), dated 22.08.2017; No. 24/2017-Central Tax (Rate), dated 21.09.2017; No. 31/2017-Central Tax (Rate), dated 13.10.2017; No. 46/2017-Central Tax (Rate), dated 14.11.2017 (effective from 15.11.2017); No. 47/2017-Central Tax (Rate), dated 14.11.2017 (effective from 15.11.2017); No. 1/2018-Central Tax (Rate), dated 25.01.2018; No. 13/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 17/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 27/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); No. 30/2018-Central Tax (Rate), dated 31.12.2018 (effective from 1.1.2019); and No. 03/2019-Central Tax (Rate), dated 29.03.2019 ( w.e.f. 01.04.2019); and No. 10/2019-Central Tax (Rate), dated 10.05.2019; No. 20/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 26/2019-Central Tax (Rate), dated 22.11.2019; and No. 2/2020-Central Tax (Rate), dated 26.03.2020 | It prescribes rate of central tax leviable on Intra-State supplies of taxable services. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (w.e.f. 01.04.2020); No. 02/2021-Central Tax (Rate), dated 02.06.2021 (w.e.f. 02.06.2021); No. 04/2021-Central Tax (Rate), dated 14.06.2021; and No. 06/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 15/2021-Central Tax (Rate), dated 18.11.2021 (w.e.f. 01.01.2022, but superceded before coming into force); No. 22/2021-Central Tax (Rate), dated 31.12.2021 (w.e.f. 01.01.2022); No. 03/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 05/2023Central Tax (Rate), dated 9.5.2023; No. 06/2023Central Tax (Rate), dated 26.07.2023 (w.e.f. 27.07.2023); and No. 12/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). |  |  |
|  |  | Circular No. 120/39/2019-GST, dated 11.10.2019 | Clarification on the effective date of explanation inserted in notification No. 11/2017-CTR, dated 28.06.2017, 5r. No. 3(vi)-Reg |  |
|  |  | Circular No. 126/45/2019-GST, dated 22.11.2019 | Clarification on scope of the notification entry at item (id), related to job work, under heading 9988 of Notification No. 11/2017-Central Tax (Rate), dated 28.06.2017. |  |
|  |  | Notification No. 37/2017-Central Tax (Rate), dated 13.10.2017 | It notifies central tax on intra-state supplies of motor vehicles purchased by lesser prior to 1.7.2017 or by registered supplier of motor vehicle who purchased motor vehicle prior to 01.07.2017 and did not avail ITC on such vehicle. This exemption is valid only up to 30.06.2020. |  |
|  |  | Notification No. 39/2017-Central Tax (Rate), dated 18.10.2017 as amended vide notification No. 11/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021). | It notifies central tax rate of $2.5 \%$ on intra-state supplies of goods, namely, food preparation (chapter 19 or 21) put up in retail container and intended for free distribution to EWS under Central Government to Economically weaker section under Central Government /State Government Programme subject to fulfillment of prescribed condition. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 2/2019-Central Tax (Rate), dated 07.03.2019 (effective from 01.04.2019) as amended vide notification No. 9/2019-Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019) and No. 18/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019). | It provides composition scheme with effect from 1.4.2019 for supplier of services with a tax rate of $6 \%$ having turnover in preceding year up to Rs. 50 lakhs. | Also issued under section 11(1) and 16(1) of the CGST Act, 2017. It provides a composition scheme for service provider through exemption route. Also relevant under section 10 of the CGST Act, 2017. |
|  |  | Circular No. 06/06/2017-GST, dated 27.08.2017 | It clarifies issue related to classification and GST Rate on lottery tickets. |  |
|  |  | Circular No. 30/4/2018-GST, dated 25.01.2018 | It clarifies on Supplies made to the Indian Railways classifiable under Any Chapter, other than Chapter 86. |  |
|  |  | Circular No. 84/03/2019-GST, dated 01.01.2019 | It clarifies on issue of classification of service of printing of pictures covered under 998386 |  |
|  |  | Circular No. 85/04/2019- GST, dated 01.01.2019 | It clarifies on issue of GST rate applicable on supply of food and beverage services by educational institution |  |
|  |  | Circular No. 177/09/2022-GST, dated 03.08.2022 | Clarification regarding applicable GST rates and exemption on certain services. |  |
|  |  | Circular No. 178/10/2022-GST, dated 03.08.2022 | GST applicability on liquidated damages, compensation and penalty arising out of breach of contract or other provisions of law. |  |
|  |  | Circular No. 179/11/2022-GST, dated 03.08.2022 | Clarification regarding GST Rates and Classification (goods) based on the recommendation of the GST Council in its $47^{\text {th }}$ meeting held on $28^{\text {th }}-29^{\text {th }}$ June at Chandigarh. |  |
|  |  | Circular No. 186/18/2022-GST, dated 27.12.2022 | Clarification on various issues pertaining to GST | Clarification inter alia covers the issue of taxability of No claim Bonus offered by Insurance |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 23 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  |  | Companies and applicability of e-invoicing w.r.t. an entity. |
|  |  | Circular No. 189/01/2023-GST, dated 13.01.2023 | Clarification regarding GST Rates and classification of Certain goods. |  |
|  |  | Circular No. 190/02/2023-GST, dated 13.01.2023 | Clarification regarding GST Rates and Classification of certain services. |  |
|  |  | Circular No. 191/03/2023-GST, dated 27.03.2023 | Clarification regarding GST Rate and Classification of "Rab" based on the recommendation of the GST Council in its $49^{\text {th }}$ Meeting held on $18^{\text {th }}$ February, 2023-Reg. |  |
|  |  | Circular No. 200/12/2023-GST, dated 01.08.2023 | Clarification regarding GST Rate and Classification of Certain Goods based on the recommendation of the GST Council in its $50^{\text {th }}$ Meeting held on $11^{\text {th }}$ July, 2023-Reg. |  |
|  |  | Circular No. 205/17/2023-GST, dated 31.10.2023. | Clarification regarding GST rate on imitation zari thread or yarn based on the recommendation of the GST Council in its $52^{\text {nd }}$ meeting held on $7^{\text {th }}$ October, 2023-reg. |  |
|  |  | Circular No.206/18/2023-GST, dated 31.10.2023 | Clarifications regarding applicability of GST on certain services -reg. |  |
| Section 9(3) | [Tax to be paid on reverse Charge basis]. | Notification No. 4/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 36/2017-Central Tax (Rate), dated 13.10.2017; No. 43/2017- Central Tax (Rate), dated 14.11.2017 (effective from 15.11.2017); No. 11/2018-Central Tax (Rate), dated 28.05.2018; No. 10/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 14/2022-Central Tax (Rate), dated 30.12.2022 (w.e.f. 01.01.2023); and No. 19/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | It specifies certain intra-state supplies of goods when supplied by specified supplier and received by specified recipient on which central tax is to be paid by such recipient of such intra-state supplies of goods on reverse charge basis. |  |
|  |  | Notification No. 13/2017-Central Tax (Rate), | It notified categories of supply of services when supplied |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 22/2017-Central Tax (Rate), dated 22.08.2017; No. 33/2017-Central Tax (Rate), dated 13.10.2017; No. 3/2018-Central Tax (Rate), dated 25.01.2018; No. 15/2018-Central Tax (Rate), dated 26.07.2018(effective from 27.07.2018); No. 29/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); No. 05/2019-Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 22/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No.29/2019-Central Tax (Rate), dated 31.12.2019; No. 05/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No 02/2023Central Tax (Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 08/2023-Central Tax (Rate), dated 26.07.2023 ( w.e.f. 27.07.2023); and No. 14/2023Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | by specified supplier to specified recipient of supply, where whole of central tax is required to be paid by the recipient of supply of services under Section 9(3) of CGST Act, 2017. |  |
|  |  | Circular No. 119/38/2019-GST, dated 11.10.2019 | Clarification Regarding Taxability of Supply of Securities under Securities Lending Scheme, 1997-Reg. | With effect from 1.10.2019, the borrower of securities is liable to discharge GST as per Sr. No. 16. |
|  |  | Circular No. 130/49/2019-GST, dated 31.12.2019 | Reverse Charge Mechanism on Renting of motor Vehicles-Reg |  |
| Section 9(4) |  | Notification No. 07/2019-Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019) as amended vide notification No. 24/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019). | It notifies certain services related to real estate sector to be taxed under Reverse Charge Mechanism. |  |
| Section 9(5) | [Tax to be paid by Electronic Commerce Operator] | Notification No. 17/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 23/2017-Central Tax (Rate), dated 22.08.2017; No. 17/2021-Central Tax (Rate), dated 18.11.2021 (w.e.f. 01.01.2022); and No. | It notifies the categories of services where Central tax on intra-state supplies is to be paid by Electronic Commerce operator (ECO). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 16/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). |  |  |
|  |  | Circular No. 167/23/2021-GST, dated 17.12.2021 | GST on Service Supplied by Restaurants through eCommerce Operators. |  |
|  | Circulars issued on issue of Levy and collection of GST |  |  |  |
|  |  | Circular No. 11/11/2017-GST, dated 20.10.2017 | Clarification on Taxability of Printing Contracts. |  |
|  |  | Circular No. 13/13/2017-GST, dated 27.10.2017 | Clarification on classification of Unstitched Salwar Suits (Cut pieces of fabric) under GST. |  |
|  |  | Circular No. 16/16/2017-GST, dated 15.11.2017 | Clarification regarding applicability of GST and availability of ITC in respect of Certain Services (It clarified on issues of applicability of GST on warehousing of Agricultural produce such as tea, processed coffee, jiggery, processed spices etc.; issue of leviability of GST on inter-state transfer of Aircraft engines, parts and accessories thereof and general insurance policies provided by a State Government employees of state government/police personnel etc. ) |  |
|  |  | Circular No. 20/20/2017, dated 22.11.2017 | It clarifies issue related to classification and GST rate on Terracotta Idols |  |
|  |  | Circular No. 19/19/2017-GST, dated 20.11.2017 | Clarification on taxability of Custom milling of Paddy |  |
|  |  | Circular No. 21/21/2017-GST, dated 22.11.2017 | It clarifies on issue of levy of IGST on Inter-State Movement of Rigs, Tools, and Spares, and all Goods on wheels (like Cranes). |  |
|  |  | Circular No. 27/01/2018-GST, dated 4.1.2018 | Clarification regarding levy of GST on accommodation services, betting and gambling in casinos, horse racing, admission to Cinema, homestays, printing, legal services etc. |  |
|  |  | Circular No. 28/02/2018-GST, dated 08.01.2018 (with corrigendum) | Clarification regarding GST on college Hostel Mess FeesReg. | Withdrawn [vide Circular No. 50/24/2018-GST, dated 31.07.2018]. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Order No. 02/2018-Central Tax, dated 31.03.2018 | Incidence of GST on Providing Catering Services in Train | Withdrawn [vide Circular No. 50/24/2018-GST, dated 31.07.2018]. |
|  |  | Circular No. 32/06/2018-GST, dated 12.02.2018 | Clarification regarding GST in respect of Certain miscellaneous Services |  |
|  |  | Circular No. 34/8/2018-GST, dated 1.3.2018 [as amended vide Circular No. 46/20/2018-GST, dated 06.06.2018]. | Clarification regarding GST in respect of certain services | S. No. 3 of Circular No. 34/8/2018-GST, dated 01.03.2018 modified vide Circular No. 46/20/2018GST, dated 06.06.2018. |
|  |  | Circular No. 35/9/2018-GST, dated 05.03.2018 | Clarification on Joint Venture-Taxable Services provided by the Members of the Joint Venture (JV) to the JV and Vice Versa and Inter-se between the member of the JVReg. |  |
|  |  | Circular No. 44/18/2018-CGST, dated 02.05.2018 | Clarification on Issue related to Taxability of "tenancy rights" under GST. |  |
|  |  | Circular No. 46/20/2018-GST, dated 06.06.2018 | Applicable GST Rate on Priority Sector Lending Certificates (PSLCs), Renewable Energy Certificates (RECs) and Other Similar Scrips - Reg. |  |
|  |  | Circular No. 62/36/2018-GST, dated 12.09.2018 | Levy of GST on Priority Sector Lending Certificates (PSLC) |  |
|  |  | Circular No. 93/12/2019-GST, dated 08.03.2019 | Nature of Supply of Priority Sector Lending Certificates (PSLC) |  |
|  |  | Circular No. 47/21/2018-GST, dated 08.06.2018 | Clarification of Certain Issues under GST. [ it also clarifies issues of reversal of ITC by OEM on mould and dies sent to component manufacturer, supply of goods and services in case of servicing of cars, books of account in case of auction of tea, coffee, rubber etc., transportation of goods by railways, issues relating to e-very bill etc.] |  |
|  |  | Circular No. 51/25/2018-GST, dated 31.07.2018 | Applicability of GST on Ambulance Services Provided to Government by Private Service Providers under the National Health Mission (NHM)-Reg. | It clarifies that the Circular No. 210/2/2018-Service Tax, dated 30.05.2018 issued in context of service tax also applicable to GST. |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 27 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 52/26/2018-GST, dated 09.08.2018 | Clarification regarding Applicability of GST on Various Goods and Services [namely, fortified toned milk, refined beet and cane sugar, tamarind kernel powder ( modified and unmodified form, drinking water, plasma products, wipes using spun lace non-woven fabric, Real Zari Kasab (thread), Marine Engine, Quilt and comforter, Bus body building as supply of motor vehicle or job work, Disc Brake Pad). |  |
|  |  | Circular No. 54/28/2018-GST, dated 09.08.2018 | Classification of Fertilizers supplied for use in the manufacture of other Fertilizers at 5\% GST Rate. |  |
|  |  | Circular No. 55/29/2018-GST, dated 10.08.2018 | Taxability of Services Provided by Industrial Training Institutes (ITI). |  |
|  |  | Circular No. 66/40/2018-GST, dated 26.09.2018 | GST on Residential Programmes or Camps meant for Advancement of Religion, Spirituality of Yoga by Religious and Charitable Trust. |  |
|  |  | Circular No. 80/54 /2018-GST, dated 31.12.2018 | It clarified GST rates \& classification (goods) of the following goods:- (i) Chhatua or Sattu (ii) Fish meal and other raw materials used for making cattle/poultry/aquatic feed (iii) Animal Feed Supplements/ feed additives from drugs (iv) Liquefied Petroleum Gas for Domestic Use (v) Polypropylene Woven and Non-Woven Bags and PP Woven and NonWoven Bags laminated with BOPP (vi) Wood logs for pulping (vii) Bagasse based laminated particle board (viii) Embroidered fabric sold in three pieces cloth for lady suits (ix) Waste to Energy Plant-scope of entry No. 234 of Schedule I of notification No.1/2017- Central Tax (Rate) dated 28.6.2017 (x) Turbo Charger for railways (xi) Rigs, tools \& Spares moving inter-state for provision of service |  |
|  |  | Circular No. 81/55/2018-GST, dated 31.12.2018 | Clarification regarding GST tax rate for Sprinkler and Drip Irrigation System including laterals |  |
|  |  | Circular No. 83/02/2019- GST, dated 01.01.2019 | Applicability of GST on Asian Development Bank (ADB) and International Finance Corporation (IFC) |  |
|  |  | Circular No. 86/05/2019- GST, dated 01.01.2019 | It clarifies on the issue of GST on Services of Business Facilitator (BF) or a Business Correspondent (BC) to Banking Company |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 100/19/2019-GST, dated 30.04.2019. | GST Applicability on Supply of Seed Certification Tags. |  |
|  |  | Circular No. 113/32/2019-GST, dated 11.10.2019 | Clarification regarding GST Rates and Classification (Goods)-Reg. |  |
|  |  | Circular No. 114/33/2019-GST, dated 11.10.2019 | Clarification on Scope of Support Services to Exploration, Mining or Drilling of Petroleum Crude or Natural Gas or Both. |  |
|  |  | Circular No. 115/34/2019-GST, dated 11.10.2019 | Clarification on Issue of GST on Airport Levies | Issued under section 168 of the CGST Act, 2017. |
|  |  | Circular No. 116/35/2019-GST, dated 11.10.2019 | Levy of GST on the service of display of name or placing of name plates of the donor in the premises of Charitable Organizations Receiving Donation or Gifts from Individual Donors-Reg. |  |
|  |  | Circular No. 118/37/2019-GST, dated 11.10.2019 | Clarification regarding Determination of Place of Supply in case of Software/Design Services Related to Electronics Semi-conductor and Design Manufacturing (ESDM) Industry-Reg. | Issued under Section 168 of the CGST Act, 2017. |
|  |  | Circular No. 119/38/2019-GST, dated 11.10.2019 | Clarification regarding Taxability of Supply of Securities under Securities Lending Scheme, 1997-Reg. |  |
|  |  | Circular No. 121/40/2019-GST, dated 11.10.2019 | GST on License Fee charged by the States for grant of Liquor Licenses to Vendors-Reg. |  |
|  |  | Circular No. 140/10/2020-GST, dated 10.06.2020 | Clarification in respect of levy of GST on Director's Remuneration. |  |
| Section 10 | Composition Levy | Rule 3 to Rule 7 of CGST Rules, 2017 | FORM GST CMP-01 to FORM GST CMP-07 |  |
|  |  | Notification No. 8/2017-Central Tax, dated 27.06.2017 as amended vide notification No. 46/2017-Central Tax, dated 13.10.2017; No. 1/2018-Central Tax, dated 1.1.2018; and No. 05/2019-Central Tax, dated 29.01.2019 (effective from 01.02.2019). | It notifies turnover limit for the purpose of composition levy scheme. It also excludes manufacturers of certain specified goods from the ambit of Composition Scheme. | Superceded vide notification No. 14/2019Central Tax, dated 07.03.2019 (effective from 01.04.2019) |
|  |  | Notification No. 14/2019-Central Tax, dated 07.03.2019 (w.e.f. 01.04.2019) as amended vide notification No. 43/2019-Central Tax, dated 30.09.2019 (w.e.f. 01.10.2019); No. 04/2022-Central Tax, dated 31.03.2022 (w.e.f. 01.04.2022); and No. | It notifies turnover limit for the purpose of composition levy scheme. It also excludes manufacturers of certain specified goods from the ambit of Composition Scheme. It extended the benefit of special composition scheme to |  |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 29 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 16/2022-Central Tax, dated 13.07.2022 (w.e.f. 18.07.2022). | the taxpayers engaged in supply of fly ash brick or fly ash aggregate (6815), bricks of fossil meals or similar siliceous earths (6901 00 10), building bricks (6904 1000), earthen or roofing tiles (6905 1000). |  |
|  |  | The CGST (Removal of Difficulties) Order No. 01/2017-Central Tax, dated 13.10.2017 | It was issued to remove the difficulties in respect of provision of section 10 of the CGST Act, 2017. | Superceded vide The CGST <br> (Removal of Difficulties) <br> Order No. 01/2019-Central <br> Tax, dated 01.02.2019. |
|  |  | The CGST (Removal of Difficulties) Order No. 01/2019-Central Tax, dated 01.02.2019. | It was issued to remove the difficulties in respect of provision of section 10 of the CGST Act, 2017. |  |
|  |  | Circular No. 1/1/2017, dated 26.06.2017 | It specifies proper officer for provisions relating to Registration and Composition levy under the CGST Act, 2017 or the rules made thereunder. |  |
|  |  | Circular No. 77/51/2018-GST, dated 31.12.2018 | It clarifies on the issue of denial of composition option by tax authorities and effective date thereof |  |
|  |  | Circular No. 97/16/2019-GST, dated 05.04.2019 | It clarifies the issue of exercise of option to pay tax (composition scheme for service providers) under notification No. 2/2019-Central Tax (Rate), dated 07.03.2019. |  |
|  |  | Circular No. 121/40/2019-GST, dated 11.10.2019 | GST on License Fee Charged by the States for Grant of Liquor Licenses to Vendors-Reg. |  |
| Section 11 | Power to Grant exemption from tax |  |  |  |
| Sub-section (1) | [ General Exemption] | Notification No. 2/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 28/2017-Central Tax (Rate ), dated 22.09.2017; No. 35/2017-Central Tax (Rate), dated 13.10.2017; No. 42/2017-Central Tax (Rate), dated 14.11.2017, No. 7/2018-Central Tax (Rate), dated 25.01.2018; No. 19/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 25/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); No. 15/2019-Central Tax (Rate), dated 30.09.2019 | It provides full exemption from payment of central tax to certain intra-state supplies of goods. |  |

Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (w.e.f. 01.10.2019); No. 9/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 19/2017Central Tax (Rate), dated 28.12.2021 (w.e.f. 01.01.2022); No. 07/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); No. 13/2022Central Tax (rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 04/2023-Central Tax (Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 18/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023); and No. 03/2024-Central Tax (Rate), dated 12.07.2024 (w.e.f. 15.07.2024). |  |  |
|  |  | Notification No. 3/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 16/2019-Central Tax (Rate), dated 30.09.2019 (01.10.2019); and No. 08/2022Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022). | It provides conditional exemption from payment of Central Tax in excess of $2.5 \%$ for specified intra-state supplies of goods for the purpose of specified petroleum operations. |  |
|  |  | Notification No. 7/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) | It provides full exemption from payment of central tax to intra-supplies of goods when supplied by (i) Central Supply Department to unit run canteens /Authorized customers or (ii) by unit run canteens to the authorized customers. |  |
|  |  | Notification No. 8/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 38/2017-Central Tax (Rate), dated 13.10.2017; No. 10/2018-Central Tax (Rate), dated 23.03.2018; No. 12/2018-Central Tax (Rate), dated 29.06.2018; and No. 22/2018- Central Tax (Rate), dated 06.08.2018. | It fully exempts intra-state supply of goods or services or both received by a Registered Person from Un-registered person from payment of Central Tax under section 9(4) of CGST Act, 2017 up to 30.09.2019. | ![img-0.jpeg](img-0.jpeg.png) |
|  |  | Notification No. 9/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) | It fully exempts intra-state supplies of goods or services or both received by Tax Deductor (under Section 51) from any supplier, who is not registered, from payment of whole of Central Tax subject to fulfillment of condition prescribed. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 10/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 01.07.2017) | It wholly exempts intra-state supplies of second hand goods received by a registered person, dealing in buying or selling of second hand goods and pay central tax on outward supplies of such goods, from any suppliers, who is not registered from payment of Central Tax leviable under section 9(4) of the CGST Act, 2017. |  |
|  |  | Notification No. 11/2017-Central Tax (Rate), dated 28.06.2017 as amended vide notification No. 20/2017-Central Tax (Rate), dated 22.08.2017; No. 24/2017-Central Tax (rate), dated 21.09.2017; No. 31/2017-Central Tax ( Rate), dated 13.10.2017; 46/2017-Central Tax ( Rate), dated 14.11.2017; No. 47/2017-Central Tax ( Rate), dated 14.11.2017; No. 1/2018-Central Tax (Rate), dated 25.01.2018; No. 13/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 17/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 27/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); No. 30/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); No. 04/2021-Central Tax (Rate), dated 14.06.2021; No. 06/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); and No. 15/2021-Central Tax (Rate), dated 18.11.2021 (w.e.f. 01.01.2022 but superceded before coming into force); and No. 22/2021Central Tax (Rate), dated 31.12.2021 (w.e.f. 01.01.2022). | It prescribes rate of Central Tax leviable on intra-state supplies of taxable services. | This notification has also been issued under section 9(1), section 15(5) and Section 16(1) of the CGST Act, 2017. |
|  |  | Notification No. 02/2022-Central Tax (rate), dated 31.03.2022 as amended vide notification No. 10/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022). | It provides conditional partial exemption from payment of CGST to intra-state supply of fly ash brick or fly ash aggregate (6815), bricks of fossil meals or similar siliceous earths (6901 00 10), building bricks (6904 1000), earthen or roofing tiles (6905 1000). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  |  |  |
|  |  | Circular No. 152/08/2021-GST, dated 17.06.2021 | Clarification regarding rate of tax applicable on construction services provided to a Government Entity, in relation to Construction such as of a a ropeway on turnkey basis-Reg (Relating to Entry No. 3(vi) of notification No. 11/2017-Central Tax (Rate), dated 28.06.2017). |  |
|  | Issued under 11(3) to add an explanation in the notification | Notification No. 17/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018) | It added explanation in the notification No. 11/2017Central Tax (Rate), dated 28.06.2017 as amended. |  |
|  |  | Notification No. 12/2017-Central Tax (Rate), dated 28.06.2017(w.e.f. 01.07.2018) as amended vide notification No. 21/2017-Central Tax (Rate), dated 22.08.2017; No. 25/2017-Central Tax (Rate), dated 21.09.2017; No. 30/2017-Central Tax (Rate), dated 29.09.2017; No. 32/2017-Central Tax (Rate), dated 13.10.2017; No. 2/2018-Central Tax (Rate), dated 25.01.2018; No. 14/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018); No. 28/2018-Central Tax (Rate), dated 31.12.2018 (effective from 01.01.2019); and No. 04/2019Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019); No. 13/2019-Central Tax (Rate), dated 31.07.2019 (w.e.f. 01.08.2019); No. 21/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019); No. 28/2019-Central Tax (Rate), dated 31.12.2019 (w.e.f. 01.01.2020); No. 04/2020-Central Tax (Rate), dated 30.09.2020 (w.e.f. 01.10.2020); No. 05/2020-Central Tax (Rate), dated 16.10.2020; No. 07/2021-Central Tax (Rate), dated 30.09.2021 (w.e.f. 01.10.2021); No. 16/2021-Central Tax (Rate), dated 18.11.2021 (w.e.f. 01.01.2022); No. 04/2022-Central Tax (Rate), dated 13.07.2022 | It fully exempts intra-state supply of specified services subject to fulfillment of conditions prescribed therein. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (w.e.f. 18.07.2022); No. 15/2022-Central Tax (Rate), dated 30.12.2022 (w.e.f. 01.01.2023); No. 01/2023-Central Tax (Rate), dated 28.02.2023 (w.e.f. 01.03.2023); No. 07/2023-Central Tax (Rate), dated 26.07.2023 (w.e.f. 27.07.2023); No. 13/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023); and No. 04/2024-Central Tax (Rate), dated 12.07.2024 (w.e.f. 15.07.2024). |  |  |
|  |  | Circular No. 82/01/2019- GST, dated 01.01.2019 | Applicability of GST on various programmes conducted by the Indian Institutes of Managements (IIMs) (with reference to notification No. 12/2017-Central Tax (Rate), dated 28.06.2017) |  |
|  |  | Circular No. 100/19/2019-GST, dated 30.04.2019. | GST Applicability on Seed Certification Tags. | Also clarifies the issue of exemption under Sr. No. 47 of notification No. 12/2017-Central Tax (Rate), dated 28.06.2017. |
|  |  | Circular No. 101/20/2019-GST, dated 30.04.2019. | GST Exemption on the Upfront amount payable in installments for long term lease of plots, under notification No. 12/2017-Central Tax (Rate), Sr. No. 41, dated 28.06.2017. |  |
|  |  | Circular No. 117/36/2017-GST, dated 11.10.2019 | Clarification on Applicability of GST Exemption to the DG, Shipping Approved Maritime Courses Conducted by Maritime Training Institute of India-Reg |  |
|  |  | Circular No. 149/05/2021-GST, dated 17.06.2021 | Clarification regarding applicability of GST on supply of food in Anganwadis and Schools-Reg. |  |
|  |  | Circular No. 150/06/2021-GST, dated 17.06.2021 | Clarification regarding applicability of GST on the activity of construction of road where considerations are received in deferred payment (annuity)-Reg. (Entry 23A of |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | notification No. 12/2017-Central Tax (Rate)). |  |
|  |  | Circular No. 151/07/2021-GST, dated 17.06.2021 | Clarification regarding applicability of GST on supply of various services by Central and State Board (such as National Board of Examination)-Reg. (Entry 66 of notification No. 12/2017-Central Tax (Rate)). |  |
|  |  | Circular No. 153/09/2021-GST, dated 17.06.2021 | GST on Milling of wheat into flour or paddy into rice for distribution by State Governments under PDS-Reg. (Relating to Entry No. 3A of notification No. 12/2017-Central Tax (Rate), dated 28.06.2017). |  |
|  |  | Circular No. 154/10/2021-GST, dated 17.06.2021 | GST on Service supplied by State Govemment to their undertaking or PSUs by way of Guaranteeing loans taken by them-Reg. (Relating to Entry No. 34A of notification No. 12/2017-Central Tax (Rate), dated 28.06.2017). |  |
|  |  | Circular No. 163/19/2021-GST, dated 06.10.2021 | Clarification regarding GST rates \& classification (goods) based on the recommendations of the GST Council in its $45^{\text {th }}$ Meeting held on $17^{\text {th }}$ September, 2021 at Lucknow. |  |
|  |  | Circular No. 164/20/2021-GST, dated 06.10.2021 | Clarifications regarding applicable GST Rates and Exemptions on Certain Services. |  |
|  | Insertion of explanation in the notification under section 11(3) of the CGST Act, 2017 | Notification No. 23/2018-Central Tax (Rate), dated 20.09.2018 | It inserts explanation in the notification No. 12/2017Central Tax (Rate), dated 28.06.2017. |  |
|  |  | Circular No. 55/29/2018-GST, dated 10.08.2018 | Taxability of Services Provided by Industrial Training Institutes (ITI). | It issues clarification in the context of notification No. 12/2017-CT (Rate), dated 28.06.2017. |
|  |  | Notification No. 26/2017-Central Tax (Rate), dated 21.09.2017 | It wholly exempts intra-state supply of heavy water and nuclear fuels (Chapter 28) by Department of Atomic Energy to the Nuclear Power Corporation of India Ltd. from payment of Central Tax. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 40/2017-Central Tax (Rate), dated 23.10.2017. | It exempts central tax on intra-state supply of taxable goods by a registered supplier to a registered recipient for export in excess of amount calculated @0.05\% subject to fulfillment of conditions prescribed therein. |  |
|  |  | Notification No. 45/2017-Central Tax (Rate), dated 14.11.2017 as amended vide notification No. 9/2018-Central Tax (Rate), dated 25.01.2017. | It prescribes concessional rate of Central tax of $2.5 \%$ on scientific and technical equipment, apparatus, equipment (including computers) etc. when supplied to public funded Research institution subject to fulfillment of conditions prescribed therein. | Rescinded vide notification No. 11/2022Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022). |
|  |  | Notification No. 5/2018-Central Tax (Rate), dated 25.01.2018 | It exempts intra-state supply of services by way of grant of license or lease to explore or mine petroleum crude or natural gas or both, from so much of the Central Tax as is leviable on the consideration paid to Central Government in the form of Central Government share of profit petroleum as defined in the contract. |  |
|  |  | Notification No. 08/2018-Central Tax (Rate), dated 25.01.2018 | It partially exempts the Central Tax on intra-state supplies of old and used motor vehicles subject to specified condition. |  |
|  |  | Notification No. 21/2018-Central Tax (Rate), dated 26.07.2018 (effective from 27.07.2018) as amended vide notification No. 20/2021-Central Tax (Rate), dated 28.12.2021 (w.e.f. 01.01.2022). | It provides partial exemption from payment of Central Tax on specified intra-state supplies of Handicraft goods. |  |
|  |  | Notification No. 26/2018-Central Tax (Rate), dated 31.12.2018 (effective from 1.01.2019) as amended vide notification No. 17/2019-Central Tax (Rate), dated 30.09.2019 (01.10.2019) and No. 10/2023-Central Tax (Rate), dated 26.07.2023 (read with corrigendum dated 31.07.2023 (w.e.f. 27.07.2023). | It fully exempts the intra-state supply of gold falling under heading 71.08 of First Schedule of Customs Tariff Act, 1975 when supplied by nominated agency under the Scheme for "Export against Supply by Nominated Agency" from payment of Central Tax subject to specified conditions. |  |
|  |  | Notification No. 19/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019) | It fully exempts all the goods supplied to the Food and Agriculture Organization of the UN for execution of |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | specified projects from payment of payment of Central Tax subject to fulfillment of specified conditions. |  |
|  |  | Notification No. 05/2021-Central Tax (Rate), dated 14.06.2021 (read with corrigendum dated 15.06.2021). | It exempts (in excess of amount specified) to goods relating to COVID-19 up to 30.09 .2021 (inclusive) |  |
|  |  | Notification No. 12/2021-Central Tax (Rate), dated 30.09.2021 (with effect from 01.10.2021 upto 31.12.2021). | It exempts (in excess of amount specified) to goods relating to COVID-19 from 01.10.2021 to 31.12.2021. |  |
|  |  | Circular No. 163/19/2021-GST, dated 06.10.2021 | Clarification regarding GST Rates and Classification (goods) based on the recommendation of the GST Council in its 45th Meeting held on 17th September, 2021 at Lucknow-Reg. |  |
|  |  | Circular No. 164/20/2021-GST, dated 06.10.2021 | Clarification regarding applicable GST Rates \& Exemption on certain services-Reg. |  |
| CHAPTER IV - TIME AND VALUE OF SUPPLY |  |  |  |  |
| Section 12 | Time of supply of goods |  |  |  |
| Section 13 | Time of supply of services |  |  |  |
|  |  | Circular No. 221/15/2024-GST, dated 26.06.2024 | Clarification on time of supply in respect of supply of services of construction of road and maintenance thereof of National Highway Projects of National Highways authority of India (NHAI) in Hybrid Annuity Mode (HAM) Model-Reg |  |
|  |  | Circular No. 222/16/2024-GST, dated 26.06.2024 | Clarification on time of supply of services of spectrum usage and other similar services under GST-Reg. |  |
|  |  |  |  |  |
| Section 14 | Change in rate of tax in respect of supply of goods or services |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 15 | Value of taxable supply | Rule 27 to Rule 35 of the CGST Rules, 2017. |  |  |
|  |  | Notification No. 49/2023-Central Tax, dated 29.09.2023 (w.e.f. 01.10.2023) | It notified supply of online money gaming; supply of online gaming (other than online money gaming); and supply of actionable claims in casinos under section 15(5) in respect of which value of supply shall be determined in manner to be determined in prescribed manner. |  |
|  |  | Circular No. 92/11/2019-GST, dated 07.03.2019 | Clarification on various doubts related to treatment of Sales Promotion Schemes under GST. It clarifies on issues of taxability, valuation, availability or otherwise of ITC on free samples and gifts, Buy one get one free offer; discount including 'Buy one, save more" offers, secondary discounts. |  |
|  |  | Circular No. 105/24/2019-GST, dated 28.06.2019. | Clarification on various doubts related to treatment of secondary or post-sales discount under GST. | Withdrawn vide Circular No. 112/31/2019-GST, dated 03.10.2019 |
|  |  | Circular No. 102/21/2019-GST, dated 28.06.2019. | Clarification regarding applicability of GST on Additional/Penal Interest-Reg. |  |
|  |  | Circular No. 204/16/2023-GST, dated 27.10.2023 | Clarification on issues pertaining to taxability of personal guarantee and corporate guarantee in GST-reg. |  |
|  |  | Circular No. 210/4/2024-GST, dated 26.06.2024 | Clarification on Valuation of Supply of Import of Services by a related person where recipient is eligible to full Input Tax Credit-Reg |  |
|  |  | Circular No. 212/06/2024-GST, dated 26.06.2024 | Clarification on Mechanism for providing evidence of compliance of conditions of Section 15(3) (b) (ii) of the CGST Act 2017 by the suppliers |  |
|  |  | Circuarl No. 214/8/2024-GST, dated 26.06.2024 | Clarification on the requirement of reversal of input tax credit in respect of the portion of the premium for life insurance policies which is not included in taxable valueReg | Also relevant for Rule 32/42 of the CGST Rules, 2017. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 225/19/2024-GST, dated 11.07.2024 | Clarification on various issues pertaining to taxability and valuation of supply of services of providing corporate guarantee between related persons-Reg | Also refer to the rule 28 of the CGST Rules, 2017 |
| CHAPTER V - INPUT TAX CREDIT |  | Rule 36 to Rule 45 of the CGST Rules, 2017. | FORM GST ITC-01 to FORM GST ITC-04 |  |
| Section 16 | Eligibility and conditions for taking input tax credit | The CGST (Removal of Difficulties) No. 2/2018Central Tax, dated 31.12.2018. | It inserts a proviso in the sub-section (4) of Section 16 of the CGST Act, 2017, thereby allowing input credit in respect of any invoice or invoice relating to such debit note for supply of goods or services or both made during the financial year 2017-18, the details of which have been uploaded by the supplier under sub-section (1) of section 37 till the due date for furnishing the details under subsection (1) of said section for the month of March, 2019. |  |
|  |  | Circular No. 160/16/2021-GST (read with corrigendum dated 24.09.2021) | Clarification in respect of certain GST Related Issues-Reg (it delink the date of issuance of debit note from the date of issuance of the underlying invoice for purposes of availing ITC in the light to amendment effected in section 16(4) with effect from 1.1.2021. ) |  |
|  |  | Circular No. 183/15/2022-GST, dated 27.12.2022 | Clarification to deal with difference in Input Tax Credit (ITC) availed in FORM GSTR-3B as compared to that detailed in FORM GSTR-2A for FY 2017-18 and 2018-19Reg |  |
|  |  | Circular No. 193/05/2023-GST, dated 17.07.2023 | Clarification to deal with difference in Input Tax Credit (ITC) availed in FORM GSTR-3B as compared to that detailed in FORM GSTR-2A for the period from 01.04.2019 to 31.12.2021-Reg |  |
|  |  | Circular No. 184/16/2022-GST, dated 27.12.2022 | Clarification on the entitlement of input tax credit where the place of supply is determined in terms of the proviso to sub-section (8) of Section 12 of the IGST Act, 2017. | Transportation services. |
|  |  | Circular No. 195/07/2023-GST, dated 17.07.2023 | Clarification on availability of ITC in respect of warranty replacement of parts and repair services during warranty period. | To be read with Circular No. 216/10/2024-GST, dated 26.06.2024 |
|  |  | Circular No. 216/10/2024-GST, dated 26.06.2024 | Clarification in respect of GST liability and input tax credit (ITC) availability in cases involving warranty |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | /extended warranty, in furtherance to Circular No. 195/07/2023, dated 17.07.2023-Reg |  |
|  |  | Circular No. 211/5/2024-GST, dated 26.06.2024 | Clarification on time limit under section 16(4) of the CGST Act, 2017 in respect of RCM supplies received from unregistered persons-Reg. |  |
| Section 17 | Apportionment of credit and blocked credits | The CGST (Removal of Difficulties) Order, No. 04/2019-Central Tax, dated 29.03.2019 (w.e.f. 01.04.2019). | It removes difficulty in case of supply of services covered by clause (b) of paragraph 5 of Schedule II of the CGST Act, 2017. |  |
|  |  | Circular No. 172/04/2022-GST, dated 06.07.2022 | Clarification On various issues pertaining to GST-Reg | It inter alia clarifies on issue of interpretation of Section 17(5) of the CGST Act, 2017. |
|  |  | Circular No. 217/11/2024-GST, dated 26.06.2024 | Entitlement of ITC by the insurance companies on the expenses incurred for repair of motor vehicles in case of reimbursement mode of insurance claim settlement-Reg |  |
|  |  | Circular No. 219/13/2024-GST, dated 26.06.2024 | Clarification on availability of input tax credit on ducts and manholes used in Network of optical fiber cables (OFCs) in terms section 17(5) of the CGST Act, 2017-Reg. |  |
| Section 18 | Availability of credit in special circumstances | Circular No. 96/15/2019-GST, dated 28.03.2019 | Clarification in respect of transfer of Input Tax Credit in case of death of sole proprietor-Reg. |  |
|  |  | Circular No. 133 03/2020-GST, dated 23.03.2020. | Clarification in respect of apportionment of input tax credit (ITC) in cases of business reorganization under section 18 (3) of CGST Act read with rule 41(1) of CGST Rules. |  |
| Section 19 | Taking input tax credit in respect of inputs and capital goods sent for job work |  |  |  |
| Section 20 | Manner of distribution of credit by Input Service Distributor. | Circular No. 71/45/2018-GST, dated 26.10.2018 | It clarifies issues related to Casual Taxable Person and Recovery of Excess ITC distributed by an ISD. |  |
| Section 21 | Manner of recovery of credit distributed in excess. |  |  |  |

Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| CHAPTER VI - REGISTRATION |  | Rule 8 to Rule 26 of the CGST Rules, 2017. | FORM GST REG-01 to FORM GST REG-30 |  |
| Section 22 | Person liable for registration. |  |  |  |
| Section 23 | Person not liable for registration. |  |  |  |
|  |  | Notification No. 5/2017-Central Tax, dated 19.06.2017 [effective from 22.06.2017] | It specifies the persons, who are only engaged in making supplies of taxable goods or services on which tax is payable on reverse charge basis by the recipient of such goods or services under section 9(3), as category of person exempted from obtaining registration under CGST Act, 2017. |  |
|  |  | Notification No. 32/2017-Central Tax, dated 15.09.2017 as amended vide notification No. 38/2017-Central Tax, dated 13.10.2017 | It specifies the casual taxable person, making taxable supplies of handicraft goods subject to specified turnover and conditions, as category of person exempted from obtaining registration under the CGST Act, 2017 | Superceded <br> notification No. 56/2018- <br> Central Tax, dated 23.10.2018]. |
|  |  | Notification No. 65/2017-Central Tax, dated 15.11.2017as amended vide notification No. 06/2019-Central Tax, dated 29.01.2019 (effective from 01.02.2019). | It specifies the persons making supplies of services, other than supplies covered by section 9(5) where ECO is required to collect tax, and having aggregate turnover on all India basis is less than Rs. 25 lakhs (Rs. 10 lakhs in case of special category states other than J \& K) as category of persons exempted from obtaining registration under CGST Act, 2017. |  |
|  |  | Notification No. 56/2018-Central Tax, dated 23.10.2018. | It specifies the casual taxable person making taxable supplies of specified handicraft goods subject to specified turnover and conditions, as a category of person exempted from obtaining registration under CGST Act, 2017. |  |
|  |  | Notification No. 10/2019 - Central Tax, dated 07.03.2019 (w.e.f. 01.04.2019) as amended vide notification No. 03/2022-Central Tax, dated 31.03.2022 ( w.e.f. 01.04.2022); and No. 15/2022Central Tax, dated 13.07.2022 (w.e.f. 18.07.2022). | It provides exemption from registration for any person engaged in exclusive supply of goods and whose aggregate turnover in the financial year does not exceed Rs. 40 lakhs. <br> It extended the benefit under notification to the taxpayer engaged in supply of fly ash brick or fly ash aggregate |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | (6815), bricks of fossil meals or similar siliceous earths (6901 00 10), building bricks (6904 1000), earthen or roofing tiles (6905 1000). |  |
|  |  | Notification No. 6/2017-Central Tax, dated 19.06.2017 (with effect from 22.06.2017) as amended vide notification No. 11/2017-Central Tax, dated 28.06.2017. | It notifies the modes of verifications for the purpose of Rule 26 of the CGST Rules, 2017. |  |
|  |  | Notification No. 34/2023-Central Tax, dated 31.07.2023 (w.e.f. 01.10.2023) | It specifies the persons making supplies though ECO and having aggregate turnover in the preceding FY and in the current FY not exceeding the amount prescribed for obtaining registration as the category of persons exempted from obtaining mandatory registration under section 22(1) subject to certain conditions. |  |
| Section 24 | Compulsory registration in certain cases |  |  |  |
| Section 25 | Procedure for registration. | Rule 8 to Rule 17 of the CGST Rules, 2017 | FORM GST REG-01 to FORM GST REG-13 |  |
|  |  | Notification No. 17/2020-Central Tax, dated 23.03.2020 (w.e.f. 01.04.2020). | It specified classes of person who shall be exempted from AADHAR Authentication provided in sub-section (6D) of Section 25 of the CGST Act, 2017. | I issued in terms of subsection (6D) of section 25 of the CGST Act, 2017] Superceded vide notification No. 03/2021Central Tax, dated 23.02.2021. |
|  |  | Notification No. 18/2020-Central Tax, dated 23.03.2020 (w.e.f. 01.04.2020) | It notified 1st April, 2020 as the date from which an individual shall be required to undergo authentication, of Aadhaar number in order to be eligible for registration. | [Issued in term of sub-section (6B) of section 25 of the CGST Act, 2017] |
|  |  | Notification No. 19/2020-Central Tax, dated 23.03.2020 (w.e.f. 01.04.2020) | It specified class of persons, other than individuals, who shall be required to undergo authentication, of Aadhaar number in order to be eligible for registration. The specified class of persons are (a) authorised signatory of all types; (b) Managing and Authorised partners of a partnership firm; and (c) Karta of Hindu undivided family. | I issued in terms of subsection (6C) of section 25 of the CGST Act, 2017. |

Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  | Notification issued under Rule 8 (sub-rule 4B) | Notification No. 27/2022-Central Tax, dated 26.12.2022 as amended vide notification No. 05/2023-Central Tax, dated 31.03.2023 (with retrospective effect from 26.12.2022); No. 31/2023Central Tax, dated 31.07.2023; and No. 54/2023Central Tax, dated 17.11.2023. | It specifies that provision of sub-rule (4A) of rule 8 shall not apply in all the states and Union Territory except the States of Andhra Pradesh, Gujarat and Puducherry. | Rescinded vide notification No. 13/2024-Central Tax, dated 10.07.2024 (w.e.f. 10.07.2024) |
|  | Issued under subsection (6D) of section 25. | Notification No. 03/2021-Central Tax, dated 23.02.2021 as amended vide notification No. 36/2021-Central Tax, dated 24.09.2021. | It notified the person to whom the provisions of subsection (6B) and (6C) of Section 25 of the CGST Act, 2017 shall not apply. |  |
|  |  | Instruction No. 03/2023-GST, dated 14.06.2023 | Guidelines for processing of Application for Registration. |  |
| Section 26 | Deemed Registration |  |  |  |
| Section 27 | Special Provisions relating to casual taxable person and non-resident taxable person. | Circular No. 71/45/2018-GST, dated 26.10.2018. | It clarifies issues related to Casual Taxable Person and Recovery of Excess Input Tax Credit Distributed by an ISD. |  |
| Section 28 | Amendmentof Registration | Rule 19 of the CGST Rules, 2017 | FORM GST REG-14 and FORM GST REG-15 |  |
| Section 29 | Cancellation [or Suspension] of Registration | Rule 20 to 21, Rule 21A, Rule 22 of the CGST Rules, 2017 | FORM GST REG-16 to FORM GST REG-20 FORM GST REG-31 |  |
|  |  | Circular No. 69/43/2018-GST, dated 26.10.2018 | Processing of Applications for Cancellation of Registration submitted in FORM GST REG-16. |  |
|  |  | Circular No. 95/14/2109-GST, dated 28.03.2019. | Verification of applications for grant of new Registration. |  |
|  |  | Circular No. 99/18/2019-GST, dated 23.04.2019 | Clarification regarding filing of Application for Revocation of Cancellation of Registration in terms of Removal of Difficulty Order (RoD) Number 05/2019Central Tax, dated 23.04.2019. |  |
|  |  | Circular No. 145/01/2021-GST, dated 11.02.2021 | Standard operating Procedure (SOP) for Implementation |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | of the Provisions of Suspension of Registrations under Sub-rule (2A) of Rule 21A of CGST Rules, 2017-Reg. |  |
|  |  | The CGST (Fifth Removal of Difficulties) Order, 2019 | It seeks to extend the time limit for filing an application for revocation of cancellation of registration for specified taxpayers. |  |
| Section 30 | Revocation and of <br> cancellation | Rule 23 of the CGST Rules, 2017 | FORM GST REG-21 to FORM GST REG-24 |  |
|  |  | The CGST (Removal of Difficulties) Order, 2020. | It extended the date for filing application for revocation of cancellation of registration under section 30(1) for thoseregistered taxpayers who were served notice under 29(2) (c) or (d) and cancellation order were passed upto 12.06.2020 to the date of service of cancellation order or 31.08.2020 whichever is later. |  |
|  |  | Circular No. 148/04/2021-GST, dated 18.05.2021. | Standard Operating Procedure (SOP) for implementation of the provision of extension of time limit to apply for revocation of cancellation of registration under section 30 of the CGST Act, 2017 and rule 23 of the CGST Rules, 2017. |  |
| CHAPTER VII - TAX INVOICE, CREDIT AND DEBIT NOTES |  | Rule 46 to Rule 55 A of the CGST Rules, 2017 |  |  |
| Section 31 | Tax invoice | Notification No. 12/2017-Central Tax, dated 28.06.2017 as amended vide notification No. 78/2020-Central Tax, dated 15.10.2020 (with effect from 01.04.2021); and No. 90/2020-Central Tax, dated 01.12.2020. | It notified the number of digits of HSN Code to be declared in a tax invoice issued by a registered person. It notifies eight digits of HSN Codes to be mentioned in a tax invoice issued by him in respect of specified chemicals ( Ref: second proviso) | [ Issued under Rule 46 of the CGST Rules, 2017] |
|  |  | Circular No. 90/09/2019-GST, dated 18.02.2019 | Compliance of Rule 46 (n) of the CGST Rules, 2017 while issuing invoices in case of Inter-State Supply. |  |
|  |  | The CGST (Removal of Difficulty) Order No. 3/2019-Central Tax, dated 08.03.2019 | It clarifies that the provisions of clause (C) of Section 31(3) of the CGST Act, 2017 shall apply to a person paying tax under Notification No. 2/2019-Central Tax (Rate), dated 07.03.2019. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 70/2019-Central Tax, dated 13.12.2019 as amended vide notification No. 13/2020-Central Tax, dated 21.03.2020 [as amended. <br> Note: The notification No. 13/2020-Central Tax, dated 21.03.2020 has been amended vide No. 61/2020Central Tax, dated 30.07.2020; No. 70/2020-Central Tax, dated 30.09.2020; No. 88/2020-Central Tax, dated 10.11.2020; No. 05/2021-Central Tax, dated 08.03.2021; No. 23/2021-Central Tax, dated 01.06.2021; No. 01/2022-Central Tax, dated 24.02.2022; No. 17/2022-Central Tax, dated 01.08.2022 and last amended vide notification No. 10/2023-Central Tax, dated 10.05.2023. | It specify certain registered persons (having aggregate turnover in any preceding financial year from 2017-18 onwards more than Rs. 500 crores) who shall be required to issue e-invoices with effect from $\underline{01.10 .2020}$. <br> The turnover limit for mandatory issuance of e-invoice reduced to Rs. 100 crores w.e.f. 01.01.2021(vide notification No. 88/2020-Central Tax, dated 10.11.2020). <br> The turnover limit for mandatory issuance of e-invoice reduced to Rs. 50 crores reduced with effect from 01.04.2021 (vide notification No. 05/2021-Central Tax, dated 08.03.2021). <br> The turnover limit for mandatory issuance of e-invoice reduced to Rs. 20 crores reduced with effect from 01.04.2022 (vide notification No. 01/2022-Central Tax, dated 24.02.2022). <br> The turnover limit for mandatory issuance of e-invoice reduced to Rs. 10 crores reduced with effect from 01.10.2022 (vide notification No. 17/2022-Central Tax, dated 01.08.2022). <br> The turnover limit for mandatory issuance of e-invoice reduced to Rs. 5 crores reduced with effect from 01.08.2022 (vide notification No. 10/2023-Central Tax, dated 10.05.2023). <br> It excludes certain registered persons including a government department, and a local authority from the requirement of issuance of e-invoices. | [issued under Rule 48(4) of the CGST Rules, 2017]. |
|  |  | Circular No. 186/18/2022-GST, dated 27.12.2022 | Clarification on various issues pertaining to GST (applicability of e-invoicing w.r.t. an entity]. | It also provides clarification on taxability of no-claim bonus offered by insurance companies. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circulus/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 72/2019-Central Tax, dated 13.12.2019 | It mandated issuance of invoices with QR code by certain class of registered person (having turnover of more than Rs. 500 crores) with effect from 1.4.2020. | Superceded vide notification No. 14/2020-Central Tax, dated 21.03.2020. |
|  |  | Notification No. 14/2020-Central Tax, dated 21.03.2020 (w.e.f. 01.10.2020) as amended vide notification No. 71/2020-Central Tax, dated 30.09.2020. | It mandated issuance of invoices with QR code by certain class of registered person (having turnover of more than Rs. 500 crores in any preceding financial year from 201718 onwards) with revised effective date of 01.12 .2020 . | [issued under Rule 46 of the CGST Rules, 2017] |
|  |  | Circular No. 146/02/2021-GST, dated 23.02.2021 | Clarification in respect of applicability of Dynamic Quick Response (QR) Code on B2C invoices and compliance of notification No. 14/2020-Central Tax, dated 21.03.2021. |  |
|  |  | Circular No. 156/12/2021-GST, dated 21.06.2021 | Clarification in respect of applicability of Dynamic Quick Response (QR) Code on B2C invoices and Compliance of notification No. 14/2020-Central Tax, dated 21.03.2020. |  |
|  |  | Circular No. 165/21/2021-GST, dated 17.11.2021 | Clarification in respect of applicability of Dynamic Quick Response (QR) Code on B2C invoices and Compliance of notification No. 14/2020-Central Tax, dated 21.03.2020. |  |
|  |  | Circular No. 198/10/2023-GST, dated 17.07.2023 | Clarification on issue pertaining to e-invoice. | it clarifies on the issue of generation of e-invoice in cases of supplies made to Government Departments or establishment etc. registered solely for TDS purpose. |
| Section 31A | Facility of digital payment to recipient [Inserted vide Finance (No. 2) Act, 2019 with effect from 01.01.2020] |  |  |  |
| Section 32 | Prohibition of unauthorized collection of tax |  |  |  |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 46 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 33 | Amount of tax to be indicated in tax invoice and other documents. | Rule 35 of the CGST Rules, 2017 |  |  |
| Section 34 | Credit and debit notes |  |  |  |
| CHAPTER VIII - ACCOUNTS AND RECORDS |  | Rule 56 to Rule 58 of the CGST Rules, 2017 | FORM GST ENR-01 to FORM GST ENR-02 |  |
| Section 35 | Accounts and other records | Circular No. 23/23/2017-GST, dated 21.12.2017 (read with corrigendum) | Issues in respect of maintenance of books of account relating to additional place of business by a principal or an auctioneer for the purpose of auction of tea, coffee, rubber etc. |  |
| Section 36 | Period of retention of records |  |  |  |
| CHAPTER IX - RETURNS |  | Rule 59 to Rule 82 of the CGST Rules, 2017 | FORM GSTR-1 to FORM GSTR- 11 and FORM GST MIS-1 to FORM GST MIS-3 |  |
| Section 37 | Furnishing details of outward supplies | The CGST (Removal of Difficulties) No. 2/2018Central Tax, dated 31.12.2018. | It inserts a proviso in the sub-section (3) of Section 37 of the CGST Act, 2017, thereby allowing rectification of error or omission in respect of the details furnished under subsection (1). |  |
|  |  | Notification No. 18/2017-Central Tax, dated 8.08.2017 (effective from 8.8.2017). | It extended the time limit for furnishing the details of the FORM GSTR-1 returns for the month of July, 2017 and August, 2017. | Superceded (vide notification No. 29/2017Central Tax, dated 08.08.2017 as well as the notification No. 44/2018Central Tax, dated 10.09.2018). |
|  |  | Notification No. 29/2017-Central Tax, dated 5.09.2017. | It superseded notification Nos. 18/2017-Central Tax, dated 08.08.2017, 19/2017-Central Tax, dated 08.08.2017 and 20/2017-Central Tax, dated 08.08.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 returns for the month of July, 2017 and August, 2017. | Superceded notification No. 30/2017Central Tax, dated 05.09.2017). |
|  |  | Notification No. 30/2017-Central Tax, dated | It superseded notification No. 29/2017-Central Tax, dated | Superceded (vide <br>  <br> Page 47 of 127 |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 11.09.2017 as amended vide notification no. 54/2017-Central Tax, 30.10.2017. | 05.09.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 Returns for the month of July, 2017 for specified class of taxable/ registered person. | notification No. 58/2017Central Tax, dated 15.11.2017). |
|  |  | Notification No. 58/2017-Central Tax, dated 15.11.2017. | It superseded notification No. 30/2017-Central Tax, dated 11.09.2017 and it extended the due dates for furnishing the details of outward supplies in FORM GSTR-1 for the months from July, 17 to March, 2018. | Superceded <br> notification No. 72/2017Central Tax, dated 29.12.2017. Again, Superceded <br> Notification No. 44/2018Central Tax, dated 10.09.2018). |
|  |  | Notification No. 72/2017-Central Tax, dated 29.12.2018 | It supersedes notification No. 58/2017-Central Tax, dated 15.11.2017. It extended due date for furnishing the monthly details of outward supplies in FORM GSTR-1 Returns for the months from July, 17 to March, 2018 by such class of Registered Persons having aggregate turnover of more than Rs. 1.5 crores in the preceding FY or the Current FY. |  |
|  |  | Notification No. 57/2017-Central Tax, dated 15.11.2017 | It extended due dates for furnishing the quarterly details of outward supplies in FORM GSTR-1 for the months from July, 17 to March, 2018 in case of registered persons having turnover up to Rs. 1.5 crores. | Superceded <br> notification No. 71/2017Central Tax, dated 29.12.2017). |
|  |  | Notification No. 71/2017-Central Tax, dated 29.12.2017 | It supersedes notification No. 57/2017-Central Tax, dated 15.11.2017. It extended due date for furnishing the quarterly details of outward supplies in FORM GSTR-1 for the months from July, 17 to March, 2018 in case of registered persons having turnover up to Rs. 1.5 crores. |  |
|  |  | Notification No. 18/2018-Central Tax, dated 28.03.2018 | It specified the last date for filing of return in FORM GSTR-1 for the month of April, May, and June, 2018 by registered person having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year. | Superceded <br> Notification No. 44/2018Central Tax, dated 10.09.2018). |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 32/2018-Central Tax, dated 10.08.2018 as amended vide notification No. 37/2018-Central Tax, dated 24.08.2018. | It extends the time limit for furnishing the details of outward supplies in FORM GSTR-I in case of those registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year for each of month from July, 2018 to March, 2019 till $11^{\text {th }}$ of succeeding month. | Superceded <br> (vide <br> notification No. 44/2018- <br> Central Tax, dated <br> 10.09.2018). |
|  |  | Notification No. 44/2018-Central Tax, dated 10.09.2018 as amended vide notification No. 63/2018-Central Tax, dated 29.11.2018; No. 72/2018-Central Tax, dated 31.12.2018; and No. 17/2019-Central Tax, dated 10.04.2019 | It extends the time limit for furnishing the details of outward supplies in FORM GSTR-I in case of those registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year for each of month from July, 2017 to Feb, 2019 to 31.03.2019. It also extended due date for filing FORM GSTR-1 for March, 2019 till 13 ${ }^{\text {th }}$ April, 2019. |  |
|  |  | Notification No. 12/2019-Central Tax, dated 07.03.2019 as amended vide notification No. 23/2019-Central Tax, dated 11.05.2019. | It extends the time limit for furnishing the details of outward supplies in FORM GSTR-I in case of those registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year for each of month from April, 2019 to June, 2019 to $11^{\text {th }}$ of the succeeding month. It also extended time limits for filing FORM GSTR-1 for the month of April, 2019 to registered persons with principal place of business located in certain specified districts of Orissa to $10^{\text {th }}$ June, 2019. |  |
|  |  | Notification No. 28/2019-Central Tax, dated 28.06.2019 as amended vide notification No. 53/2017-Central Tax, dated 14.11.2019 (w.e.f. 11.08.2019); No. 57/2019-Central Tax, dated 26.11.2019 (w.e.f. 15.11.2019); No. 63/2019Central Tax, dated 12.12.2019 (w.e.f. 30.11.2019); and No. 23/2020-Central Tax, dated 23.03.2020 (with retrospective effect from 20.12.2019). | It extended the time limit for furnishing the details of outward supplies in FORM GSTR-I in case of those registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year for each of month from July, 2019 to September, 2019 to $11^{\text {th }}$ of the succeeding month. <br> It extended due date for furnishing FORM GSTR-1 for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir, by such class |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | of registered persons having aggregate turnover of more than 1.5 crore rupees in the preceding financial year or current financial year, for each of the months from July, 2019 to September, 2019 till 24th March, 2020 (Ref: First proviso to paragraph 1). |  |
|  |  | Notification No. 46/2019-Central Tax, dated 09.10.2019 as amended vide notification No. 58/2019-Central Tax, dated 26.11.2019 (w.e.f. 11.11.2019); No. 64/2019-Central Tax, dated 12.12.2019 (w.e.f. 30.11.2019); No. 76/2019Central Tax, dated 26.12.2019 (w.e.f. 11.12.2019); and No. 22/2020-Central Tax, dated 23.03.2020 (with retrospective effect from 20.12.2019). | It extends the time limit for furnishing the details of outward supply of goods or services or both in FORM GSTR-1 for the registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year and it also prescribes the time period for filing quarterly return in GSTR-1 for each of the months from Oct, 2019 to March, 2020. <br> It extended the time limit for furnishing the details of outward supply of goods or services or both in FORM GSTR-1 for the registered persons (having aggregate turnover exceeding Rs. 1.5 crores in the preceding FY or the current FY) with principal place of business in the State of Jammu and Kashmir for the month of October, 2019 till 30.11.2019. <br> It further extended the time limit for furnishing the details of outward supply of goods or services or both in FORM GSTR-1 for the registered persons (having aggregate turnover exceeding Rs. 1.5 crores in the preceding FY or the current FY) with principal place of business in the State of Jammu and Kashmir for the month of October, 2019 till 20.12.2019 (Ref: first proviso to paragraph 1); <br> It extended the time limit for furnishing the details of outward supply of goods or services or both in FORM GSTR-1 for the registered persons (having aggregate turnover exceeding Rs. 1.5 crores in the preceding FY or the current FY) with principal place of business in the State of Assam, Manipur or Tripura for the month of November, 2019 till 31.12.2019 (Ref: second proviso to paragraph 1); <br> It extended the due date for furnishing FORM GSTR-1 | [issued under second proviso to section 37(1) of the CGST Act, 2017.] |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir, and having aggregate turnover of more than 1.5 crore rupees in the preceding financial year or current financial year, for the month of October, 2019 and November, 2019 to February till 24th March, 2020. |  |
|  |  | Notification No. 25/2022-Central Tax, dated 13.12.2022 |  |  |
|  |  | Circular No. 7/7/2017-GST, dated 01.09.2017 | System based Reconciliation of Information Furnished in FORM GSTR-1 and FORM GSTR-2 with FORM GSTR-3BReg. |  |
|  |  | Circular No. 15/15/2017-GST, dated 06.11.2017 | Due date for Generation of FORM GSTR-2A and FORM GSTR-1A in accordance with extension of due date for filing FORM GSTR-1 and GSTR-2 respectively. |  |
|  |  | Circular No. 89/08/2019-GST, dated 18.02.2019 | Clarification on Mentioning details of Inter-State supplies made to unregistered persons in Table 3.2 of FORM GSTR-3B and Table 7B of FORM GSTR-1. |  |
| Section 38 <br> (*substituted vide <br> finance Act, 2022); | Communication of details of inward supplies and input tax credit. |  |  |  |
|  |  | Notification No. 19/2017-Central Tax, dated 08.08.2017 (effective from 08.08.2017) | It extended the time limit for furnishing the details in FORM GSTR-2 for the months of July, 2017 and August, 2017. | Superceded notification No. 29/2017Central Tax, dated 05.09.2017). | (vide 29/2017- <br> dated |
|  |  | Notification No. 29/2017-Central Tax, dated 5.09.2017. | It superseded notification Nos. 18/2017-Central Tax, dated 08.08.2017, 19/2017-Central Tax, dated 08.08.2017 and 20/2017-Central Tax, dated 08.08.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 returns for the month of July, 2017 and August, 2017. | Superceded <br> notification No. 30/2017Central Tax, <br> 05.09.2017). | vide <br> dated |
Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 30/2017-Central Tax, dated 11.09.2017 as amended vide notification No. 54/2017-Central Tax, 30.10.2017. | It superseded notification No. 29/2017-Central Tax, dated 05.09.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 Returns for the month of July, 2017 for specified class of taxable/ registered person. | Superceded <br> notification No. 58/2017Central Tax, dated 15.11.2017). |
| Section 39 | Furnishing of Returns | Notification No. 20/2017-Central Tax, dated 08.08.2017 [effective from 08.08.2017] | It extended due date for furnishing the monthly return GSTR-3 for the month of July and August, 2017. | Superceded <br> notification No. 29/2017Central <br> dated05.09.2017). |
|  |  | Notification No. 25/2017-Central Tax, dated 28.08.2017 | It extended time limit for furnishing the monthly return by person supplying Online Information and data base access or retrieval services from a place outside India to a non-taxable person online recipient | Superceded <br> notification No. 42/2017Central Tax, dated 13.10.2017). |
|  |  | Notification No. 42/2017-Central Tax, dated 13.10.2017 [effective from 15.09.2017] | It superceded the notification No. 25/2017-Central Tax, dated 28.08.2017 and further extended the time limit for filing FORM GSTR-5A return by person supplying Online Information and data base access or retrieval services from a place outside India to a non-taxable person online recipient for the month of July, august and September, 2017. | Superceded <br> notification No. 61/2017Central Tax, dated 15.11.2017). |
|  |  | Notification No. 61/2017-Central Tax, dated 15.11.2017. | It superceded the notification No. 42/2017-Central Tax, dated 13.10.2017 and further extended the time limit for filing FORM GSTR-5A return by person supplying Online Information and data base access or retrieval services from a place outside India to a non-taxable person online recipient for the month of July, August, September, 2017 and October, 2017 till 15.12.2017. | Superceded <br> notification No. 69/2017Central Tax, dated 21.12.2017). |
|  |  | Notification No. 69/2017-Central Tax, dated 21.12.2017 | It superseded notification No. 61/2017-Central Tax, dated 15.11.2017 and extended the time limit for filing FORM GSTR-5A for months from July, 2017 to December, 2017 till 31.01.2018. |  |
|  |  | Notification No. 26/2017-Central Tax, dated | It extended time limits for filing FORM GSTR-6 Return | Superceded <br> (vide |
Compiled by the GSTINDIAPATHWAY,ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 28.08.2017. | by Input Service Distributor for the month of July and August, 2017. | ![img-1.jpeg](img-1.jpeg.png) |
|  |  | Notification No. 31/2017-Central Tax, dated 11.09.2017 | It superseded notification No. 26/2017-Central Tax, dated 28.08.2017 and further extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July and August, 2017 | Superceded <br> notification No. 43/2017Central Tax, dated 13.10.2017). |
|  |  | Notification No. 43/2017-Central Tax, dated 13.10.2017. | It superseded notification No. 31/2017-Central Tax, dated 11.09.2017 and extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July, August and September, 2017 till 15.11.2017. | Superceded <br> notification No. 62/2017Central Tax, dated |
|  |  | Notification No. 62/2017-Central Tax, dated 15.11.2017. | It superseded the notification No. 43/2017-Central Tax, dated 13.10.2017 and extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July, 2017 till 31.12.2017. | Superceded <br> notification No. 8/2018Central Tax, dated 23.01.2018). |
|  |  | Notification No. 8/2018-Central Tax, dated 23.01.2018. | It extended the time limit for furnishing the return by an ISD in the FORM GSTR-6 for the month of July, 2017 to February, 2018 to 31.03.2018. It superseded the notification No. 62/2017-Central Tax, dated 15.11.2017. | Superceded <br> notification No. 19/2018Central Tax, dated 28.03.2018). |
|  |  | Notification No. 19/2018-Central Tax, dated 28.03.2018 | It superseded the notification No. 08/2018-Central Tax, dated 23.01.2018 and extended the time limit for furnishing FORM GSTR-6 returns for the month of July 2017 to April, 2018 till 31.05.2018 | Superceded <br> notification No. 25/2018Central Tax, dated 31.05.2018). |
|  |  | Notification No. 25/2018-Central Tax, dated 31.05.2018. | It superseded the notification No. 19/2018-Central Tax, dated 28.03.2018 and extended the time limit for furnishing FORM GSTR-6 returns by ISD for the month of July 2017 to June, 2018 till 31.07.2018. | Superceded <br> notification No. 30/2018Central Tax, dated 31.05.2018. |
|  |  | Notification No. 30/2018-Central Tax, dated 30.07.2018. | It superseded notification No. 25/2018-Central Tax, dated 31.05.2018 and extended the time limit for furnishing FORM GSTR-6 for the period from July 17 to August, 2018 till 30.09.2018. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 41/2017-Central Tax, dated 13.10.2017 as amended vide notification no. 59/2017-Central Tax, dated 15.11.2017 | It extended the time limit for furnishing the Return in FORM GSTR-4 by a composition Supplier for the quarter July to September, 2017 till 24.12.2017. |  |
|  |  | Notification No. 65/2018-Central Tax, dated 29.11.2018 | It extended the time limit for furnishing the return in FORM GSTR-4 for the quarter July -September, 2017 by registered person having their principal place of Business in Srikakulam District of Andhra Pradesh till 30.11.2018. |  |
|  |  | Notification No. 60/2017-Central Tax, dated 15.11.2017 | It extended the time limit for filing FORM GSTR-5 for the month of July, 17 to October, 2017 till 11.12.2017. | $\begin{array}{\|l\|} \hline \text { Superceded } \\ \text { notification No. 68/2017- } \\ \text { Central Tax, dated } \\ \text { 21.12.2017). } \end{array}$ |
|  |  | Notification No. 68/2017-Central Tax, dated 21.12.2017 | It superceded notification No. 60/2017-Central Tax, dated 15.11.2017 and extended the time limit for filing FORM GSTR-5 for months from July, 2017 to December, 2017 till 31.01.2018. |  |
|  |  | Notification No. 66/2018-Central Tax, dated 29.11.2018as amended vide notification No.07/2019-Central Tax, dated 31.01.2019. | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person for the months from Oct, 2018 to December, 2018 till $28^{\text {th }}$ of February, 2019. | Superceded <br> notification No. 26/2019- <br> Central Tax, dated 28.06.2019. |
|  |  | Notification No. 08/2019-Central Tax, dated 08.02.2019. | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person required to Deduct tax at source under Section 51 of the CGST Act, 2017 for the month of January, 2019 till $28^{\text {th }}$ of February, 2019. | Superceded <br> notification No. 26/2019- <br> Central Tax, dated 28.06.2019. <br> Issued under Section 39(6) read with section 168 of the CGST Act, 2017 and rule 66 of the CGST Rules, 2017. |
|  |  | Notification No. 18/2019-Central Tax, dated 10.04.2019 | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person required to Deduct tax at source under Section 51 of the CGST Act, 2017 for the month of March, 2019 till $12^{\text {th }}$ of April, 2019. | Superceded <br> notification No. 26/2019- <br> Central Tax, dated 28.06.2019. |
|  |  | Notification No. 26/2019-Central Tax, dated 28.06.2019 as amended vide notification No. | - It extended the time limit for furnishing FORM GSTR-7 Return by a registered person required |  |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 54 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 40/2019-Central Tax, dated 31.08.2019; No. 55/2019-Central Tax, dated 14.11.2019 (w.e.f. 20.09.2019); No. 59/2019-Central Tax dated 26.11.2019 (w.e.f. 10.11.2019); No. 65/2019-Central Tax, dated 12.12.2019 (w.e.f. 30.11.2019); No. 78/2019-Central Tax, dated 26.12.2019 (w.e.f. 10.12.2019); No. 20/2020-Central Tax, dated 23.03.2020 (with retrospective effect from 20.12.2019); No. 13/2023-Central Tax, dated 24.05.2023 (w.e.f. 10.05.2023); No. 16/2023Central Tax, dated 19.06.2023 (w.e.f. 31.05.2023); No. 21/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023); and No. 44/2023-Central Tax, dated 25.08.2023 (w.e.f. 31.07.2023) | to Deduct tax at source under Section 51 of the CGST Act, 2017 for the period of October, 2018 to July, 2019 till 31st August, 2019. <br> - Extended the time limit for filing FORM GSTR-7 for the months of July, 2019 to October, 2019 for taxpayers with principal place of business in the state of Jammu \& Kashmir (Ref: third proviso to paragraph 1) <br> - Extended the time limit for filing FORM GSTR-7 for the month of November, 2019 for taxpayers with principal place of business in the state of Assam, Manipur or Tripura (Ref: fourth proviso to paragraph 1); <br> - Extended due date for furnishing FORM GSTR-7 for those taxpayers whose principal place of business is in the erstwhile State of Jammu and Kashmir for the July, 2019 to October,2019 and November, 2019 to February, 2020. (Ref: second and third proviso of paragraph 1). <br> - Extended the time limit for filing FORM GSTR-7 for the month of April, 2023, May, 2023, June, 2023; and July 2023 till 25.08.2023 for taxpayers with principal place of business in the state of Manipur (Ref: fifth proviso to paragraph 1); |  |
|  |  | Notification No. 05/2022-Central Tax, dated 17.05.2022 | It extended the time limit for furnishing the return in FORM GSTR-3B for the month of April, 2022 to 24.05.2022. |  |
|  |  | Notification No. 84/2020-Central Tax, dated 10.11.2020 | It notifies class of persons under proviso to Section 39(1) read with proviso to section 39(7). It allows the registered persons (other than a person under section 14 of the IGST Act, 2020) having turnover of upto Rs. 5 crores in preceding FY and have opted to file return for every quarter with monthly payment of taxes subject to fulfillment of conditions specified therein. | It relates to Quarterly Return filing and monthly payment of taxes (QRMP) Scheme. |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 55 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 85/2020-Central Tax, dated 10.11.2020 (w.e.f. 01.01.2021) | It notifies special procedure for making payment of $35 \%$ as tax liability in first two months (under QRMP Scheme). | Also issued under section 148 of the CGST Act, 2017. |
|  |  | Notification No. 06/2022-Central Tax, dated 17.05.2022 | It extended the due date for depositing the tax due under proviso to sub-section (7) of section 39 of the CGST Act, 2017 in FORM GST PMT-06 for the month of April, 2022 till 27.05.2022. |  |
|  |  | Notification No. 21/2022-Central Tax, dated 21.10.2022. | It extended the due date for furnishing the FORM GSTR3B Return under section 39(1) for the month of September, 2022 till 21.10.2022. |  |
|  |  | Notification No. 12/2023-Central Tax, dated 24.05.2023 (w.e.f. 20.05.2023) as amended vide notification No. 15/2023-Central Tax, dated 19.06.2023 (w.e.f. 31.05.2023); No. 19/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023); and No. 42/2023-Central Tax, dated 25.08.2023 (w.e.f. 31.07.2023) | It extended the due date of filing FORM GSTR-3B for the month of April, 2023, May 2023, June 2023 and July, 2023 till 25.08.2023 for registered person whose principal place of business is in the State of Manipur and are required to file return under section 39(1) read with rule 61(1) (clause (i)). |  |
|  |  | Notification No. 17/2023-Central Tax, dated 27.06.2023 (w.e.f. 20.06.2023). | It extended the due date of filing FORM GSTR-3B for the month of May, 2023 till 30.06.2023 for registered person whose principal place of business is in the Districts of Kutch, Jamnagar, Morbi, Patan, and Banaskantha in the State of Gujarat and are required to file return under section 39(1) read with rule 61(1) (clause (i)). |  |
|  |  | Notification No. 20/2023-Central Tax, dated 17.07.2023 as amended vide notification No. 43/2023-Central Tax, dated 25.08.2023 (w.e.f. 31.07.2023) | It extended the due date of filing FORM GSTR-3B for the Quarter ending June, 2023 till 25.08.2023 for registered person whose principal place of business is in the State of Manipur and are required to file return under section 39(1) read with rule 61(1) (clause (ii)). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 55/2023-Central Tax, dated 20.12.2023 | It extended the due date of filing FORM GSTR-3B for the month of November, 2023 till 27.12.2023 for registered person whose principal place of business is in the districts of Chennai, Tiruvallur, Chengalpattu and Kancheepuram in the State of Tamil Nadu and are required to file return under section 39(1) read with rule 61(1) (clause (ii)). |  |
|  |  | Notification No. 1/2024-Central Tax, dated 05.01.2024 (w.e.f. 20.12.2023). | It extended the due date of filing FORM GSTR-3B for the month of November, 2023 till 10.01.2024 for registered person whose principal place of business is in the districts of Tirunelveli, Tenkasi, Kanyakumari, Thoothukudi, and Virudhunagar in the State of Tamil Nadu and are required to file return under section 39(1) read with rule 61(1) (clause (ii)). |  |
|  |  | Circular No. 143/1/2020-GST, dated 10.11.2020. | It deals with Quarterly Return Monthly Payment Scheme and explains legislative changes and procedures. | QRMP Scheme. |
|  |  | Circular No. 170/02/2022-GST, dated 6.7.2022 | Mandatory furnishing of correct and proper information of inter-State supplies and amount of ineligible/ blocked Input Tax Credit and reversal thereof in return in FORM GSTR-3B and statement in FORM GSTR-1. |  |
| Section 40 | First Return |  |  |  |
| Section 41 <br> [Substituted vide <br> Finance Act, 2022]: | Availment of input tax credit. |  |  |  |
| Section 42 | Matching, reversal and reclaim of input tax credit. |  |  |  |
| Section 43 | Matching, reversal and reclaim of reduction in output tax liability |  |  |  |
| Section 43A | Procedure for furnishing |  |  |  |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| [Effective Date is yet to be notified] | return and availing input tax credit. |  |  |  |
| Section 44 | Annual Return | Rule 80 of the CGST Rules, 2017 | FORM GSTR-9, 9A, 9B and 9C. |  |
|  |  | The CGST (Removal of Difficulties) Order No. 1/2018-Central Tax, dated 11.12.2018 as amended vide Order No. 03/2018-Central Tax, dated 31.12.2018. | It was issued to remove the difficulties in respect of provision of section 44 of the CGST Act, 2017 so as to extend the date of filing of Annual Return in FORM GSTR -9, 9A and 9C for the year 2017-18 till 30.06.2019. |  |
|  |  | The CGST (Removal of Difficulties) Order No. 6/2019-Central Tax, dated 28.06.2019. | It allows filing of Annual Return for the period from 01.07.2017 to 31.03.2018 till 31.08.2019 for all registered persons other than Input Service Distributor, a person paying tax under section 51 or section 52, a casual taxable person and a non-resident taxable person. |  |
|  |  | The CGST (Removal of Difficulties) Order No. 7/2019-Central Tax, dated 26.08.2019. | It allowed filing of Annual Return for all registered persons other than Input Service Distributor, a person paying tax under section 51 or section 52, a casual taxable person and a non-resident taxable person for the period from 01.07.2017 to 31.03.2018 till 30.11.2019. |  |
|  |  | The CGST (Removal of Difficulties) Order No. 8/2019-Central Tax, dated 14.11.2019. | It allowed filing of Annual Return for all registered persons other than Input Service Distributor, a person paying tax under section 51 or section 52, a casual taxable person and a non-resident taxable person for the period from 01.07.2017 to 31.03.2018 till 31.12.2019 and the annual return for the period from 01.04.2018 to 31.03.2019 till 30.03.2020. |  |
|  |  | The CGST (Removal of Difficulties) Order No. 10/2019-Central Tax, dated 26.12.2019. | It allowed It allowed filing of Annual Return for all registered persons other than Input Service Distributor, a person paying tax under section 51 or section 52, a casual taxable person and a non-resident taxable person for the period from 01.07.2017 to 31.03.2018 till 30.01.2020. |  |
|  |  | Notification No. 6/2020-Central Tax, dated 03.02.2020 | It extends the time limit for furnishing of the annual Return electronically through the common portal, in respect of the period from the 1st July, 2017 to the 31st March, 2018, in staggered manner. |  |
|  |  | Notification No. 09/2020-Central Tax, dated | It notified foreign company which is an airlines company |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 16.03.2020 | covered under the notification issued under sub-section (1) of section 381 of the Companies Act, 2013 (18 of 2013) and who have complied with the sub-rule (2) of rule 4 of the Companies (Registration of Foreign Companies) Rules, 2014, as the class of registered persons who shall not be required to furnish reconciliation statement in FORM GSTR-9C to the CGST Rules, 2017 under subsection (2) of section 44 of the said Act read with sub-rule (3) of rule 80 of the said rules subject to fulfillment of conditions specified therein. |  |
|  |  | Notification No. 15/2020-Central Tax, dated 23.03.2020. | It extended the time limit for furnishing of the annual return specified under section 44 of the said Act read with rule 80 of the said rules, electronically through the common portal, for the financial year 2018-2019 till 30.06.2020. | [r/wrule 80 of the CGST <br> Rules, 2017] [Superceded <br> vide notification No. <br> 41/2020-Central Tax, dated <br> 05.05.2020] |
|  |  | Notification No. 41/2020-Central Tax, dated 05.05.2020 as amended vide notification No. 69/2020-Central Tax, dated 30.09.2020; and No. 80/2020-Central Tax, dated 28.10.2020. | It extended the time limit for furnishing of the annual return specified under section 44 of the said Act read with rule 80 of the said rules, electronically through the common portal, for the financial year 2018-2019 till 30.12.2020. | [r/w rule 80 of the CGST <br> Rules, 2017] |
|  |  | Notification No. 95/2020-Central Tax, dated 30.12.2020 as amended vide notification No. 04/2021-Central Tax, dated 28.02.2021. | It extended the time limit for furnishing of the annual return specified under section 44 for FY 2019-20 till 28.02.2021 and which was further extended up to 31.03.2021. | [r/w rule 80 of the CGST <br> Rules, 2017] |
|  |  | Notification No. 31/2021-Central Tax, dated 30.07.2021 (w.e.f. 01.08.2021). | It exempts the registered person whose aggregate turnover in the FY 2020-21 is up to Rs. 2 Cr., from filing annual return for the FY 2020-21. | Issued under first proviso to Section 44. |
|  |  | Notification No. 10/2022-Central Tax, dated 05.07.2022 | It exempts the registered person whose aggregate turnover in the FY 2021-22 is up to Rs. 2 Cr., from filing annual return for the FY 2021-22. | Issued under first proviso to Section 44. |
|  |  | Notification No. 32/2023-Central Tax, dated 31.07.2023 | It exempts the registered person whose aggregate turnover in the FY 2022-23 is up to Rs. 2 Cr., from filing annual return for the FY 2022-23. | Issued under first proviso to Section 44. |
|  |  | Notification No. 14/2024-Central Tax, dated | It exempts the registered person whose aggregate | Issued under first proviso |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 59 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 10.07.2024 | turnover in the FY 2023-24 is up to Rs. 2 Cr., from filing annual return for the FY 2023-2024. | to Section 44. |
| Section 45 | Final Return | Rule 61 of the CGST Rules, 2017 | FORM GSTR-10 |  |
|  |  | Notification No. 58/2018-Central Tax, dated 26.10.2018 | It notifies the persons whose registration has been cancelled on or before 30.09.2018, as a Class of persons to furnish FORM GSTR-10 till 31.12.2018. | Also issued under section 148 of the CGST Act, 2017. |
| Section 46 | Notice to return defaulters. |  |  |  |
|  |  | Circular No. 129/48/2019-GST, dated 24.12.2019 | Standard Operating Procedure to be followed in case of non-filers of Returns-Reg. | Issued under section 168 of the CGST Act, 2017. |
| Section 47 | Levy of late fee |  |  |  |
| Section 48 | Goods and Services tax practitioners | Rule 83 to Rule 84 (including 83A and 83B) of the CGST Rules, 2017. | FORM GST PCT-01 to FORM GST PCT-05 |  |
|  |  | Notification No. 24/2018-Central Tax, dated 28.05.2018. | It notified the National Academy of Customs, Indirect Taxes and Narcotics as the authority to conduct the examination for GST Practitioner. |  |
|  |  | Circular No. 9/9/2017, dated 18.10.2017 | It authorized certain officers for the purpose of enrolling or rejecting application for enrolment of GST Practitioners. |  |
| CHAPTER X - PAYMENT OF TAX |  | Rule 85 to Rule 88 of the CGST Rules, 2017. | FORM GST PMT-01 to FORM GST PMT-07 |  |
| Section 49 | Payment of tax, interest, penalty and other documents. |  |  |  |
| Section 49A [inserted w.e.f. 01.02.2019] | Utilization of input tax credit subject to certain conditions. | Circular No. 98/17/2019-GST, dated 23.04.2019 | Clarification in respect of utilization of input tax credit under GST-Reg. |  |
| Section 49B [inserted w.e.f. 01.02.2019] | Order of utilization of input tax credit. |  |  |  |
| Section 50 | Interest on delayed payment of tax | Notification No. 13/2017-Central Tax, dated 28.6.2017 as amended vide notification No. 31/2020-Central Tax, dated 03.04.2020 (w.e.f. | It, inter alia, notifies rates of interest payable under Section 50 (1) and under Section 50 (3) of the CGST Act, 2017. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 20.03.2020); No. 51/2020-Central Tax, dated 24.06.2020; No. 08/2021-Central Tax, dated 01.05.2021 (with effect from 18.04.2021); and No. 18/2021-Central Tax, dated 01.06.2021 (w.e.f. 18.05.2021). |  |  |
|  |  | Notification No. 08/2022- Central Tax, dated 07.06.2022. | It notified rate of interest per annum to be 'Nil', for the class of registered persons (specified e-commerce operators) who failed to furnish the statement in FORM GSTR-8 by due date for the months of September, 2020; October, 2020; November, 2020; December, 2020 and January, 2021. | r/w section 148 of the CGST Act, 2017. |
|  |  | Notification No. 07/2024-Central Tax, dated 08.04.2024 | It provided waiver of interest for specified taxpayers for specified tax period. |  |
|  |  | Circular No. 192/04/2023-GST, dated 17.07.2023 | Clarification on charging of interest under section 50(3) of the CGST Act, 2017 in cases of wrong availment of IGST Credit and reversal thereof. |  |
| Section 51 | Tax Deduction at Source | Notification No. 50/2018-Central Tax, dated 13.09.2018 as amended vide notification No. 57/2018 - Central Tax, dated 23.10.2018; notification No. 61/2018-Central Tax, dated 05.11.2018; and last amended vide notification No. 73/2018-Central Tax, dated 31.12.2018. | It brought into force the provisions of Section51 of the CGST Act, 2017 with effect from 1.10.2018. It also specified persons under clause (d) of sub-section (1) of Section 51 of the CGST Act, 2018. |  |
|  |  | Circular No. 65/39/2018-DOR, dated 14.09.2018 | It issued guidelines for Deductions and Deposits of TDS by the DDO under GST. |  |
|  |  | Circular No. 67/41/2018-DOR, dated 28.09.2018 | Modification to the Guidelines for Deductions and Deposits of TDS by the DDO under GST as clarified in Circular No. 65/39/2018-DOR, dated 14.09.2018. |  |
|  |  | Circular No. 198/10/2023-GST, dated 17.07.2023 | Clarification on issue pertaining to e-invoice | it clarifies on the issue of generation of e-invoice in cases of supplies made to Government Departments |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  |  | or establishment etc. registered solely for TDS purpose. |
| Section 52 | Collection of Tax at source | The CGST (Removal of Difficulties) Order No. 4/2018-Central Tax, dated 31.12.2018 as amended vide The CGST (Second Removal of Difficulties) Order No. 02/2019-Central Tax, dated 01.02.2019. | It inserted an explanation to the Sub-section (4) of Section 52 of the CGST Act, 2017 providing that due date for furnishing the statement under this sub-section for the months of October, November and December, 2018 shall be the $7^{\text {th }}$ February, 2019. |  |
|  |  | Notification No. 52/2018-Central Tax, dated 20.09.2018 as amended vide notification No. 15/2024-Central Tax, dated 10.07.2024 (w.e.f. 10.07.2024). | It notifies rate of 0.25 percent of the net value of intra-state supplies made through ECO (other than agent) by other suppliers where the consideration is collected by ECO, is to be collected as TCS by such ECO. |  |
|  |  | Circular No. 74/48/2018-GST, dated 05.11.2018 | Collection of Tax at Source by Tea Board of India. |  |
|  |  | Circular No. 194/06/2023-GST, dated 17.07.2023 | Clarification on TCS Liability under Section 52 of the CGST Act, 2017 in case of multiple E-commerce Operators in one Transaction |  |
| Section 53 | Transfer of Input Tax Credit. |  |  |  |
| Section 53A | Transfer of certain amounts [inserted vide Finance (No.2) Act, 2019 (with effect from 01.01.2020)]. |  |  |  |
| CHAPTER XI - REFUNDS |  | Rule 89 to Rule 97A of the CGST Rules, 2017. | FORM GST RFD-01 to FORM GST RFD-11 |  |
| Section 54 | Refund of Tax |  |  |  |
|  | Issued under clause (ii) of proviso to Section 54(3) of the CGST Act, 2017. | Notification No. 5/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017) as amended vide notification No. 29/2017-Central Tax (Rate), dated 22.09.2017; No. 44/2017-Central Tax | It notifies certain goods failing into specified tariff heading in respect of which refund of un-utilized input tax credit is not allowed where the credit has accumulated on account of inverted duty structure. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | (Rate), dated 14.11.2017 (effective from 15.11.2017); No. 20/2018-Central Tax (Rate), dated 26.07.2018; No. 09/2022-Central Tax (Rate), dated 13.07.2022 (w.e.f. 18.07.2022); and No. 20/2023Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). |  |  |
|  |  | Notification No. 15/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017); as amended vide No. 15/2023-Central Tax (Rate), dated 19.10.2023 (w.e.f. 20.10.2023). | It notifies that refund of un-utilized input tax credit is not allowed in case of supplies of services of construction of complex, building or a part thereof in specified situation. |  |
|  |  | Notification No. 13/2017-Central Tax, dated 28.6.2017 (effective 1.7.2017) as amended videnotification No. 31/2020-Central Tax, dated 03.04.2020 (w.e.f. 20.03.2020); No. 51/2020-Central Tax, dated 24.06.2020; No. 08/2021-Central Tax, dated 01.05.2021 (w.e.f. 18.04.2021); and No. 18/2021-Central Tax, dated 01.06.2021 (w.e.f. 18.05.2021). | It, interalia, notified @ $6 \%$ per annum as the rate of interest payable under Section 54(12) of the CGST Act, 2017 in case of delayed payment of refund. |  |
|  |  | Notification No. 37/2017-Central Tax, dated 04.10.2017. | It specified conditions and safeguards for furnishing a LUT in place of bond by registered person who intends to supply goods or services for export without payment of Integrated Tax. |  |
|  |  | Notification No. 16/2017-Central Tax, dated 01.07.2017 | It specified conditions and safeguards for furnishing a LUT in place of bond by registered person who intends to supply goods or services for export without payment of Integrated Tax. | Superceded [vide notification No. 37/2017Central Tax, dated 04.10.2017]. |
|  |  | Circular No. 8/8/2017-GST, dated 04.10.2017 as amended vide Circular No. 40/14/2018-GST, dated 06.04.2018; and Circular No. 88/07/2019GST, dated 01.02.2019 | Clarification on Issues related to furnishing of Bond/Letter of Undertaking for Exports. | Amended vide Circular No. 40/14/2018-GST, dated 06.04.2018]. |
|  |  | Circular No. 5/5/2017-GST, dated 11.08.2017 | Clarification on Issues related to furnishing of Bond/Letter of Undertaking for Exports | Rescinded (vide circular No. 8/8/2017-GST, dated 04.10.2017) |
|  |  | Circular No. 4/4/2017-GST, dated 07.07.2017 | Issues related to Bond/Letter of Undertaking for Exports without payment of integrated tax. | Rescinded (vide circular No. 8/8/2017-GST, dated |
| Compiled by the GSTINDIAPATHWAY,ORG Team |  |  |  | Page 63 of 127 |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  |  | 04.10.2017). |
|  |  | Circular No. 2/2/2017-GST, dated 04.07.2018 | Issues related to furnishing of Bond/Letter of Undertaking for Exports | Rescinded (vide Circular No. 8/8/2017-GST, dated 04.10.2017). |
|  |  | Other Circulars issued on Refunds |  |  |
|  |  | Circular No. 17/17/2017-GST, dated 15.11.2017 | Manual filing and processing of refund claim in respect of Zero-rated Supplies. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 18/18/2017-GST, dated 16.11.2017 | Clarification on refund of un-utilized input tax credit on GST paid on inputs in respect of exporter of Fabrics. |  |
|  |  | Circular No. 24/24/2017-GST, dated 21.12.2017 | Manual filing and processing of refund claims on account of inverted duty structure, deemed exports and excess balance in electronic cash ledger. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 37/11/2018-GST, dated 15.03.2018 | Clarifications on Export related Refund Issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 45/19/2018-GST, dated 30.05.2018 | Clarification on Refund Related Issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 48/22/2018-GST, dated 14.06.2018 | Clarification of Certain Issues Under GST. (Apart from issue of eligibility of independent fabric processors (Job-workers) for refund of unutilized Input Tax credit on account of inverted duty structure, it also clarifies on issue relating to supply of services to SEZ unit or developer under section 7 and 12 of the IGST Act, 2017). | Also clarifies on SEZ related issues. |
|  |  | Circular No. 56/30/2018-GST, dated 24.08.2018 | Clarification regarding removal of restriction of refund of accumulated ITC on fabric-Reg. |  |
|  |  | Circular No. 59/33/2018-GST, dated 04.09.2018 | Clarification on Refund Related Issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 70/44/2018-GST, dated 26.10.2018 | Clarification on Certain Issues related to Refund. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 64 of 127
INDEX

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 78/52/2018-GST, dated 31.12.2018 | Clarification on export of services under GST |  |
|  |  | Circular No. 79/53/2018-GST, dated 31.12.2018 | It clarifies certain refund related issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 110/29/2019-GST, dated 03.10.2019 | Eligibility to file a refund application in FORM GST RFD01 for a Period and Category under which a NIL refund application has already been filed. |  |
|  |  | Circular No. 111/30/2019-GST, dated 03.10.2019 | Procedure to claim refund in FORM GST RFD-01 subsequent to Favourable Order in Appeal or Any other Forum-Reg. |  |
|  |  | Circular No. 125/44/2019-GST, dated 18.11.2019 | Fully Electronic Refund Process through FORM GST RFD-01 and Single Disbursement-Reg. | Amended vide Circular No. 135/05/2020-GST, dated 31.03.2020. |
|  |  | Circular No.135/05/2020 - GST, dated 31.03.2020. | Clarification on refund related issues |  |
|  |  | Circular No. 137/07/2020-GST, dated 13.04.2020. | Clarification in respect of certain challenges faced by the registered persons in implementation of provisions of GST Laws-reg. |  |
|  |  | Circular No. 139/09/2020-GST, dated 10.06.2020 | Clarification on Refund Related issues. |  |
|  |  | Circular No. 147/03/2021-GST, dated 12.03.2021 | Clarification on Refund Related Issues | It amended Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 160/16/2021-GST, dated 20.09.2021 read with corrigendum dated 24.09.2021. | Clarification in respect of Certain GST Related Issue-Reg (it clarified the issue of allowing refund of unutilized ITC in cases of export of goods where export goods is subjected to "NIL" rate of export duty). |  |
|  |  | Circular No. 162/18/2021-GST, dated 25.09.2021 | Clarification in respect of refund of tax specified in section 77(1) of the CGST Act and section 19(1) of the IGST Act. |  |
|  |  | Circular No. 166/22/2021-GST, dated 17.11.2021 | Clarification on Certain Refund Related Issues. |  |
|  |  | Circular No. 168/24/2021-GST, dated 30.12.2021 | Mechanism for filing of refund claim by the taxpayers registered in erstwhile Union Territory of Daman \& Diu for period prior to merger with UT of Dadra \& Nagar Haveli. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 172/04/2022-GST, dated 06.07.2022 | Clarification on various issue pertaining to GST. | It inter alia clarifies on the issue of refund claimed by the recipients of supplies regarded as deemed export. |
|  |  | Circular No. 173/05/2022-GST, dated 06.07.2022 | Clarification on issue of claiming refund under inverted duty structure where the supplier is supplying goods under some concessional notification. |  |
|  |  | Circular No. 174/06/2022-GST, dated 06.07.2022 | Prescribing manner of re-credit in electronic credit ledger using FORM GST PMT-03A |  |
|  |  | Circular No. 175/07/2022-GST, dated 06.07.2022 | Manner of filing refund of unutilized ITC on account of export of electricity- |  |
|  |  | Circular No. 181/3/2022-GST, dated 10.11.2022 | Clarification on refund related issues. |  |
|  |  | Circular No. 188/20/2022-GST, dated 27.12.2022 | Prescribing manner of filing an application for refund by un-registered persons. |  |
|  |  | Instruction No. 03/2022-GST, dated 14.06.2022 | Procedure relating to sanction, post audit and review of refund claims. |  |
|  |  | Instruction No. 04/2022-GST, dated 28.11.2022 | Manner of Processing and sanction of IGST Refunds, withheld in terms of clause (c) of sub-rule (4) of Rule 96, transmitted to the jurisdictional GST Authorities under sub-rule (5A) of rule 96 of the CGST Rules, 2017. |  |
|  |  | Circular No. 197/09/2023-GST, dated 17.07.2023 | Clarification on Refund Related issues. |  |
|  |  | Circular No. 226/20/2024-GST, dated 11.07.2024 | Mechanism for refund of additional integrated tax (IGST) paid on account of upward revision in price of the goods subsequent to exports-Reg. |  |
| Section 55 | Refund in Certain Cases |  |  |  |
|  |  | Notification No. 6/2017-Central Tax (Rate), date 28.06.2017 (w.e.f. 1.7.2017) | It specifies the Canteen Stores Department under the Ministry of Defense as a person who is entitled to claim a refund of $50 \%$ of the applicable central tax paid by it on all inward supplies of goods received by it for subsequent supply to Unit Run Canteen of Canteen Store Department (CSD) or the authorized customers of the CSD. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 16/2017-Central Tax (Rate), dated 28.06.2017 (w.e.f. 1.7.2017). | It specifies United Nations or a specified international organization or foreign diplomatic mission or consular post in India or diplomatic agents or career consular officers posted therein which shall be entitled to claim a refund of taxes paid on the notified supplies of goods or services received by them under CGST Act, 2017 subject to conditions mentioned in the notification. |  |
|  |  | Notification No. 11/2019-Central Tax (Rate), dated 29.06.2019 (w.e.f. 01.07.2019). | It specifies retail outlets established in the departure area of an international airport, beyond the immigration counters, making tax free supply of goods to an outgoing international tourist, as class of persons, entitled to claim refund of applicable central tax paid on inward supply of such goods. |  |
|  |  | Circular No. 36/10/2018-GST, dated 13.03.2018 | Processing of Refund Applications for UIN Entities. | Also see under Section 168 of the CGST Act, 2017. |
|  |  | Circular No. 43/17/2018-GST, dated 13.04.2018 | It dealt with queries regarding Processing of Refund Applications for UIN Agencies. |  |
|  |  | Circular No. 63/37/2018-GST, dated 14.09.2018 read with corrigendum dated 06.09.2019 and Circular No. 144/14/2020-GST, dated 15.12.2020. | Clarification regarding processing of refund claims filed by UIN entities and Waiver from recording of UIN on the invoices for the month of April 2020 to March, 21. |  |
|  |  | Circular No. 68/42/2018-GST, dated 05.10.2018 | Notification No. 16/2017-Central Tax (Rate), dated 28.06.2017 issued under the CGST Act, 2017to be applicable to for the purpose of refund under the GST (Compensation to States) Act, 2017. | [Issued with reference to refund of Compensation Cess to UN and specified international Organization). |
|  |  | Circular No. 60/34/2018-GST, dated 04.09.2018 | Processing of Refund Applications filed by Canteen Stores Department (CSD)-regarding. |  |
|  |  | Circular No. 75/49/2018-GST, dated 27.12.2018 | Guidelines for Processing of Applications for Financial Assistance under the Central Sector Scheme named "Seva BhojYojna" of the Ministry of Culture. |  |
|  |  | Circular No. 106/25/2019-GST, dated 29.06.2019 (w.e.f. 01.07.2019). | Refund of taxes paid on inward supply of indigenous goods by retail outlets established at departure area of the international airport beyond immigration counters when supplied to outgoing international tourist against foreign | Withdrawn ab-initio vide Circular No. 176/08/2022GST, dated 06.07.2022. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | exchange. |  |
| Section 56 | Interest on Delayed Refund. | Notification No. 13/2017-Central Tax, dated 28.6.2017 (effective 1.7.2017) as amended vide notification No.31/2020-CentralTax, dated 03.04.2020 (w.e.f. 20.03.2020); No. 51/2020-Central Tax, dated 24.06.2020; No. 08/2021-Central Tax, dated 01.05.2021 (w.e.f. 18.04.2021); and No. 18/2021-Central Tax, dated 01.06.2021 (w.e.f. 18.05.2021). | It, inter alia, specifies rate of interest payable under Section 56 and under proviso to Section 56 of the CGST Act, 2017. |  |
| Section 57 | Consumer Welfare Fund |  |  |  |
| Section 58 | Utilisation of Fund |  |  |  |
| CHAPTER XII - ASSESSMENT |  | Rule 98 to Rule 100 of the CGST Rules, 2017. | FORM GST ASMT-01 to FORM GST ASMT-18 |  |
| Section 59 | Self-Assessment |  |  |  |
| Section 60 | Provisional Assessment |  |  |  |
| Section 61 | Scrutiny of Returns |  |  |  |
|  |  | Instruction No. 02/2022-GST, dated 22.03.2022 | Standard operating procedure (SOP) for scrutiny of returns for FY 2017-18 and 18-19. |  |
|  |  | Instruction No. 02/2023-GST, dated 26.05.2023 | Standard operating procedure (SOP) for scrutiny of returns for FY 2019-20 onwards. |  |
| Section 62 | Assessment of non-filers of returns |  |  |  |
| Section 63 | Assessment of unregistered persons |  |  |  |
| Section 64 | Summary assessment in certain special cases. |  |  |  |
| CHAPTER XIII - AUDIT |  | Rule 101 to Rule 102 of the CGST Rules, 2017. | FORM GST ADT-01 to FORM GST ADT-04 |  |
| Section 65 | Audit by tax authorities |  |  |  |
| Section 66 | Special Audit |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| CHAPTER XIV - INSPECTION, <br> SEARCH, SEIZURE AND ARREST |  | Rule 139 to Rule 141 of the CGST Rules, 2017 | FORM GST INS-01 to FORM GST INS-05 |  |
| Section 67 | Power of inspection, search and seizure | Notification No. 27/2018-Central Tax, dated 13.06.2018 | It notifies the goods or class of goods which are allowed to be disposed of after seizure considering perishable or hazardous nature, depreciation in value with passage of time, constraints of storage space etc. |  |
|  |  | Instruction No. 01/2020-21/GST-Investigation, dated 02.02.2021 | Instructions/Guidelines regarding procedure to be followed during search Operation-Reg |  |
|  |  | Instruction No. 01/2022-23 (GST-Investigation), dated 25.05.2022 | Deposit of tax during the course of search, inspection or investigation. |  |
|  |  | Instruction No. 01/2024-GST(Inv.), dated 30.03.2024 | Guidelines for CGST Formations in maintaining ease of doing Business while engaging in investigation with regular taxpayers. |  |
| Section 68 | Inspection of goods in movement | Circular No. 41/15/2018-GST, dated 13.04.2018 as amended vide Circular No. 88/07/2019-GST, dated 01.02.2019. | It clarifies the procedure for interception of conveyances for inspection of goods in movement, and detention, release and confiscation of such goods and conveyancesReg. | Modified [vide Circular No. 49/23/2018-GST, dated 21.06.2018 and 49/23/2018GST, dated 21.06.2018]. |
|  |  | Circular No. 49/23/2018-GST, dated 21.06.2018 | Modification of the Procedure for Interception of Conveyances for Inspection of Goods in Movement, and Detention, Release and Confiscation of such goods and Conveyances, as clarified in Circular No. 49/23/2018-GST, dated 21.06.2018. | Modified [vide Circular No. 49/23/2018-GST, dated 21.06.2018]. |
|  |  | Circular No. 64/38/2018-GST, dated 14.09.2018 | Modification of the Procedure for Interception of Conveyances for Inspection of Goods in Movement, and Detention, Release and Confiscation of such goods and Conveyances, as clarified in Circular Nos. 41/15/2018GST, dated 13.04.2018 and 49/23/2018-GST, dated 21.06.2018. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 69 | Power to Arrest |  |  |  |
|  |  | Instruction No. 02/2022-23 (GST-INV) dated 17.08.2022 | Guidelines for Arrest and bail in relation to offences punishable under the CGST Act, 2017 |  |
| Section 70 | Power to summon persons to give evidence and produce documents. |  |  |  |
|  |  | Instruction No. 03/2022-23 (GST-INV), dated 17.08.2022 | Guidelines for issuance of Summons under Section 70 of the CGST Act, 2017 |  |
| Section 71 | Access to business premises |  |  |  |
| Section 72 | Officers to assist proper officers |  |  |  |
| CHAPTER XV - DEMANDS AND RECOVERY |  | Rule 142 to Rule 161 of the CGST Rules, 2017. | FORM GST DRC-01 to FORM GST DRC-25 |  |
| Section 73 | Determination of tax not paid or short paid or erroneously refunded or input tax credit wrongly availed or utilized for any reason other than fraud or any willfulmisstatement or suppression of facts. |  |  |  |
| Section 74 | Determination of tax not paid or short paid or erroneously refunded or input tax credit wrongly availed or utilized by reason of fraud or any willful-misstatement or suppression of facts. |  |  |  |
|  |  | Instruction No. 02/2021-22[ GST-Investigation]. | Issuance of SCN in time bound manner |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | dated 22.09.2021. |  |  |
|  |  | Circular No. 171/3/2022-GST, dated 06.07.2022 | Clarification on various issues relating to applicability of demand and penalty provisions under the Central Goods and Services Tax Act, 2017 in respect of transactions involving fake invoices |  |
|  |  | Instruction No 01/2023-GST, dated 4.05.2023 | Guidelines for Special All Indian Drive against Fake Registration. |  |
| Section 75 | General Provisions relating to determination of tax |  |  |  |
|  |  |  |  |  |
|  |  | Circular No. 185/17/2022-GST, dated 27.12.2022 | Clarification with regard to applicability of provisions of section 75(2) of CGST Act, 2017 and its effect on limitation. |  |
| Section 76 | Tax collected but not paid to Government |  |  |  |
| Section 77 | Tax wrongfully collected and paid to Central Government or State Government. |  |  |  |
| Section 78 | Initiation of recovery proceedings. |  |  |  |
| Section 79 | Recovery of tax |  |  |  |
|  |  | Instruction No. 01/2022-GST, dated 07.01.2022 | Guidelines for recovery proceedings under the provision of section 79 of the CGST Act, 2017 in cases covered under explanation to sub-section (12) of Section 75 of the CGST Act, 2017 |  |
|  |  | Instruction No. 01/2024-GST, dated 30.05.2024 | Guidelines for initiation of recovery proceedings before three months from the date of service of demand orderReg |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 224/18/2024-GST, dated 11.07.2024 | Guidelines for recovery of outstanding dues, in cases wherein first appeal has been disposed of, till Appellate Tribunal Comes into operation-Reg | Also refer to rule 142 of the CGST Rules, 2017. |
| Section 80 | Payment of tax and other amount in installments. |  |  |  |
| Section 81 | Transfer of property to be void in certain cases. |  |  |  |
| Section 82 | Tax to be first charge on property. |  |  |  |
| Section 83 | Provisional attachment to protect revenue in certain cases. | Rule 159 of the CGST Rule, 2017 | FORM DRC-22 to FORM DRC-23 |  |
|  |  | Instructions No. CBEC-20/16/05/2021-GST/359, dated 23.02.2021 | Guidelines for provisional attachment of Property under section 83 of the CGST Act, 2017 |  |
| Section 84 | Continuation and validation of certain recovery proceedings. |  |  |  |
| CHAPTER XVI - LIABILITY TO PAY IN CERTAIN CASES |  |  |  |  |
| Section 85 | Liability in case of transfer of business |  |  |  |
| Section 86 | Liability of agent and principal |  |  |  |
| Section 87 | Liability in case of amalgamation or merger of companies |  |  |  |
| Section 88 | Liability in case of company in liquidation |  |  |  |
| Section 89 | Liability of directors of private company |  |  |  |
| Section 90 | Liability of partners of firm to pay tax. |  |  |  |

Compiled by the GSTINDIAPATHWAY,ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 91 | Liability of guardians, trustees, etc. |  |  |  |
| Section 92 | Liability of Court of Wards, etc. |  |  |  |
| Section 93 | Special provisions regarding liability to pay tax, interest or penalty in certain cases. |  |  |  |
| Section 94 | Liability in other cases |  |  |  |
| CHAPTER XVII- ADVANCE <br> RULING |  | Rule 103 to Rule 107 A of the CGST Rules, 2017. | FORM GST ARA-01 to FORM GST ARA-03 |  |
| Section 95 | Definitions |  |  |  |
| Section 96 | Authority for advance ruling |  |  |  |
| Section 97 | Application for advance ruling | Circular No. 25/25/2017-GST, dated 21.12.2017 | Manual filing of applications for Advance Ruling and Appeals before Appellate Authority for Advance Ruling. |  |
| Section 98 | Procedure on receipt of application |  |  |  |
| Section 99 | Appellate Authority for Advance Ruling |  |  |  |
| Section 100 | Appeal to Appellate Authority | Circular No. 25/25/2017-GST, dated 21.12.2017 | Manual filing of applications for Advance Ruling and Appeals before Appellate Authority for Advance Ruling. |  |
| Section 101 | Orders of Appellate Authority |  |  |  |
| Section 101A | Constitution of National Appellate Authority for Advance Ruling [inserted vide Finance (No.2) Act, 2019 (with effect from 01.01.2020)]. |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 101B | Appeal to National Appellate Authority [inserted vide Finance (No.2) Act, 2019 (with effect from 01.01.2020)]. |  |  |  |
| Section 101C | Order of National Appellate Authority [inserted vide Finance (No.2) Act, 2019 (with effect from 01.01.2020)]. |  |  |  |
| Section 102 | Rectification of advance ruling |  |  |  |
| Section 103 | Applicability of advance ruling |  |  |  |
| Section 104 | Advance ruling to be void in certain circumstances |  |  |  |
| Section 105 | Power of Authority and Appellate Authority |  |  |  |
| Section 106 | Procedure of Authority and Appellate Authority |  |  |  |
|  |  |  |  |  |
| CHAPTER XVIII - APPEALS AND REVISION |  | Rule 108 to Rule 116 of the CGST Rules, 2017. | FORM GST APL-01 to FORM GST APL-08 |  |
| Section 107 | Appeals to Appellate Authority |  |  |  |
| Section 108 | Power of Revisional Authority |  |  |  |
| Section 109 | Constitution of Appellate Tribunal and Benches thereof. | Notification S.O 1359 (E), dated 13.03.2019 | It notified the creation of the National Bench of the Goods and Services Tax Appellate Tribunal (GSTAT) at new Delhi with effect from 13.03.2019. | Supercoded vide notification No. SO 1 (E), dated 29.12.2023. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification S. O. 3009 (E), dated 21.08.2019 | It notified the creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) with effect from 21.08.2019. | Superceded vide notification No. SO 4073 (E), dated 14.09.2023. |
|  |  | Notification S.O. 4332 (E), dated 29.11.2019. | It notified creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) in Rajasthan, Mizoram and Karnataka w.e.f. 29.11.2019. | Superceded vide notification No. SO 4073 (E), dated 14.09.2023. |
|  |  | Notification S. O. 4073 (E), dated 14.09.2023 | It notified the creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) with effect from 14.09.2023. | Superceded vide notification No. SO 3048 (E), dated 31.07.2024. |
|  |  | Notification No. SO 1 (E), dated 29.12.2023 | It constituted the Principal Bench of the Goods and Services Tax Appellate Tribunal (GSTAT) at new Delhi with effect from 29.12.2023. | Superceded vide notification No. SO 3048 (E), dated 31.07.2024. |
|  |  | Notification S.O. 3048 (E), dated 31.07.2024 | It notified the establishment of GST Appellate Tribunal with effect from 1.09.2024. <br> It also notified constitution of principal Bench of GSTAT at New Delhi and also constituted state benches of GSTAT in various states along with circuit benches. | It also superseded earlier notification No. notification No. SO 1 (E), dated 29.12.2023 and notification S. O. 4073 (E), dated 14.09.2023. |
| Section 110 | President and Members of Appellate Tribunal, their qualification, appointment, conditions of service, etc. |  |  |  |
| Section 111 | Procedure before Appellate Tribunal |  |  |  |
| Section 112 | Appeals to Appellate Tribunal |  |  |  |
|  |  | The Central Goods and Services Tax (Removal of Difficulties) Order No. 09/2019-Central Tax, dated 03.12.2019. | It extends the last date of filing of appeals before the GST Appellate Tribunal against the order of Appellate Authority on account of non-constitution of benches of appellate Tribunal. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | It now allows filing of appeals within the period of three months is considered out of the later of the dates on which the order sought to be appealed against is communicated to the person preferring the appeal or the date on which the President or the State President of the Appellate Tribunal after its constitution under section 109, enter office. Further, the period of six months from the date on which the said order has been passed, to be considered out of the later of the dates of date of communication of order or the date on which the President or the State President of the Appellate Tribunal after its constitution under section 109 enters officer |  |
|  |  | Circular No. 132/2/2020 - GST, dated 18.03.2020. | Clarification in respect of appeal in regard to nonconstitution of Appellate Tribunal |  |
|  |  | Circular No. 224/18/2024-GST, dated 11.07.2024 | Guidelines for recovery of outstanding dues, in cases wherein first appeal has been disposed of, till Appellate Tribunal Comes into operation-Reg |  |
| Section 113 | Orders of Appellate Tribunal |  |  |  |
| Section 114 | Financial and administrative powers of President |  |  |  |
| Section 115 | Interest on refund of amount paid for admission of appeal |  |  |  |
| Section 116 | Appearance by authorized representative |  |  |  |
| Section 117 | Appeal to High Court |  |  |  |
| Section 118 | Appeal to Supreme Court |  |  |  |
| Section 119 | Sums due to be paid notwithstanding appeal, etc. |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 120 | Appeal not to be filed in certain cases |  |  |  |
|  |  | Circular No. 207/1/2024-GST, dated 26.06.2024 | Reduction of Government Litigation- Fixing Monetary Limits for filing appeals or applications by the Department before GSTAT, High Courts and Supreme Court-Reg |  |
| Section 121 | Non-appealable decisions and orders |  |  |  |
| CHAPTER XIX - OFFENCES AND PENALTIES |  | Rule 162 of the CGST Rules, 2017. | FORM GST CPD-01 to FORM GST CPD-02. |  |
| Section 122 | Penalty for certain offences |  |  |  |
|  |  | Circular No. 171/03/2022-GST, dated 06.07.2022 | Clarification on various issues relating to applicability of demand and penalty provisions under the CGST Act, 2017 in respect of transactions involving fake invoice. |  |
| Section 123 | Penalty for failure to furnish information return |  |  |  |
| Section 124 | Fine for failure to furnish statistics |  |  |  |
| Section 125 | General Penalty |  |  |  |
| Section 126 | General disciplines related to penalty |  |  |  |
| Section 127 | Power to impose penalty in certain cases |  |  |  |
| Section 128 | Power to waive penalty or fee or both |  |  |  |
|  |  | Notification No. 28/2017-Central Tax, dated 01.09.2017 | It waived the late fee payable for all registered persons for failure to furnish the return in FORM GSTR-3B for the month of July, 2017 by due date. | Superceded <br> (vide notification No. 76/2018Central Tax, dated 31.12.2018) |
|  |  | Notification No. 50/2017-Central Tax, dated | It waived the amount of late fee payable by any registered | Superceded (vide |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 24.10.2017. | person for failure to furnish return in FORM GSTR-3B for the month of August and September, 2017 by due date. | notification No. 76/2018- <br> Central Tax, dated 31.12.2018) |
|  |  | Notification No. 64/2017-Central Tax, dated 15.11.2017 | It waived the amount of late fee payable by any registered person for failure to furnish return in FORM GSTR-3B for the month of October, 2017 by the due date in excess of Rs. 25/ day during the period of failure. However, wherever the tax payable is nil, then it has been waived in excess of Rs. 10/ day during the period of failure. | Superceded <br> notification No. 76/2018Central Tax, dated 31.12.2018) |
|  |  | Notification No. 76/2018-Central Tax, dated 31.12.2018 as amended vide notification No. 32/2020-Central Tax, dated 03.04.2020 (w.e.f. 20.03.2020); No. 52/2020-Central Tax, dated 24.06.2020; No. 57/2020-Central Tax, dated 30.06.2020 (w.e.f. 25.06.2020); No. 09/2021-Central Tax, dated 01.05.2021 (w.e.f. 20.04.2021); No. 19/2021-Central Tax, dated 01.06.2021 (w.e.f. 20.05.2021); and No. 33/2021-Central Tax, dated 29.08.2021. | It waived the amount of late fee payable by any registered person for failure to furnish return in FORM GSTR-3B for July, 2017 onwards by the due date in excess of Rs. 25/ day during the period of failure. However, wherever the tax payable is nil, then it has been waived in excess of Rs. 10/ day during the period of failure. Further, no late fee under section 47 is payable if any registered person who did not furnish return in FORM 3B for the period from July, 2017 to September, 2018, but furnishes such return between the period from 22.12.2018 to 31.03.2019. <br> It also waived the payment of late fee by any registered person for failure to furnish return in FORM GSTR-3B for the period from Feb, 2020 to July, 2020. <br> It also waive the payment of late fee by certain specified taxpayers for failure to furnish return in FORM GSTR-3B for the period of Jan, 21 to April, 21. (Ref: $8^{\text {th }}$ Proviso). <br> It also waived the payment of late fee in excess of Rs. 500/ by taxpayer who failed to furnish GSTR-3B return between July, 2017 to April, 2021 but files between 1.6.2021 to 30.11.2021 (Ref: $9^{\text {th }}$ Proviso). |  |
|  |  | Notification No. 73/2017-Central Tax, dated 29.12.2017 as amended vide notification No. 77/2018-Central Tax, dated 31.12.2018; No. | It waived the amount of late fee payable by any registered person for failure to furnish return in FORM GSTR-4 by due date under section 47 of the CGST Act, 2017 in excess |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 67/2020-Central Tax, dated 21.09.2020 (read with corrigendum); No. 93/2020-Central Tax, dated 22.12.2020; No. 21/2021-Central Tax, dated 01.06.2021; No. 07/2022-Central Tax, dated 26.05.2022; No. 12/2022-Central Tax, dated 05.07.2022; No. 02/2023-Central Tax, dated 31.03.2023; and No. 22/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023) | of Rs. 25/- for every day during the period of such failure or in excess of Rs. 10/- for every day. <br> It also provide conditional waiver from payment of late fee to registered person who failed to file FORM GSTR-4 return for the period from July, 2017 to March, 2019 by the due date but furnishes the said return during period from 22.09.2020 to 31.10.2020. <br> It waived the late fee payable for delay in furnishing of FORM GSTR-4 for FY 2019-20 for the period from 1.11.2020 to 31.12.2020 for registered person having principal place of business in UT of Ladakh. <br> It partially waived the late fee payable for delay in furnishing of FORM GSTR-4 for FY 2021-22 onwards by registered person. <br> It waived the late fee payable for delay in furnishing of FORM GSTR-4 for FY 2021-22 for the period from 01.05.2022 to 28.07.2022 ( $6^{\text {th }}$ proviso as amended). <br> It partially waived the late fee payable for delay in furnishing of FORM GSTR-4 for the quarters from July, 2017 to March, 2019 or for the FY 2019-20 to 2021-2022 onwards by registered person provided the same is furnished between 1.4.2023 to 31.08.2023 ( $7^{\text {th }}$ Proviso). |  |
|  |  | Notification No. 4/2018-Central Tax, dated 23.01.2018 as amended vide notification No. 75/2018-Central Tax, dated 31.12.2018; and No. 74/2019-Central Tax, dated 26.12.2019 (w.e.f. 19.12.2019); No. 4/2020-Central Tax, dated 10.01.2020;No. 33/2020-Central Tax, dated 03.04.2020; No. 53/2020-Central Tax, dated 24.06.2020.; and No. 20/2021-Central Tax, dated 01.06.2021. | - It waived the amount of late fee payable by any registered person for failure to furnish the details of outward supplies for any month/quarter in FORM GSTR-4 by due date under section 47 of the CGST Act, 2017 in excess of Rs. 25/- for every day during the period of such failure or in excess of Rs. 10 /every day during the period of such failure where there are no outward supplies in any month/quarter. Further, no late fee under section 47 is payable if any registered person who did not furnish return in |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | FORM GSTR-1 for the period from July, 2017 to September, 2018, but furnishes such details between the period from 22.12 .2018 to 31.03 .2019 . <br> - Waived the late fee payable under section 47 of the CGST Act, 2017 for registered person who failed to file details of outward supplies in FORM GSTR-1 for the months/quarter from July, 2017 to November, 2019 by the due date provided the taxpayer furnishes such details between 19.12 .2019 to 17.01.2020. <br> - Conditionally Waived the late fee payable under section 47 of the CGST Act, 2017 by the registered person for failure to file details of outward supplies in FORM GSTR-1 for the period from the month of March, April,May, and June, 2020 / or quarter ending on 30.06.2020. <br> - Partially waived the late fee payable under section 47 of the CGST Act, 2017 by the registered person for failure to file details of outward supplies in FORM GSTR-1 for the period June, 2021 onwards or quarter ending June, 2021 onwards. |  |
|  |  | Notification No. 5/2018-Central Tax, dated 23.01.2018. | It waived the amount of late fee payable by any registered person for failure to furnish the details of outward supplies for any month/quarter in FORM GSTR-5 by due date under section 47 of the CGST Act, 2017 in excess of Rs. 25/- for every day during the period of such failure or in excess of Rs. 10 /- every day during the period of such failure where there are no outward supplies in any month/quarter. |  |
|  |  | Notification No. 6/2018-Central Tax, dated 23.01.2018 | It waived the amount of late fee payable by any registered person for failure to furnish the details of outward supplies for any month/quarter in FORM GSTR-5A by | ![img-2.jpeg](img-2.jpeg.png) |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | due date under section 47 of the CGST Act, 2017 in excess of Rs. 25/- for every day during the period of such failure or in excess of Rs. 10 /- every day during the period of such failure where there are no outward supplies in any month/quarter | 23.01.2018). |
|  |  | Notification No. 7/2018-Central Tax, dated 23.01.2018. | It waived the amount of late fee payable by any registered person for failure to furnish the details of outward supplies for any month/quarter in FORM GSTR-6 by due date under section 47 of the CGST Act, 2017 in excess of Rs. 25/- for every day during the period of such failure. |  |
|  |  | Notification No. 22/2018-Central Tax, dated 14.05.2018 | It waived the late fee to be paid by those registered persons, whose GST-TRANS 1 was submitted but not filed on common portal on or before 27.12.2017, for late filing of GSTR-3 B return for the month of October, 2017 to April, 2018. The waiver is subject to condition that such registered person has filed GST TRANS-1 by 10.05.2018 and GSTR 3B return for each of such month by 31.05.2018. |  |
|  |  | Notification No. 41/2018-Central Tax, dated 04.09.2018. | It waived the late fee for certain specified classes of registered persons for delay in filing returns in FORM GSTR -3B, GSTR-4 and GSTR-6 for certain specified period. |  |
|  |  | Notification No. 41/2019-Central Tax, dated 31.08.2019 as amended vide notification No. 48/2019-Central Tax, dated 09.10.2019. | It waived the late fee for certain specified classes of registered persons for delay in filing FORM GSTR-1, and FORM GSTR-6 for the month of July, 2019. |  |
|  |  | Notification No. 68/2020-Central Tax, dated 21.09.2020 | It waived the late fee in excess of Rs. 250 for the registered persons who failed to furnish FORM GSTR-10 return by the due date, but furnishes the same between the period from 22.09.2020 to 31.12.2020. |  |
|  |  | Notification No. 42/2018-Central Tax, dated 04.09.2018 | It extends the time limit for making the declaration in FORM GST ITC-01 by specified class of registered person. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circulus/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 89/2020-Central Tax, dated 29.11.2020, as amended by notification No. 06/2021-Central Tax, dated 30.03.2021. | It grants waiver of penalty payable by any registered person under section 125 for non-compliance of provision of notification No. 14/2020-Central Tax, dated 21.03.2020 between the period from 01.12 .2020 to 30.06 .2021 subject to compliance from 1.7.2021. | Superceded by notification No. 28/2021-Central Tax, dated 30.06.2021 |
|  |  | Notification No. 28/2021-Central Tax, dated 30.06.2021 | It grants waiver of penalty payable by any registered person under section 125 for non-compliance of provision of notification No. 14/2020-Central Tax, dated 21.03.2020 between the period from 01.12 .2020 to 30.09 .2021 . |  |
|  |  | Notification No. 22/2021-Central Tax, dated 01.06.2021 | It waives the late fee payable under section 47 by TDS deductor for failure to furnish FORM GSTR-7 for the month of June, 2021 onwards in excess Rs. 25 / day during the period of failure subject to max of Rs. 1000/-. |  |
|  |  | Notification No. 07/2023-Central Tax, dated 31.03.2023 vide notification No. 25/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023) | It partially waives the late fee payable under section 47 to taxpayer who have failed to file return under section 44 (i.e. annual return) if the return is filed between 1.4.2023 to 31.08.2023. |  |
|  |  | Notification No. 08/2023-Central Tax, dated 31.03.2023 vide notification No. 26/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023) | It partially waives the late fee payable under section 47 to taxpayer who have failed to file FORM GSTR-10 return if the return is filed between 1.4.2023 to 31.08.2023 |  |
| Section 129 | Detention, seizure and release of goods and conveyances in transit. |  |  |  |
| Section 130 | Confiscation of goods or conveyances and levy of penalty |  |  |  |
| Section 131 | Confiscation or penalty not to interfere with other punishments. |  |  |  |
| Section 132 | Punishment for certain offences |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Instruction No. 04/2022-23 (GST-INV), dated 01.09.2022 | Guidelines for launching of prosecution under the CGST Act, 2017. |  |
| Section 133 | Liability of officers and certain other persons |  |  |  |
| Section 134 | Cognizance of offences |  |  |  |
| Section 135 | Presumption of culpable mental state. |  |  |  |
| Section 136 | Relevancy of statements under certain circumstances. |  |  |  |
| Section 137 | Offences by companies |  |  |  |
| Section 138 | Compounding of offences | Rule 162 of the CGST Rules, 2017. | FORM GST CPD-01 and FORM GST CPD-02. |  |
| CHAPTER XX- TRANSITIONAL PROVISIONS. |  | Rule 117 to Rule 121 of the CGST Rules, 2017. | FORM GST TRAN-1 to FORM GST TRAN-2 |  |
| Section 139 | Migration of existing taxpayers |  |  |  |
| Section 140 | Transitional arrangements for input tax credit | Circular No. 33/07/2018-GST, dated 23.02.2018 | Directions under Section 168 of the CGST Act regarding non-transition of CENAT Credit under section 140 of CGST Act or non-utilization thereof in certain cases. |  |
|  |  | Circular No. 58/32/2018-GST, dated 04.09.2018 as amended vide Circular No. 88/07/2019-GST, dated 01.02.2019. | Recovery of Arrears of Wrongly Availed CENVAT Credit under the Existing Law and Inadmissible Transitional Credit-Reg. |  |
|  |  | Circular No. 87/06/2019-GST, dated 02.01.2019 | Central Goods and Services Tax (Amendment) Act, 2018 Clarification regarding section 140(1) of the CGST Act, 2017 |  |
|  |  | Circular No. 180/12/2022-GST, dated 09.09.2022 | Guidelines for filing/revising TRAN-1/TRAN-2 in terms of order dated 22.07.2022 \& 02.09.2022 of Hon'ble Supreme Court in the case of Union of India vs. Filco Trade Centre Pvt. Limited. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 182/14/2022-GST, dated 10.11.2022 | Guidelines for verifying the Transitional Credit in the light of the order of the Hon'ble Supreme Court in the Union of India vs. Filco Trade Centre Pvt. Limited SLP (c) No. 32709-32710/2018, order dated 22.07.2022 \& 02.09.2022 |  |
| Section 141 | Transitional Provisions relating to job work |  |  |  |
| Section 142 | Miscellaneous <br> transitional Provisions |  |  |  |
|  |  | Circular No. 42/16/2018-GST, dated 13.04.2018 | Clarification regarding procedure for recovery of Arrears under the Existing Law and Reversal of inadmissible input tax Credit. |  |
| CHAPTER XXI - MISCELLANEOUS |  | Rule 138 to Rule 138C (E-way Rules) | FORM GST EWB-01 to FORM GST EWB-03 |  |
| Section 143 | Job work procedure | Circular No. 38/12/2018, dated 26.03.2018 as amended vide Circular No. 88/07/2019-GST, dated 01.02.2019 | Clarification on Issues Related to Job Work. |  |
| Section 144 | Presumption as to documents in certain cases. |  |  |  |
| Section 145 | Admissibility of micro films, facsimile copies of documents and computer printouts as documents and as evidence. |  |  |  |
| Section 146 | Common Portal | Notification No. 4/2017-Central Tax, dated 19.06.2017. | It notified www.gst.gov.in as the common Goods and Services Tax Electronic Portal for facilitating registration, payment of tax, furnishing of returns, computation and settlement of Integrated tax and electronic way bill. | Superceded <br> (vide notification No. 9/2018Central Tax, dated 23.01.2018). |
|  |  | Notification No. 9/2018-Central Tax, dated 23.01.2018. | It notified www.gst.gov.in as the common goods and Service Tax Electronic Portal for facilitating registration, payment of tax, furnishing of return and computation and |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | settlement of integrated tax and www.ewaybillgst.gov.in as the common goods and services tax Electronic Portal for furnishing electronic way bill. |  |
|  |  | Notification No. 69/2019-Central Tax, dated 13.12.2019 (w.e.f. 01.01.2020) | It notified the following as the Common Goods and Services Tax electronic Portal for the purpose of preparation of the e-invoice under rule 48(4) of the CGST Rules, 2017: <br> (i) www.einvoice1.gst.gov.in <br> (ii) www.einvoice2.gst.gov.in <br> (iii) www.einvoice3.gst.gov.in <br> (iv) www.einvoice4.gst.gov.in <br> (v) www.einvoice5.gst.gov.in <br> (vi) www.einvoice6.gst.gov.in <br> (vii) www.einvoice7.gst.gov.in <br> (viii) www.einvoice8.gst.gov.in <br> (ix) www.einvoice9.gst.gov.in <br> (x) www.einvoice10.gst.gov.in | Issued under section 146 of the CGST Act, 2017 read with rule 48(4) of the CGST Rules, 2017. |
|  |  | Circular No. 39/13/2018-GST, dated 03.04.2018 | Setting up of an IT Grievance Redressal Mechanism to Address the Grievances of Tax Payers due to Technical Glitches on GST Portal. |  |
| Section 147 | Deemed exports | Notification No. 48/2017-Central Tax, dated 18.10.2017 as amended vide notification No. 1/2019-Central Tax, dated 15.01.2019 | It notifies certain supplies of goods to be treated as deemed exports. |  |
|  |  | Notification No. 49/2017-Central Tax, dated 18.10.2017 | It notifies evidences, which are required to be produced by the supplier of deemed export supplies for claiming refund. |  |
|  |  | Circular No. 14/14/2017-GST, dated 6.11.2017 | Procedure regarding procurement of supplies of goods |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | from DTA by Export Oriented Unit (EOU)/Electronic Hardware Technology Park (EHTP) Unit/Software Technology Park (STP) Unit/ Bio-technology Park (BTP) Unit under deemed Export benefit under Section 147 of the CGST Act, 2017. |  |
| Section 148 | Special procedure for certain processes | Notification No. 4/2018-Central Tax (Rate), dated 25.01.2018 as amended vide notification No. 23/2019-Central Tax (Rate), dated 30.09.2019 (w.e.f. 01.10.2019) | It notifies special procedure with respect of payment of tax by registered person supplying service by way of construction against transfer of development right or vice versa. |  |
|  |  | Notification No. 40/2017-Central Tax, dated 13.10.2017 | It notified the registered person having aggregate turnover less than Rs. 1.5 crores in previous financial year or the registered person who turnover in current financial year is likely to be less than 1.5 crore but did not opt for composition scheme, as the class of person to pay central tax on outward supply of goods at the time of supply specified in 12(2) (a) of CGST Act, 2017 and to furnish the details and returns as per chapter IX of CGST Act, 2017. | $\begin{aligned} & \text { Superceded } \\ & \text { (vide } \\ & \text { notification No. 66/2016- } \\ & \text { Central Tax, dated } \\ & \text { 15.11.2017). } \end{aligned}$ |
|  |  | Notification No. 66/2017-Central Tax, dated 15.11.2017 as amended vide notification No. 50/2023-Central Tax, dated 29.09.2023 (w.e.f. 01.10.2023). | It superseded notification No. 40/2017-Central Tax, dated 13.10.2017 and notified the registered person who did not opt for composition levy, as class of person to pay central tax on outward supply of goods at the time of supply specified in 12(2) (a) of CGST Act, 2017 and to furnish the details and returns as per Chapter IX of CGST Act, 2017. It excluded actionable claims as defined in clause (102A) of the section 2 of the CGST Act, 2017 with effect from 01.10.2023. | It superseded notification No. 40/2017-Central Tax, dated 13.10.2017 |
|  |  | Notification No. 57/2017-Central Tax, dated 15.11.2017 | It prescribes special procedure for registered persons having aggregate turnover of up to Rs. 1.5 crores in the preceding FY or Current FY for furnishing the details of outward supply of goods or services or both in FORM GSTR-I and lays down due dates for furnishing details of outwards supplies for the period from July, 2017 to March, 2018. | Superceded (vide notification No. 71/2017-Central Tax, dated 29.12.2017). <br> Also Superceded (vide notification No. 43/ 2018Central Tax, dated 10.09.2018). |
|  |  | Notification No. 71/2017-Central Tax, dated 29.12.2017. | It superceded the notification No. 57/2017-Central Tax, dated 15.11.2017 and notified the registered person |  |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 86 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | having turnover of up to Rs. 1.5 crores in the preceding FY or the Current FY, as class of Registered Person which may follow special procedure for furnishing the details of outward supply of goods or services or both. It also laid down due dates for furnishing FORM GSTR-1 for quarter July-Sep, 2017, Oct-Dec, 2017, and Jan-March, 2018. |  |
|  |  | Notification No. 17/2018-Central Tax, dated 28.03.2018 | It notified the registered person having aggregate turnover of up to Rs. 1.5 crores in the preceding financial year or the current financial year as class of person who shall follow special procedure specified for furnishing the details of outward supply of goods or services or both. | Superceded (vide notification No. 43/ 2018-Central Tax, dated 10.09.2018). |
|  |  | Notification No. 20/2018-Central Tax, dated 28.03.2018. | It extended the date of filing refund claim under section 54 by specified person (specified under section 55 such as UN agency) for refund of taxes paid on inward supplies of goods/services before the expiry of 18 months from the last date of quarter in which supply was received. | Rescinded vide notification no. 20/2022-Central Tax, dated 28.09.2022 |
|  |  | Notification No. 31/2018-Central Tax, dated 06.08.2018 as amended vide notification No. 67/2018-Central Tax, dated 31.12.2018. | It prescribes procedure for registration for obtaining GSTIN by those taxpayers who did not file the complete FORM GST REG-26 but received only a Provisional Identification Number (PID) till 31.12.2017. |  |
|  |  | Notification No. 33/2018-Central Tax, dated 10.08.2018 as amended vide notification No. 38/2018-Central Tax, dated 24.08.2018. | It prescribed special procedure for registered persons having aggregate turnover of Up to Rs. 1.5 crores in the preceding FY or Current FY for furnishing the details of outward supply of goods or services or both in FORM GSTR-I and lays down due dates for furnishing details of outwards supplies for the period from July, 2018 to March, 2019. | ```Superceded (vide notificalion No. 43/2018- Central Tax, dated 10.09.2018).``` |
|  |  | Notification No. 43/2018-Central Tax, dated 10.09.2018 as amended vide notification No. 64/2018-Central Tax, dated 29.11.2018; and No. 71/2018-Central Tax, dated 31.12.2018. | It prescribes special procedure for registered persons having aggregate turnover of Up to Rs. 1.5 crores in the preceding FY or Current FY for furnishing the details of outward supply of goods or services or both in FORM GSTR-I and lays down due dates for furnishing details of outwards supplies for the period from July, 2018 to March, 2019. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 11/2019-Central Tax, dated 07.03.2019 | It notifies the registered persons having aggregate turnover of up to Rs. 1.5 crores in the preceding FY or Current FY as class of registered person to follow the special procedure for furnishing details of outward supplies and prescribes time limit of 31.07.2019 for furnishing details of outward supplies of goods or services in FORM GSTR-1 for quarter April-June, 2019. |  |
|  |  | Notification No. 58/2018-Central Tax, dated 26.10.2018 | It notifies the persons whose registration has been cancelled on or before 30.09.2018, as a Class of persons to furnish FORM GSTR-10 till 31.12.2018. |  |
|  |  | Notification No. 06/2019-Central Tax (Rate), dated 29.03.2019 (w.e.f. 01.04.2019)as amended vide notification No. 03/2021-Central Tax (Rate), dated 02.06.2021 (w.e.f. 02.06.2021). | It notifies certain class of persons in respect of construction services. |  |
|  |  | Notification No. 21/2019-Central Tax, dated 23.04.2019 as amended vide notification No. 34/2019Central Tax, dated 18.07.2019; No. 35/2019-Central Tax, dated 29.07.2019; No. 50/2019-Central Tax, dated 24.10.2019 (w.e.f. 18.10.2019); No. 12/2020Central Tax, date 21.03.2020; No. 34/2020-Central Tax, dated 03.04.2020; No. 59/2020-Central Tax, dated 13.07.2020; No. 64/2020-Central Tax, dated 31.08.2020; No. 10/2021-Central Tax, dated 01.05.2021 (w.e.f. 30.04.2021); No. 25/2021-Central Tax, dated 01.06.2021 (w.e.f. 31.05.2021); and No. 11/2022-Central Tax, dated 5.7.2022. | It notifies the special procedure for those taxpayers availing benefit of notification No. 02/2019-Central Tax (Rate), dated 07.03.2019 with regard to quarterly tax payment and annual filing of return. <br> It also provides for due date of 31.08.2019 for furnishing the statement containing the details of payment of selfassessed tax in FORM GST CMP-08 for quarter April, 19 to June, 19. It provided for due date of 22.10.2019 for furnishing the statement containing the details of payment of self-assessed tax in FORM GST CMP-08 for the quarter July, 19 to September, 19 or part thereof. (Ref: second proviso to paragraph 1). <br> It also waived off the requirement for furnishing FORM GSTR-1 for 2019-20 for taxpayers who could not opt for availing the option of special composition scheme under notification No. 2/2019-Central Tax (Rate) (Ref: proviso to paragraph 2). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | It also extended the date for furnishing statement, containing the details of payment of self-assessed tax in FORM GST CMP-08 for the quarter ending 31st March, 2020 and furnishing FORM GSTR-1 for the FY ending 31.03.2020. <br> It also extended the date of furnishing the return in FORM GSTR-4 for the FY ending 31.03.2021 upto 31.07.2021. <br> It allowed taxpayers to furnish a statement in FORM GST CMP-08 of CGST Rules, 2017 for the quarter ending 30.06. 2022 till 31.07.2022 (5 $5^{\text {th }}$ proviso) |  |
|  |  | Notification No. 27/2019-Central Tax, dated 28.06.2019 as amended vide notification No. 24/2020-Central Tax, dated 23.03.2020 (with retrospective effect from 30.11.2019). | It notifies the registered persons having aggregate turnover of up to Rs. 1.5 crores in preceding financial year or the current financial year, as class of registered persons to follow special procedure for furnishing the details of outward supply of goods or services or both. <br> Further, it extended due date for furnishing FORM GSTR1 for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir, for the quarter July-September, 2019 till 24th March,2020. |  |
|  |  | Notification No. 30/2019-Central Tax, dated 28.06.2019. | It notifies the persons registered under Section 24 read with rule 14 of the CGST Rules, 2017, supplying online information and data base access or retrieval from a place outside India to a person in India (other than a registered person) as class of registered person to follow special procedure. Such persons are not required to file annual return in FORM GSTR-9 and reconciliation statement in FORM GSTR-9C |  |
|  |  | Notification No. 45/2019-Central Tax, dated 09.10.2019 as amended vide notification No. 21/2020-Central Tax, dated 23.03.2020 (with | It notifies the registered persons having aggregate turnover of up to Rs. 1.5 crores in the preceding financial year as the class of registered persons to follow special |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | retrospective effect from 31.01.2020) | procedure for furnishing the details of outward supply of goods or services or both in FORM GSTR-1. It also prescribes the time period for filing quarterly return in GSTR-1 for the quarter from Oct, 19 to December, 2019 and January, 20 to March, 20. <br> It also extended due date for furnishing FORM GSTR-1 for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir or the Union territory of Jammu and Kashmir or the Union territory of Ladakh for the quarter October-December, 2019 till 24th March, 2020 ( Ref: First Proviso to Paragraph 1) |  |
|  |  | Notification No. 47/2019-Central Tax, dated 09.10.2019as amended vide notification No. 77/2020-Central Tax, dated 15.10.2020. | It notifies the registered person whose aggregate turnover in a FY does not exceed Rs. 2 crores and who has not filed the annual return under section 44(1) of the CGST, 2017 read with rule 80 of the CGST Rules, 2017 as a class of persons who shall have option to file the annual return for the year 2017-18; 2018-19 and 2019-20. | [filing of annual return under section 44(1) of the CGST Act, 2017 for registered person having aggregate turnover up to 2 crores]. |
|  |  | Circular No. 124/43/2019-GST, dated 18.11.2019 | Clarification regarding Optional Filing of Annual Return under notification No. 47/2019-Central Tax, dated 09.10.2019-Reg. |  |
|  |  | Notification No. 38/2019-Central Tax, dated 31.08.2019 | It notified the registered person, who are required to furnish the details of challans in FORM ITC-04 (under Rule 45(3) of the CGST Rules, 2017 read with section 143 of the CGST Act, 2017) as class of Registered person, as class of persons required to follow special procedure to the effect that they will not be required to file FORM ITC04, but shall be required to furnish the details of all challan dispatched to the job worker during July, 2017 to March, 2019, but not received from Job Worker or not supplied from the place of business of job-worker as on 31.03.2019. Such details shall be required to be furnished in the ITC-04 for the period from April -June, 2019. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 62/2019-Central Tax, dated 26.11.2019 as amended vide notification No. 03/2020-Central Tax, dated 01.01.2020. | It notified the registered person having principal place of business or place of business in the erstwhile state of Jammu and Kashmir till 31.12.2019 and now lies in the Union territory of Jammu and Kashmir or in the UT of Ladakh as class of person who shall follow the special procedure till 31.12.2019. |  |
|  |  | Notification No. 09/2020-Central Tax, dated 16.03.2020 | It notified foreign company which is an airlines company covered under the notification issued under sub-section (1) of section 381 of the Companies Act, 2013 (18 of 2013) and who have complied with the sub-rule (2) of rule 4 of the Companies (Registration of Foreign Companies) Rules, 2014, as the class of registered persons who shall follow the special procedure. |  |
|  |  | Notification No. 10/2020-Central Tax, dated 21.03.2020 as amended vide notification No. 45/2020-Central Tax, dated 09.06.2020. | It notified those persons whose principal place of business or place of business was in the erstwhile Union territory of Daman and Diu or in the erstwhile Union territory of Dadra and Nagar Haveli till the 26.01.2020; and is in the merged Union territory of Daman and Diu and Dadra and Nagar Haveli from the 27.01.2020 onwards, as the class of persons who shall, follow the following special procedure till the 31.05. 2020 |  |
|  |  | Notification No. 11/2020-Central Tax, dated 21.03.2020 as amended vide notification No. 39/2020-Central Tax, dated 05.05.2020. | It notified those registered persons, who are corporate debtors under the provisions of the Insolvency and Bankruptcy Code, 2016 (31 of 2016), undergoing the corporate insolvency resolution process and the management of whose affairs are being undertaken by interim resolution professionals (IRP) or resolution professionals (RP), as the class of persons who shall follow the special procedure, from the date of the appointment of the IRP/RP till the period they undergo the corporate insolvency resolution process. |  |
|  |  | Circular No.134/04/2020-GST, dated 23.03.2020 | Clarification in respect of issues under GST law for |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | companies under Insolvency and Bankruptcy Code, 2016 |  |
|  |  | Circular No. 187/19/2022-GST, dated 27.12.2022 | Clarification regarding the treatment of statutory dues under GST laws in respect of taxpayers for whom the proceedings have been finalized under Insolvency and Bankruptcy Code, 2016. |  |
|  |  | Notification No. 27/2020-Central Tax, dated 23.03.2020 | It prescribed the due date for furnishing FORM GSTR-1 for the quarters April, 2020 to June, 2020 and July, 2020 to September, 2020 for registered persons having aggregate turnover of up to 1.5 crore rupees in the preceding financial year or the current financial year. | This has been issued with reference to furnish details of outward supplies. |
|  |  | Notification No. 28/2020-Central Tax, dated 23.03.2020 | It prescribed the due date for furnishing FORM GSTR-1 by such class of registered persons having aggregate turnover of more than 1.5 crore rupees in the preceding financial year or the current financial year, for each of the months from April,2020 to September, 2020. | This has been issued with reference to furnish details of outward supplies. |
|  |  | Notification No. 73/2020-Central Tax, dated 01.10.2020. | It notifies special procedure for taxpayers for issuance of e-invasive in the period from 01.10.2020 to 31.10.2020. |  |
|  |  | Notification No. 74/2020-Central Tax, dated 15.10.2020. | It prescribes the due dates for furnishing FORM GSTR-1 returns for the quarter October, 2020 to December, 2020 and January, 2021 to March, 2021 for registered persons having aggregate Turnover of Rs. 1.5 crores in the preceding financial year or the current financial year. | Superceded vide notification No. 83/2020Central Tax, dated 10.11.2020 (w.e.f. |
|  |  | Notification No. 75/2020-Central Tax, dated 15.10.2020. | It prescribes the due dates for furnishing FORM GSTR-1 returns for each of the month from October, 2020 to March, 2021 for such class of registered persons having aggregate Turnover of more than Rs. 1.5 crores in the preceding financial year or the current financial year. | Superceded vide notification No. 83/2020Central Tax, dated 10.11.2020 (w.e.f. |
|  |  | Notification No. 83/2020-Central Tax, dated 10.11.2020 as amended vide notification No. 12/2021-Central Tax, dated 01.05.2021; No. 17/2021-Central Tax, dated 01.06.2021; No. | It prescribes the due date for filing FORM GSTR-1. It extended the due date for furnishing FORM GSTR-1 for November, 2022 for registered persons whose principal | It also superceded the notification Nos. 74/2020Central Tax, dated 15.10.2020 and No. 75/2020- |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 92 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 25/2022-Central Tax, dated 13.12.2022; No. 11/2023-Central Tax, dated 24.05.2023 (w.e.f. 11.05.2023); No. 14/2023-Central Tax, dated 19.06.2023 (w.e.f. 31.05.2023); No. 18/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023); No. 41/2023-Central Tax, dated 25.08.2023 (w.e.f. 31.07.2023); and No. 09/2024-Central Tax, dated 12.04.2024 (w.e.f. 11.04.2024) | place of business is in certain districts of Tamil Nadu. <br> It extended the due date for furnishing FORM GSTR-1 for April, 2023, May, 2023 and June, 2023 and July, 2023 till 25.08.2023 for registered persons whose principal place of business is in the State of Manipur (Ref: $4^{\text {th }}$ proviso inserted vide notification No. 11/2023-Central Tax, dated 25.05.2024). | Central Tax, dated 15.10.2020 with effect from 01.01.2021. |
|  |  | Notification No. 3/2023-Central Tax, dated 31.03.2023 as amended vide notification No. 23/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023) | It prescribes special procedure in respect of revocation of cancellation of such registration which were cancelled under clause (b) or clause (c) of Section 29(2) of the CGST Act, 2017 on or before 31.12.2022 and who failed to apply for revocation of cancellation within the prescribed time period under section 30 of the CGST Act, 2017. This special procedure to be available till 31.08.2023. |  |
|  |  | Notification No. 06/2023-Central Tax, dated 31.03.2023 vide notification No. 24/2023-Central Tax, dated 17.07.2023 (w.e.f. 30.06.2023) | It prescribes special procedure for registered person who failed to furnish a valid return within 30 days from the date of issuance of assessment order on or before 28.02.2023 under Section 62(1). Such assessment will be deemed withdrawn even if appeal filed against such orders is pending or decided if such registered person files prescribed return on or before 31.08.2023 and due tax along with interest and late fee is paid. |  |
|  |  | Notification No. 29/2023-Central Tax dated 31.07.2023 | It notifies the special procedure to be followed by a registered person or an officer referred to in section 107(2) who intends to file an appeal in accordance with circular No. 182/14/2022-GST, dated 10.11.2022 pursuant to the directions of the Hon'ble Supreme Court in the case of Union of India v/s. Filco Trade Central Pvt. Ltd. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 30/2023-Central Tax, dated 31.07.2023 as amended vide notification No. 47/2023-Central Tax, dated 25.09.2023 (w.e.f. 31.07.2023) | It notified special procedure to be followed with effect from 01.01.2024 by a registered person engaged in manufacturing of the specified goods (Pan masala and tobacco-based goods) falling under Chapter 21(210690 20) and 24 of Customs Tariff Act, 1975. It also prescribed the forms i.e. SRM-I to SRM-IV. | Rescinded vide notification No. 03/2024-Central Tax, dated 05.01.024. |
|  |  | Notification No. 04/2024-Central Tax, dated 05.01.2024 as amended vide notification No. 08/2024-Central Tax, dated 10.04.2024 | It notified special procedure to be followed with effect from 15.05.2024 by a registered person engaged in manufacturing of the specified goods (Pan masala and tobacco-based goods) falling under Chapter 21(210690 20) and 24 of Customs Tariff Act, 1975. It also prescribed the forms i.e. GST FORM SRM-I to GST FORM SRM-IV. |  |
|  |  | Circular No. 208/2/2024-GST, dated 26.06.2024 | Clarifications on Various issues pertaining to Special Procedure for the manufacturers of the Specified Commodities as per notification No. 04/2024-Central Tax, dated 05.01.2024-Reg. |  |
|  |  | Notification No. 36/2023-Central Tax, dated 04.08.2023 (w.e.f. 01.10.2023). | It notified Electronic Commerce Operator (ECO) as class of person and lays down special procedure to be followed by them in respect of supply of goods through it by the persons paying tax under Rule 10 (composition Scheme). |  |
|  |  | Notification No. 37/2023-Central Tax, dated 04.08.2023 (w.e.f. 01.10.2023). | It notified Electronic Commerce Operator (ECO) as class of person and lays down special procedure to be followed by them in respect of supply of goods through it by the persons exempted from obtaining registration in terms of notification No. 34/2023-Central tax, dated 31.07.2023. |  |
|  |  | Notification No. 53/2023-Central Tax, dated 2.11.2023 (w.e.f. 2.11.2023) | It notify special procedure for condonation of delay in filing of appeals against demand order passed until 31.03.2023 (Amnesty Scheme). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 149 | Goods and service tax compliance rating. |  |  |  |
| Section 150 | Obligation to furnish information return. |  |  |  |
| Section 151 | Power to collect statistics |  |  |  |
| Section 152 | Ban on disclosure of information. |  |  |  |
| Section 153 | Taking assistance from an expert |  |  |  |
| Section 154 | Power to take samples |  |  |  |
| Section 155 | Burden of proof |  |  |  |
| Section 156 | Persons deemed to be public servants |  |  |  |
| Section 157 | Protection of action taken under this Act. |  |  |  |
| Section 158 | Disclosure of information by a public servant. |  |  |  |
| Section 158A <br> (inserted vide <br> Finance Act, 2023 <br> with effect from <br> 1.10.2023) | Consent based sharing of information furnished by taxable person. | Notification No. 33/2023-Central Tax, dated 31.07.2023 (w.e.f. 1.10.2023). | It notified "Account Aggregator" as the systems with which may be shared by the common porta under section 158A. |  |
|  |  | Notification No. 06/2024-Central Tax, dated 22.02.2024 | It notified "public Tech Platform for friction less credit" as a system with which information may be shared by the common portal based on consent under sub-section (2) of section 158A of the CGST Act, 2017. | r/w section 20 of the IGST Act, 2017 |
| Section 159 | Publication of information in respect of persons in certain cases. |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
| Section 160 | Assessment proceedings, etc. ... not to be invalid on certain grounds. |  |  |  |
| Section 161 | Rectification of errors apparent on the face of record. |  |  |  |
| Section 162 | Bar on jurisdiction of civil courts. |  |  |  |
| Section 163 | Levy of fee |  |  |  |
| Section 164 | Power of Government to make rules. |  |  |  |
|  |  | Notification No. 3/2017-Central Tax, dated 19.06.2017 (effective 22.06.2017) and has been subsequently amended vide notification No. 7/2017-Central Tax, dated 27.06.2017 (w.e.f. 22.06.2017); No. 10/2017-Central Tax, dated 28.06.2017 (effective from 1.07.2018); No. 15/2017Central Tax, dated 1.7.2017 (effective from 1.7.2017); No. 17/2017-Central Tax, 27.07.2017; No. 22/2017-Central Tax, dated 17.08.2017; No. 27/2017-Central Tax, dated 30.08.2017; No. 34/2017-Central Tax, dated 15.09.2017, No. 36/2017-Central Tax, dated 29.09.2017, No. 45/2017-Central Tax, dated 13.10.2017; No. 47/2017-Central Tax, dated 18.10.2017, No. 51/2017-Central Tax, dated 28.10.2017; No. 55/2017-Central Tax, dated 15.11.2017; No. 70/2017-Central Tax, dated 21.12.2017; No. 75/2017-Central Tax, dated 29.12.2017; No. 3/2018-Central Tax, dated 23.01.2018; No. 12/2018-Central Tax, dated 7.03.2018; No. 14/2018-Central Tax, dated 23.03.2018; No. 21/2018-Central Tax, dated 18.04.2018; No. | It notified CGST Rules, 2017. |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 26/2018-Central Tax, dated 13.06.2018; No. 28/2018-Central Tax, dated 19.06.2018; No. 29/2018-Central Tax, dated 6.07.2018; No. 39/2018-Central Tax, dated 4.09.2018; No. 48/2018-Central Tax, dated 10.09.2018; No. 49/2018-Central Tax, dated 13.09.2018; No. 53/2018-Central Tax, dated 09.10.2018; No. 54/2018-Central Tax, dated 09.10.2018; No. 60/2018-Central Tax, dated 30.10.2018; No. 74/2018-Central Tax, dated 31.12.2018; No. 03/2019-Central tax, dated 29.01.2019 ( with effect from 01.02.2019); No. 16/2019-Central Tax, dated 29.03.2019; and No. 20/2019-Central Tax, dated 23.04.2019; No. 31/2019-Central Tax, dated 28.06.2019; No. 33/2019-Central Tax, dated 18.07.2019; No. 49/2019-Central Tax, dated 09.10.2019; No. 56/2019-Central Tax, dated 14.11.2019; No. 68/2019-Central Tax, dated 13.12.2019; No. 75/2019-Central Tax, dated 26.12.2019; No. 02/2020-Central Tax, dated 01.01.2020; No. 08/2020-Central Tax, dated 02.03.2020; No. 16/2020-Central Tax, dated 23.03.2020; No. 30/2020-Central Tax, dated 03.04.2020; No. 38/2020-Central Tax, dated 05.05.2020; No. 50/2020-Central Tax, dated 24.06.2020 (w.e.f. 01.04.2020); No. 58/2020-Central Tax, dated 01.07.2020 (w.e.f. 01.07.2020); No. 60/2020-Central Tax, dated 30.07.2020; No. 62/2020-Central Tax, dated 20.08.2020; No. 72/2020-Central Tax, dated 30.09.2020 (read with corrigendum dated 01.10.2020); No. 79/2020Central Tax, dated 15.10.2020; No. 82/2020Central Tax, dated 10.11.2020 (read with corrigendum dated 13.11.2020); No. 94/2020Central Tax, dated 22.12.2020 read with |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | corrigendum dated 28.12.2020; No 01/2021Central Tax, dated 01.01.2021; No. 07/2021Central Tax, dated 27.04.2021; No. 13/2021Central Tax, dated 01.05.2021; No. 15/2021Central Tax, dated 18.05.2021;No. 27/2021Central Tax, dated 01.06.2021; No. 30/2021Central Tax, dated 30.07.2021 (w.e.f. 01.08.2021); No. 32/2021-Central Tax, dated 29.08.2021 (w.e.f. 29.08.2021); No. 35/2021-Central Tax, dated 24.09.2021 (w.e.f. date specified in notification or date notified vide notification No. 38/2021-Central Tax, dated 21.12.2021); No. 37/2021-Central Tax, dated 01.12.2021 (w.e.f. 01.12.2021 with some exceptions); No. 40/2021-Central Tax, dated 29.12.2021 (w.e.f. 29.12.2021 except otherwise specified in the amendment rules); No. 14/2022-Central Tax, dated 05.07.2022; No. 19/2022-Central Tax, dated 28.09.2022 (w.e.f. 01.10.2022); No. 22/2022-Centrax Tax, dated 15.11.2022; No. 24/2022-Central Tax, dated 23.11.2022 (w.e.f. 01.12.2022); No. 26/2022Central Tax, dated 26.12.2022; No. 04/2023-Central Tax, dated 31.03.2023 (with retrospective effect from 26.12.2022); No. 38/2023-Central Tax, dated 04.08.2023 (w.e.f. 04.08.2023 except otherwise specified); No. 51/2023-Central Tax, dated 29.09.2023 (w.e.f. 01.10.2023); No. 52/2023-Central Tax, dated 26.10.2023 (w.e.f. 26.10.2023); No. 2/2024-Central Tax, dated 05.01.2024 (w.e.f. 31.12.2023); and No. 12/2024-Central Tax, dated 10.07.2024(w.e.f. 10.07.2024 save as otherwise provided). |  |  |
|  |  | Notification No. 44/2020-Central Tax, dated 08.06.2020 | It brought into force the provisions of CGST (Fifth Amendment) Rules, 2020 (notified vide notification No. 38/2020-Central Tax, dated 05.05.2020) with effect from 08.06.2020. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 74/2017-Central Tax, dated 29.12.2017. | It appointed 1st February, 2018 for coming into effect of the provisions of the E-way Bill Rules. | Rescinded (vide notification No. 11/2018-Central Tax, dated 2.2.2018). |
|  |  | Notification No. 11/2018-Central Tax, dated 02.02.2018 | It rescinded the notification No. 74/2017-Central Tax, dated 29.12.2017 |  |
|  |  | Notification No. 15/2018-Central Tax, dated 23.03.2018 | It notified 1st April, 2018 as the date of coming into effect of the specified provisions of the Rule 138 of the CGST Rules relating to the E-way. |  |
|  |  | Notification No. 22/2019-Central Tax, dated 23.04.2019 as amended vide notification No. 25/2019-Central Tax, dated 21.06.2019; and No. 36/2019-Central Tax, dated 20.08.2019. | It notified $21^{\text {st }}$ November, 2019 as the date of coming into force the provisions of Rule 138E of the CGST Rules, 2017 ( $14^{\text {th }}$ amendment rules). |  |
|  |  | Notification No. 42/2019-Central Tax, dated 24.09.2019 | It notified $24^{\text {th }}$ September, 2019 as the date of coming into force the provision of Rules 10, 11, 12 and 26 of CGST (fourth amendment Rules, 2019 notified vide notification No. 31/2019-Central Tax, dated 28.06.2019. |  |
| Section 165 | Power to make regulations. |  |  |  |
| Section 166 | Laying of and and regulations notifications |  |  |  |
| Section 167 | Delegation of powers |  |  |  |
| Section 168 | Power to issue instructions or directions. |  |  |  |
|  |  | Notification No. 21/2017-Central Tax, dated 08.08.2017 as amended vide notification No. 45/2018-Central Tax, dated 10.09.2018; and notification No. 68/2018-Central Tax, dated 31.12.2018. | It specified that dates for filing GSTR-3B returns for the months of July and August, 2017. Further, it extended date for filing GSTR-3B returns for the period from July, 2017 to Feb, 2019 by those taxpayers who obtained GST Registration Number under notification No. 31/2018Central Tax, dated 06.08.2018 till 31.03.2019. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Notification No. 23/2017-Central Tax, dated 17.08.2017 as amended vide notification No. 24/2017-Central Tax, dated 21.08.2017 | It specified conditions for furnishing the return in FORM GSTR-3B |  |
|  |  | Notification No. 35/2017-Central Tax, dated 15.09.2017 as amended vide notification No. 02/2018-Central Tax, dated 20.01.2018; No. 46/2018-Central Tax, dated 10.09.2018; and No. 69/2018-Central Tax, dated 31.12.2018. | It specified that last dates for filing GSTR-3B for the month from August, 17 to December, 2017. Further, it extended date for filing GSTR-3B returns for the period from July, 2017 to Feb, 2019 by those taxpayers who obtained GST Registration Number under notification No. 31/2018-Central Tax, dated 06.08.2018 till 31.03.2019 |  |
|  |  | Notification No. 56/2017-Central Tax, dated 15.11.2017as amended vide notification No. 45/2018-Central Tax, dated 10.09.2018; and notification No. 68/2018-Central Tax, dated 31.12.2018. | It specified the last date for filing GSTR-3B return for the month of January, Feb. and March, 2018. Further, it extended date for filing GSTR-3B returns for the period from July, 2017 to Feb, 2019 by those taxpayers who obtained GST Registration Number under notification No. 31/2018-Central Tax, dated 06.08.2018 till 31.03.2019 |  |
|  |  | Notification No. 13/2019-Central Tax, dated 07.03.2019 as amended vide notification No. 24/2019-Central Tax, dated 11.05.2019. | It specified that dates for filing GSTR-3B returns for the months of April, 2019 to June, 2019 and provides that such returns to be furnished electronically on or before the twentieth day of the month succeeding such month and payment of taxes also to be made by such dates. It also extended time limits for filing FORM GSTR-3B for registered persons having principal place of business located in certain districts of Orissa for the month of April, 2019 to $20^{\text {th }}$ June, 2019. | Ir/w Rule 61(5) of the CGST Rules, 2017. |
|  |  | Notification No. 44/2019-Central Tax, dated 09.10.2019 as amended vide notification No. 61/2019-Central Tax, dated 26.11.2019 (w.e.f. 20.11.2019); No. 67/2019-Central Tax, dated 12.12.2019 (w.e.f. 30.11.2019); No. 73/2019-Central Tax, dated 23.12.2019; No. 77/2019-Central Tax, dated 26.12.2019 (w.e.f. 23.12.2019); No. 07/2020Central Tax, dated 03.02.2020; No. 25/2020- | It specifies the due dates for filing return in FORM GSTR-3B for each of the month during the period from October, 2019 to March, 2020. <br> It extended the due date for filing return in FROM GSTR3B for the month of October, 2019 till 20.12.2019 for registered person with principal place of business in the State of Jammu and Kashmir (Ref: proviso to first paragraph); | (r/w rule 61(5) of the CGST Rules, 2017. |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 100 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Central Tax, dated 23.03.2020 (with retrospective effect from 20.12.2020); and No. 42/2020-Central Tax, dated 05.05.2020 (with retrospective effect from 24.03.2020). | It further extended the due date for filing return in FROM GSTR-3B for the month of October, 2019 till 30.11.2019 for registered person with principal place of business in the State of Jammu and Kashmir (Ref: proviso to first paragraph); <br> It extended the last date for filing of FORM GSTR-3B for the month of Nov. 2019 by three days from 20.12.2019 till 23.12.2019. <br> It extended the due date for filing of FORM GSTR-3B return for the month of November, 2019 for registered person having principal place of business in the state of Assam, Manipur, Meghalaya or Tripura till 31.12.2019 (Ref: third proviso to paragraph 1). <br> It provided due dates for filing of FORM GSTR-3B to the taxpayers having turnover upto Rs. 5 crores in a staggered manner, based on the location of principal place of business. <br> It also extended due date for furnishing FORM GSTR-3B for the months of October, 2019, November, 2019 to February, 2020 for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir on or before the 24th March, 2020. (Ref: $6^{\text {th }}$ proviso to Paragraph 1). |  |
|  |  | Notification No. 44/2017-Central Tax, dated 13.10.2017 as amended vide notification No. 52/2017-Central Tax, dated 28.10.2017. | It extended the time limit for making a declaration in FORM ITC-01 by the registered persons till 31.10.2017. |  |
|  |  | Notification No. 67/2017-Central Tax, dated 21.12.2017. | It superseded the notification No. 52/2017-Central Tax, dated 28.10.2017 and extended the time limit for making a declaration in FORM ITC-01 by registered persons till 31.01.2018 |  |
|  |  | Notification No. 16/2018-Central Tax, dated | It specified the last day for filing FORM GSTR-3B returns |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 23.03.2018 as amended vide notification No. 23/2018-Central Tax, dated 18.05.2018; No. 46/2018-Central Tax, dated 10.09.2018; and No. 69/2018-Central Tax, dated 31.12.2018. | for the month of April, May, and June, 2018.Further, it extended date for filing GSTR-3B returns for the period from July, 2017 to Feb, 2019 by those taxpayers who obtained GST Registration Number under notification No. 31/2018-Central Tax, dated 06.08.2018 till 31.03.2019 |  |
|  |  | Notification No. 34/2018-Central Tax, dated 10.08.2018 as amended vide notification No. 35/2018-Central Tax , dated 21.08.2018; No. 36/2018-Central Tax, dated 24.08.2018; No. 47/2018-Central Tax, dated 10.09.2018; No. 55/2018-Central Tax, dated 21.10.2018; No. 62/2018-Central Tax, dated 29.11.2018; No. 70/2018-Central Tax, dated 31.12.2018; No. 09/2019-Central Tax, dated 20.02.2019; and No. 19/2019-Central Tax, dated 22.04.2019 (w.e.f. 20.04.2019). | It provides the dates for filing the return in FORMGSTR3B for each of the month from July, 2018 to March, 2019 to be filed electronically through common portal by date prescribed in the notification. The return for the month of March, 2019 can be filed on or before $23^{\text {rd }}$ April, 2019. |  |
|  |  | Notification No. 29/2019-Central Tax, dated 28.06.2019 as amended vide notification No. 37/2019-Central Tax, dated 21.08.2019 (effective from 20.08.2019); No. 54/2019-Central Tax, dated 14.11.2019 (w.e.f. 20.09.2019); No. 60/2019-Central Tax, dated 26.11.2019 (w.e.f. 20.11.2019); No. 66/2019-Central Tax, dated 12.12.2019 (w.e.f. 30.11.2019); and No. 26/2020-Central Tax, dated 23.03.2020 (with retrospective effect from 20.12.2019). | It provides the dates for filing the return in FORM GSTR3B for each of the month from July, 2019 to September, 2019 to be filed electronically through common portal on or before 20th of the succeeding such month. <br> It provided the dates for filing the return in FORM GSTR3B for the month from July, 2019 to be filed electronically through common portal on or before 22.08.2019 (first proviso to paragraph 1). <br> It provided the dates for filing the return in FORM GSTR3B for the month from July, 2019 by the Registered taxpayers with principal place of business in the specified districts of state of Bihar, Gujarat, Karnataka, Kerala, Maharashtra, Odisha, and Uttarakhand as mentioned in the notification to be filed electronically through common portal on or before 20.09.2019 (Ref: second proviso to the paragraph 1). |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | It extended due date for furnishing FORM GSTR-3B of the said rules for the months of July, 2019 to September, 2019 for registered persons whose principal place of business is in the erstwhile State of Jammu and Kashmir, shall be furnished electronically through the common portal, on or before the 24th March, 2020(Ref: fourth Proviso to the paragraph 1). |  |
|  |  | Notification No. 29/2020-Central Tax, dated 23.03.2020 as amended vide notification No. 36/2020-Central Tax, dated 03.04.2020; and No. 54/2020-Central Tax, dated 24.06.2020. | It provides the due dates for fling the return in FORM GSTR-3B of CGST Rules, 2017 for the month of April, 2020 to September, 2020. <br> It provides specific dates for filing of Return in FORM GSTR-3B for the month of May, 2020. | [issued under Rule 61(5) of the CGST Rules, 2017. |
|  |  | Notification No. 76/2020-Central Tax, dated 15.10.2020. | It provides the due dates for fling the return in FORM GSTR-3B of CGST Rules, 2017 for each of the month fromOct, 2020 to March, 2021. | Rescinded vide notification No. 86/2020-Central Tax, dated 10.11.2020 (read with corrigendum dated 13.11.2020). |
|  |  | Notification No. 53/2017-Central Tax, dated 28.10.2017 as amended vide notification No. 63/2017-Central tax. Dated 15.11.2017. | It extended the time limit for making ITC-04 declaration in respect of goods dispatched to a job worker or received from job-worker or sent from one job worker to another | Superceded vide notification No. 40/2018-Central Tax, dated 04.09.2018. |
|  |  | Notification No. 40/2018-Central Tax, dated 4.9.2018 | It superceded the notification No. 53/2017-Central Tax, dated 28.10.2017 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to June, 2018 till 30.09.2018. | Superceded (vide notification No. 59/2018-Central Tax, dated 26.10.2018). |
|  |  | Notification No. 59/2018-Central Tax, dated 26.10.2018. | It superceded the notification No. 40/2018-Central Tax, dated 4.09.2018 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to September, 2018 till 31.12.2018. | Superceded <br> notification No. 78/2018- <br> Central Tax, dated 31.12.2018) |
|  |  | Notification No. 78/2018-Central Tax, dated 31.12.2018 | It superceded the notification No. 59/2018-Central Tax, dated 26.10.2018 and extended the time limit for making a | Superceded <br> notification No. 15/2019- <br>  <br>  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to December, 2018 till 31.03.2019. | $\begin{array}{\|l\|} \hline \text { Central } \\ \text { Tax, dated } \\ \text { 28.03.2019 } \end{array}$ |
|  |  | Notification No. 15/2019-Central Tax, dated 28.03.2018 | It superceded the notification No. 78/2018-Central Tax, dated 31.12.2019 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to March, 2019 till 30.06.2019. | Superceded (vide <br> notification No. 32/2019- <br> Central Tax, dated <br> 28.06.2019). <br> [ also issued under Rule <br> 45(3) of the CGST Rules, <br> 2017. |
|  |  | Notification No. 32/2019-Central Tax, dated 28.06.2019. | It superceded the notification No. 15/2019-Central Tax, dated 28.03.2019 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to June, 2019 till 31.08.2019. |  |
|  |  | Notification No. 42/2018-Central Tax, dated 04.09.2018. | It extended time limit up to 04.10.2018 for making FORM GST ITC-01 declaration by those registered persons who filed FORM GST CMP-04 between 2.3.2018 to 31.03.2018. |  |
|  |  | Notification No. 38/2019-Central Tax, dated 31.08.2019. | It notifies the registrants persons required to furnish the details of challan in FORM ITC-04 as class of registered persons who shall follow the special procedure such that these persons shall not be required to furnish FORM ITC04 for the period from July, 2017 to March, 2019. | Also refers to rule 45(3) of the CGST Rules, 2017 read with section 143 of the CGST Act, 2017. |
|  |  | Notification No. 87/2020-Central Tax, dated 10.11.2020 (w.e.f. 25.10.2020). | It extends the time limit for furnishing declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker during the period from July, 2020 to September, 2020 till 30.11.2020. | Also Issued under Rule 45(3) of the CGST Rules, 2017. |
|  |  | Notification No. 11/2021-Central Tax, dated 01.05.2021 (w.e.f. 25.04.2021) as amended vide notification No. 26/2021-Central Tax, dated 01.06.2021 (w.e.f. 31.05.2021). | It extends the date, up to 30.06.2021, of furnishing FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker during the period from 01.01.2021 to 31.03.2021. |  |
|  |  | Circular No. 10/10/2017-GST, dated 18.10.2017 | Clarification on Issues wherein the goods are moved within the State or From the State of Registration to |  |
| Compiled by the GSTINDIAPATHWAY.ORG Team |  |  |  | Page 104 of 127 |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | another State for Supply on Approval Basis. |  |
|  |  | Circular No. 26/26/2017-GST, dated 29.12.2017. | Filing of Returns under GST (It deals with issues of filing of GSTR-1 and GSTR-3B, applicability and quantum of late fee, amendment/corrections/rectification of errors etc.) |  |
|  |  | Circular No. 36/10/2018-GST, dated 13.03.2018 | Processing of Refund Applications for UIN Entities. | Also see under Section 55. |
|  |  | Circular No. 38/12/2018, dated 26.03.2018 | Clarification on Issues Related to Job Work. | Also see under Section 143. |
|  |  | Circular No. 45/19/2018-GST, dated 30.05.2018 | Clarification on Refund Related Issues. | Also See under Section 54 (Refund). |
|  |  | Circular No. 58/32/2018-GST, dated 04.09.2018 | Recovery of Arrears of Wrongly Availed CENVAT Credit under the Existing Law and Inadmissible Transitional Credit. |  |
|  |  | Circular No. 59/33/2018-GST, dated 04.09.2018 | Clarification on Refund Related Issues. |  |
|  |  | Circular No. 61/35/2018-GST, dated 04.09.2018. | E-way Bill in case of storing of goods in Godown of transporter. |  |
|  |  | Circular No. 63/37/2018-GST, dated 14.09.2018. | Clarification regarding processing of refund claim filed by UIN Entities. |  |
|  |  | Circular No. 69/43/2018-GST, dated 26.10.2018 as amended vide Circular No. 88/07/2019-GST, dated 01.02.2019. | Processing of Applications for Cancellation of Registration submitted in FORM GST REG-16 |  |
|  |  | Circular No. 70/44/2018-GST, dated 26.10.2018 | Clarification on Certain Issues related to Refund. |  |
|  |  | Circular No. 72/46/2018-GST, dated 26.10.2018 | It clarifies the procedure in respect of return of time expired drugs or medicines. | Relevant for Pharma Sector. |
|  |  | Circular No. 73/47/2018-GST, dated 05.11.2018. | Scope of Principal and Agent Relationship Under Schedule I of the CGST Act, 2017 in the context of Del-Credere-Agent-Reg. |  |
|  |  | Circular No. 74/48/2018-GST, dated 05.11.2018 | Collection of Tax at Source by Tea Board of India |  |
|  |  | Circular No. 76/50/2018-GST, dated 31.12.2018 | Clarification on certain issues (sale by government departments to unregistered person; leviability of penalty under section 73(11) of the CGST Act; rate of tax in case of debit notes / credit notes issued under section 142(2) of | Also see under section 15, section 73, section 142, section 51. |

Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | the CGST Act; applicability of notification No. 50/2018Central Tax; valuation methodology in case of TCS under Income Tax Act and definition of owner of goods) related to GST-Reg |  |
|  |  | Circular No. 91/10/2018-GST, dated 18.02.2019 | Clarification regarding tax payment made for supply of warehoused goods while being deposited in a customs bonded warehouse for the period from July, 2017 to March, 2018. | Also refer to circular No. 3/1/2018-IGST, dated 25.05.2018. |
|  |  | Circular No. 92/11/2019-GST, dated 07.03.2019 | Clarification on various doubts related to treatment of Sales Promotion Schemes under GST | It clarifies on issues of <br> taxability, valuation, <br> availability or otherwise <br> of ITC on free samples and <br> gifts, buy one get one free <br> offer; discount including <br> 'Buy one, save more" <br> offers, secondary discounts. |
|  |  | Circular No. 105/24/2019-GST, dated 28.06.2019. | Clarification on various doubts related to treatment of secondary or post-sales discount under GST. | Also refers to circular No. 92/11/2019-GST, dated 07.03.2019. |
|  |  | Circular No. 94/13/2019-GST, dated 28.03.2019 | It issues clarification on refund related issues under GST. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
|  |  | Circular No. 104/23/2019-GST, dated 28.06.2019. | Processing of Refund Applications in FORM GST RFD01A submitted by Taxpayers wrongly mapped on the common portal | Refund Matter |
|  |  | Circular No. 103/22/2019-GST, dated 28.06.2019. | Clarification regarding determination of place of supply in certain cases. | It clarifies the place of supply in case of services provided by Ports and Services rendered on goods temporarily imported in India. |
|  |  | Circular No. 107/26/2019-GST dated 18.07.2019 | Clarifications on doubts related to supply of Information Technology Enabled Services (ITes Services)-Reg. | Withdrawn vide Circular No. 127/46/2019-GST, dated 04.12.2019. |

Compiled by the GSTINDIAPATHWAY.ORG Team

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Orders Issued under Section 168 |  |  |
|  |  | Order No. 01/2017-GST, dated 21.07.2017 | It extended the period for filing intimation in FORM GST CMP-01. | It relates to the Composition Levy Scheme. |
|  |  | Order No. 04/2017-GST, dated 29.09.2017 | It extended the period for intimation of details of stock held on the date previous to the date of exercise of option to pay tax under Section 10 in FORM GST CMP-03 till 31.10.2017. | Superceded (vide Order No. 05/2017-GST, dated 28.10.2017). |
|  |  | Order No. 05/2017-GST, dated 28.10.2017 | It extended the period for intimation of details of stock held on the date previous to the date of exercise of option to pay tax under Section 10 in FORM GST CMP-03 till 31.11.2017. | Superceded (vide Order No. 05/2017-GST, dated 28.10.2017). |
|  |  | Order No. 11/2017-GST, dated 21.12.2017 | It extended the period for intimation of details of stock held on the date previous to the date of exercise of option to pay tax under Section 10 in FORM GST CMP-03 till 31.01.2018. |  |
|  |  | Order No. 02/2017-GST, dated 18.09.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded (vide Order No. 08/2017-GST, dated 28.10.2017). |
|  |  | Order No. 08/2017-GST, dated 28.10.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded (vide Order No. 10/2017-GST, dated 15.11.2017). |
|  | (filing of GST TRAN-1 under Rule 120 A of the CGST Rules, 2017) | Order No. 10/2017-GST, dated 15.11.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Issued under Rule 120A of CGST Rules, 2017. |
|  |  | Order No. 03/2017-GST, dated 21.09.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded (vide Order No. 03/2017-GST, dated 21.09.2017). |
|  |  | Order No. 07/2017-GST, dated 28.10.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 30.11.2017. | Superceded (vide Order No. 09/2017-GST, dated 15.11.2017). |
|  | Filing of GST TRAN-1 under Rule 117 of the CGST Rules, 2017) | Order No. 09/2017-GST, dated 15.11.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 27.12.2017. | Issued under Rule 117 of the CGST Rules, 2017 |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 107 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  | (Filing of GST TRAN -2) | Order No. 1/2018-Central Tax, dated 28.03.2018 | It extended the period for furnishing the statement in FROM GST TRAN-2 under clause (b) (iii) of the Rule 117(4) of CGST Rules, 2017 till 30.06.2018. |  |
|  | (filing of FORM GST <br> TRAN-1 under Rule <br> 117(1A) of CGST Rules, <br> 2017. | Order No. 01/2019-GST, dated 31.01.2019. | It extended the period for submitting the declaration in FORM GST TRAN-I for class of person who could not submit the declaration on common portal due to technical difficulties and whose cases recommended by GST Council till 31.03.2019. |  |
|  |  | Order No. 01/2020-GST, dated 07.02.2020 | It extended the time limit for submitting the declaration in FORM GST TRAN-1 under Rule 117(1A) of the CGST Rules for class of registered persons who could not submit the said declaration by due date on account of technical difficulties on the common portal and whose cases have been recommended by the Council. |  |
|  |  | Order No. 4/2018-GST, dated 17.09.2018 | It extended the period for submitting the declaration in FORM GST TRAN-1 for class of person who could not submit the declaration on common portal due to technical difficulties and whose cases recommended by GST Council till 31.01.2019. | Superceded vide Order No. 01/2019-GST, dated 31.01.2019. |
|  | (Filing of GST REG-26) | Order No. 06/2017-GST, dated 28.10.2017 | It extended the period for submit electronically the application in FORM GST REG-26 till 31.12.2017. | Issued under Rule 24(2)(b) of the CGST Rules, 2017. |
|  | Constitution of Standing Committee for purpose of Consumer Welfare fund | Order No. 3/2018-Central Tax, dated 16.08.2018 | Constitution of Standing Committee under Sub-rule (4) of Rule 97 of CGST Rules, 2017. | Issued under Rule 97(4) of the CGSG Rules, 2017 |
|  | Document Identification Number | Circular No. 122/41/2019-GST, dated 05.11.2019 | Generation and Quoting of Document Identification Number (DIN) on any communication issued by the officers of the Central Board of Indirect Taxes and Customs (CBIC) to taxpayers and other concerned persons-Reg. |  |
|  |  | Circular No. 128/47/2019-GST, dated 23.12.2019 | Generation and Quoting of Document Identification Number (DIN) on any communication issued by the officers of the Central Board of Indirect Taxes and Customs (CBIC) to taxpayers and other concerned persons-Reg. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 123/42/2019-GST, dated 11.11.2019 | Restriction in availment of Input Tax Credit in terms of Sub-Rule (4) of Rule 36 of CGST Rules, 2017. | It should be read with Circular No. 142/12/2020GST, dated 09.10.2020. |
|  |  | Circular No. 142/12/2020-GST, dated 09.10.2020. | Clarification relating to application of sub-rule (4) of rule 36 of the CGST Rules, 2017 for the months of February, 2020 to August, 2020. |  |
|  |  | Circular No. 143/1/2020-GST, dated 10.11.2020. | It deals with Quarterly Return Monthly Payment Scheme and explains legislative changes and procedures. | QRMP Scheme. |
|  |  | Circular No. 160/16/2021-GST, dated 20.09.2021. | Clarification in respect of Certain GST Related Issues-Reg. |  |
|  |  | Circular No. 170/02/2022-GST, dated 6.7.2022 | Mandatory furnishing of correct and proper information of inter-State supplies and amount of ineligible/blocked Input Tax Credit and reversal thereof in return in FORM GSTR-3B and statement in FORM GSTR-1. |  |
|  |  | Circular No. 197/09/2023-GST, dated 17.07.2023 | Clarification on Refund Related Issue |  |
|  |  | Circular No. 202/14/2023-GST, dated 27.10.2023 | Clarification relating to export of services-sub-clause(iv) of the Section 2 (6) of the IGST Act 2017-reg. | Also relevant for section 2(6) of the IGST Act, 2017. |
|  |  | Circular No. 203/15/2023-GST, dated 27.10.2023 | Clarification regarding determination of place of supply in various cases-reg. | Also relevant for section 12 and 13 of the IGST Act, 2017. |
|  |  | Circular No. 204/16/2023-GST, dated 27.10.2023 | Clarification on issues pertaining to taxability of personal guarantee and corporate guarantee in GST-reg. |  |
|  |  | Circular No. 207/1/2024-GST, dated 26.06.2024 | Reduction of Government Litigation- Fixing Monetary Limits for filing appeals or applications by the Department before GSTAT, High Courts and Supreme Court-Reg |  |
|  |  | Circular No. 208/2/2024-GST, dated 26.06.2024 | Clarifications on Various issues pertaining to Special Procedure for the manufacturers of the Specified Commodities as per notification No. 04/2024-Central Tax, dated 05.01.2024-Reg. |  |
|  |  | Circular No. 209/3/2024-GST, dated 26.06.2024 | Clarification on the provisions of clause (ca) of Section 10(1) of the Integrated Goods and Service Tax Act, 2017 relating to place of supply of goods to unregistered persons-Reg. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 210/4/2024-GST, dated 26.06.2024 | Clarification on Valuation of Supply of Import of Services by a related person where recipient is eligible to full Input Tax Credit-Reg |  |
|  |  | Circular No. 211/5/2024-GST, dated 26.06.2024 | Clarification on time limit under section 16(4) of the CGST Act, 2017 in respect of RCM supplies received from unregistered persons-Reg. |  |
|  |  | Circular No. 212/06/2024-GST, dated 26.06.2024 | Clarification on Mechanism for providing evidence of compliance of conditions of Section 15(3) (b) (ii) of the CGST Act 2017 by the suppliers |  |
|  |  | Circular No. 213/07/2024, dated 26.06.2024 | Clarification on the taxability of ESOP/ESPP/RSU provided by a company to its employees through its overseas holding company-Reg |  |
|  |  | Circular No. 214/08/2024-GST, dated 26.06.2024. | Clarification on the requirement of reversal of input tax credit in respect of the portion of the premium for life insurance policies which is not included in taxable value |  |
|  |  | Circular No. 215/09/2024-GST, dated 26.06.2024. | Clarification on taxability of wreck and salvage values in motor insurance claims. |  |
|  |  | Circular No. 216/10/2024-GST, dated 26.06.2024. | Clarification in respect of GST liability and input tax credit (ITC) availability in cases involving Warranty/ Extended Warranty, in furtherance to Circular No. 195/07/2023-GST dated 17.07.2023. |  |
|  |  | Circular No. 217/11/2024-GST, dated 26.06.2024. | Entitlement of ITC by the insurance companies on the expenses incurred for repair of motor vehicles in case of reimbursement mode of insurance claim settlement. |  |
|  |  | Circular No. 218/12/2024-GST, dated 26.06.2024. | Clarification regarding taxability of the transaction of providing loan by an overseas affiliate to its Indian affiliate or by a person to a related person. |  |
|  |  | Circular No. 219/13/2024-GST, dated 26.06.2024. | Clarification on availability of input tax credit on ducts and manholes used in network of optical fiber cables (OFCs) in terms of section 17(5) of the CGST Act, 2017. |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circula/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | Circular No. 220/14/2024-GST, dated 26.06.2024. | Clarification on place of supply applicable for custodial services provided by banks to Foreign Portfolio Investors |  |
|  |  | Circular No. 221/15/2024-GST, dated 26.06.2024. | Time of supply on Annuity Payments under HAM Projects |  |
|  |  | Circular No. 222/16/2024-GST, dated 26.06.2024. | Time of supply in respect of supply of allotment of Spectrum to Telecom companies in cases where an option is given to the Telecom Companies for payment of licence fee and Spectrum usage charges in instalments in addition to an option of upfront payment. |  |
|  |  | Circular No. 223/17/2024-GST, dated 10.07.2024. | Amendment in circular no. 1/1//2017 in respect of Proper officer for provisions relating to Registration and Composition levy under the Central Goods and Services Tax Act, 2017 or the rules made thereunder. |  |
|  |  | Circular No. 224/18/2024-GST, dated 11.07.2024. | Guidelines for recovery of outstanding dues, in cases wherein first appeal has been disposed of, till Appellate Tribunal comes into operation. |  |
|  |  | Circular No. 226/20/2024-GST, dated 11.07.2024. | Mechanism for refund of additional Integrated Tax (IGST) paid on account of upward revision in price of the goods subsequent to export. |  |
|  |  | Circular No. 227/21/2024-GST, dated 11.07.2024. | Processing of refund applications filed by Canteen Stores Department (CSD). |  |
|  |  | Circular No. 228/22/2024-GST, dated 15.07.2024. | Clarifications regarding applicability of GST on certain services -reg. |  |
|  |  | Circular No. 229/23/2024-GST, dated 15.07.2024. | Clarification regarding GST rates \& classification (goods) based on the recommendations of the GST Council in its 53rd meeting held on 22nd June, 2024, at New Delhi -reg. |  |
| Section 168A <br> (w.e.f. <br> 31.03.2020) | Power of Government to extend time limit in special circumstances | Notification No. 35/2020-Central Tax, dated 03.04.2020 (w.e.f. 20.03.2020) as amended vide notification No. 40/2020-Central Tax, dated | It extended due date of compliance (with some exception as specified in the notification) which falls during the period from "20.03.2020 to $29.11 .2020$ " till 30.11 .2020 and |  |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 111 of 127

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  | 05.05.2020; No. 47/2020-Central Tax, dated 09.06.2020 (w.e.f. 31.05.2020); No. 55/2020-Central Tax, dated 27.06.2020; No. 65/2020-Central Tax, dated 01.9.2020; No. 66/2020-Central Tax, dated 21.09.2020; No. 91/2020-Central Tax, dated 14.12.2020 (w.e.f. 01.12.2020); No. 34/2021-Central Tax, dated 29.08.2021; No. 09/2023-Central Tax, dated 31.03.2023; and No. 56/2023-Central Tax, dated 28.12.2023. | to extend validity of e-way bills. <br> It also extended the validity of e-way bill generated on or before 24.03.2020 (whose validity has expired on or after 20.03.2020) till 30.06.2020. <br> It also provided onetime extension for the time limit provided under section 31(7) of the CGST Act, 2017 till 31.10.2020. <br> It also extended due dates for compliances and action in respect of anti-profiteering measures under GST till 31.03.2021. <br> It also extended the time limit for making application for revocation of cancellation of registration in term of section 30(1) where a registration was cancelled under clauses (b) and (c) of section 29(2) and time limit for making an application of revocation of cancellation of Registration under section 30(1) fell during the period from 01.03.2020 to 31.08.2021 (Ref: notification No. 34/2021-Central Tax, dated 29.08.2021). <br> It extended the time limit specified under Section 73(10 for issuance of Order under Section 73(9) for the year 2017-18, 2018-19 and 2019-20. |  |
|  |  | Notification No. 46/2020-Central Tax, dated 09.06.2020 (w.e.f. 20.03.2020) as amended vide notification No. 56/2020-Central Tax, dated 27.06.2020. | It extended the time limit for passing order under section 54 (7) of the CGST Act, 2017 where the time limit for passing such orders falls between 20.03.2020 to 30.08.2020. The date for issuance of order has been extended up to 15 days from the receipt of reply to the notice or the 31.08.2020 whichever is later. |  |
|  |  | Notification No. 14/2021-Central Tax, dated 01.05.2021 (w.e.f. 15.04.2021) as amended vide notification No. 24/2021-Central Tax, dated 01.06.2021 (w.e.f. 30.05.2021); No. 34/2021-Central Tax, dated 29.08.2021; No. 13/2022-Central Tax, dated 05.07.2022; and No. 56/2023-Central Tax, dated 28.12.2023. | It extended due date of compliance (with some exception as specified in the notification) which falls during the period from "15.04.2021 to 30.05.2021" till 30.06.2021. <br> It extended the time limit for passing order under section 54 (7) of the CGST Act, 2017 where the time limit for passing such orders falls between 15.04.2021 to 29.06.2021. The date for issuance of order has been extended up to 15 days from the receipt of reply to the notice or the | r/w section 20 of the IGST <br> Act, 2012 and Section 21 of <br> UTGST Act, 2017. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | 30.06.2021 whichever is later. <br> It also extended the time limit for making application for revocation of cancellation of registration in term of section 30(1) where a registration was cancelled under clauses (b) and (c) of section 29(2) and time limit for making an application of revocation of cancellation of Registration under section 30(1) fell during the period from 01.03.2020 to 31.08.2021 (Ref: notification No. 34/2021-Central Tax, dated 29.08.2021). <br> It excluded the period from 1.03.2020 to 28.02.2022 for the purpose of limitation under section 73(10) for issuance of order for recovery of tax; under 73(10) for issuance of order for recovery of erroneous refund; and for filing of refund application under section 54 and 55 of CGST Act, 2017. |  |
|  |  | Circular No. 136/06/2020-GST, dated 03.04.2020 | Clarification in respect of various measures announced by the Government forproviding relief to the taxpayers in view of spread of Novel Corona Virus (COVID-19). |  |
|  |  | Circular No. 141/11/2020-GST, dated 24.06.2020 | Clarification in respect of various measures announced by the Government forproviding relief to the taxpayers in view of spread of Novel Corona Virus (COVID-19). |  |
|  |  | Circular No. 137/07/2020-GST, dated 13.04.2020 | Clarification in respect of certain challenges faced by the registered persons inimplementation of provisions of GST Laws. |  |
|  |  | Circular No. 138/08/2020-GST, dated 06.05.2020 | Clarification in respect of certain challenges faced by the registered persons inimplementation of provisions of GST Laws. |  |
|  |  | Circular No. 157/13/2021-GST, dated 20.07.2021 | Clarification regarding extension of limitation under GST Law in terms of Hon'ble Supreme Court's Order dated 27.04.2021 |  |
| Section 169 | Service of notice in certain circumstances |  |  |  |
| Section 170 | Rounding off of tax, etc. |  |  |  |
| Section 171 | Anti-profiteering | Rule 122 to Rule 137 of the CGST Rules, 2017. |  |  |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  | measure |  |  |  |
|  |  | Notification No. 23/2022-Central Tax, dated 23.11.2022 (w.e.f. 01.12.2022). | It empowered Competition Commission of India to examine whether ITC availed by the Registered Person or the reduction of tax rate resulted in commensurate reduction in the price of the goods or services or both or vice versa. |  |
| Section 172 | Removal of difficulties | The CGST (Removal of Difficulties) Order No. 01/2017-Central Tax, dated 13.10.2017 | It was issued to remove the difficulties in respect of provision of section 10 of the CGST Act, 2017. | Superseded CGST <br> (Removal of Difficulties) Order No. 01/2019-Central Tax, dated 01.02.2019. |
|  |  | The CGST (Removal of Difficulties) Order No. 1/2018-Central Tax, dated 11.12.2018 as amended vide the CGST (Third Removal of Difficulties) Order No. 3/2018-Central Tax, dated 31.12.2018. | It was issued to remove the difficulties in respect of provision of section 44 of the CGST Act, 2017 so as to extend the date of filing of Annual Return in FORM GSTR -9, 9A and 9C for the year 2017-18 till 31.06.2019. | It pertains to section 44 of the CGST Act, 2017. |
|  |  | The CGST (Removal of Difficulties) No. 2/2018Central Tax, dated 31.12.2018. | It inserts a proviso in the sub-section (4) of Section 16 of the CGST Act, 2017, thereby allowing input credit in respect of any invoice or invoice relating to such debit note for supply of goods or services or both made during the financial year 2017-18, the details of which have been uploaded by the supplier under sub-section (1) of section 37 till the due date for furnishing the details under subsection (1) of said section for the month of March, 2019. | It pertains to section 16 of the CGST Act, 2017. |
|  |  | The CGST (Removal of Difficulties) Order No. 4/2018-Central Tax, dated 31.12.2018 as amended vide The CGST (Second Removal of Difficulties) Order No. 02/2019-Central Tax, dated 01.02.2019. | It inserted an explanation to the Sub-section (4) of Section 52 of the CGST Act, 2017 providing that due date for furnishing the statement under this sub-section for the months of October, November and December, 2018 shall be the 31st January, 2019. | It pertains to section 52 of the CGST Act, 2017. |
|  |  | The CGST (Removal of Difficulties) Order No. 01/2019-Central Tax, dated 01.02.2019. | It was issued to remove the difficulties in respect of provision of section 10 of the CGST Act, 2017. It also superceded the CGST (Removal of Difficulties) Order No. 01/2017-Central Tax, dated 13.10.2017. | It pertains to section 10 of the CGST Act, 2017. |
|  |  | The CGST (Removal of Difficulty) Order No. 3/2019-Central Tax, dated 08.03.2019 | It clarifies that the provisions of clause (c) of Section 31(3) of the CGST Act, 2017 shall apply to a person paying tax under Notification No. 2/2019-Central Tax (Rate), dated | It pertains to section 31(3) of the CGST Act, 2017. |

| Chapter/ <br> Section Number | Heading | Notification No. and date/ <br> Circular/Instruction | Subject in brief | Present status of notification/Remarks |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | 07.03.2019. |  |
|  |  | The CGST (Fifth Removal of Difficulties) Order No. 5/2019-GST, dated 23.04.2019 | It seeks to extend the time limit for filing an application for revocation of cancellation of registration for specified taxpayers. | It pertains to Section 30 of the CGST Act, 2017. |
|  |  | The CGST (Removal of Difficulties) Order No. 6/2019-Central Tax, dated 28.06.2019. | It allows filing of Annual Return for the period from 01.07.2017 to 31.03.2018 till 31.08.2019 for all registered persons other than Input Service Distributor, a person paying tax under section 51 or section 52, a casual taxable person and a non-resident taxable person. | It pertains to section 44 of the CGST Act, 2017. |
| Section 173 | Amendment of Act 32 of 1994 |  |  |  |
| Section 174 | Repeal and saving |  |  |  |
| SCHEDULE I - Activities to be treated as supply even if made without consideration. |  | Circular No. 57/31/2018-GST, dated 04.09.2018 | Scope of Principal-Agent Relationship in the context of Schedule I of the CGST Act-Reg. |  |
|  |  | Circular No. 73/47/2018-GST, dated 05.11.2018. | Scope of Principal and Agent Relationship Under Schedule I of the CGST Act, 2017 in the context of Del-Credere-Agent-Reg. |  |
|  |  | Circular No. 210/4/2024-GST, dated 26.06.2024 | Clarification on Valuation of Supply of Import of Services by a related person where recipient is eligible to full Input Tax Credit-Reg |  |
| SCHEDULE II - Activities to be treated as supply of goods or supply of services |  |  |  |  |
| SCHEDULE III - Activities or transactions which shall be treated neither as a supply or goods nor as supply of services. |  |  |  |  |
|  |  | Circular No. 140/10/2020-GST, dated 10.06.2020 | Clarification in respect of levy of GST on Director's Remuneration. |  |

# Details of Notification/Circular/Order_Superceded/Rescinded 

Table-I
![img-3.jpeg](img-3.jpeg.png)

# Table-II 

| Central Tax Non-Rate Notifications (Superceded or Rescinded) |  |  |
| :--: | :--: | :--: |
| Notification No and date (Rescinded or Superceded) | Subject | Rescinding / Superceding Notification No. and date |
| (1) | (2) | (3) |
| Notification No. 4/2017-Central Tax, dated 19.06.2017. | It notified www.gst.gov.in as the common Goods and Service Tax Electronic Portal for facilitating registration, payment of tax, furnishing of returns, computation and settlement of Integrated tax and electronic way bill. | Superceded vide notification No. 9/2018-Central Tax, dated 23.01.2018. |
| Notification No. 8/2017-Central Tax, dated 27.06.2017 as amended vide notification No. 46/2017-Central Tax, dated 13.10.2017; No. 1/2018Central Tax, dated 1.1.2018; and No. 05/2019Central Tax, dated 29.01.2019. | It notifies turnover limit for the purpose of composition levy scheme. It also excludes manufacturers of certain specified goods from the ambit of Composition Scheme. | Superceded vide notification No. 14/2019-Central Tax, dated 07.03.2019. |
| Notification No. 16/2017-Central Tax, dated 01.07.2017 | It specified conditions and safeguards for furnishing a LUT in place of bond by registered person who intends to supply goods or services for export without payment of Integrated Tax. | Superceded vide notification No. 37/2017-Central Tax, dated 04.10.2017. |
| Notification No. 18/2017-Central Tax, dated 8.08.2017. | It extended the time limit for furnishing the details of the FORM GSTR-1 returns for the month of July, 2017 and August, 2017. | Superceded videnotification No. 29/2017-Central Tax, dated 08.08.2017 as well as vide notification No. 44/2018-Central Tax, dated 10.09.2018). |
| Notification No. 19/2017-Central Tax, dated 08.08.2017 | It extended the time limit for furnishing the details in FORM GSTR-2 for the months of July, 2017 and August, 2017. | Superceded vide notification No. 29/2017-Central Tax, dated 05.09.2017. |
| Notification No. 20/2017-Central Tax, dated 08.08.2017 | It extended due date for furnishing the monthly return GSTR-3 for the month of July and August, 2017. | Superceded vide notification No. 29/2017-Central Tax, dated05.09.2017. |
| Notification No. 25/2017-Central Tax, dated 28.08.2017 | It extended time limit for furnishing the monthly return by person supplying Online Information and data base access or retrieval services from a place outside India to a nontaxable person online recipient | Superceded vide notification No. 42/2017-Central Tax, dated 13.10.2017. |

| Notification 28.08.2017. | No. 26/2017-Central Tax, dated | It extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July and August, 2017. | Superceded vide notification No. 31/2017-Central Tax, dated 11.09.2017. |
| :--: | :--: | :--: | :--: |
| Notification 01.09.2017 | No. 28/2017-Central Tax, dated | It waived the late fee payable for all registered persons for failure to furnish the return in FORM GSTR-3B for the month of July, 2017 by due date. |  |
| Notification 5.09.2017. | No. 29/2017-Central Tax, dated | It superseded notification Nos. 18/2017-Central Tax, dated 08.08.2017, 19/2017-Central Tax, dated 08.08.2017 and 20/2017-Central Tax, dated 08.08.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 returns for the month of July, 2017 and August, 2017. |  |
| Notification 11.09.2017 as amended vide notification no. 54/2017-Central Tax, 30.10.2017. | No. 30/2017-Central Tax, dated | It superseded notification No. 29/2017-Central Tax, dated 05.09.2017 and it extended the time limit for furnishing the FORM GSTR-1, 2 and 3 Returns for the month of July, 2017 for specified class of taxable/ registered person. |  |
| Notification 11.09.2017 | No. 31/2017-Central Tax, dated | It superseded notification No. 26/2017-Central Tax, dated 28.08.2017 and further extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July and August, 2017 |  |
| Notification 38/2017-Central Tax, dated 13.10.2017 | No. 32/2017-Central Tax, dated | It specifies the casual taxable person, making taxable supplies of handicraft goods subject to specified turnover and conditions, as category of person exempted from obtaining registration under the CGST Act, 2017 |  |
| Notification 33/2017-Central Tax, dated | No. 33/2017-Central Tax, dated | It brought into effect provision of the Section 51 (1) of the CGST Act, 2017 with regard to persons specified in clause (a), (b) and (d) with effect from 18.09.2017. |  |
| Notification 13.10.2017 | No. 40/2017-Central Tax, dated | It notified the registered person having aggregate turnover less than Rs. 1.5 crores in previous financial year or the registered person who turnover in current financial year is likely to be less than 1.5 crore but did not opt for composition scheme, as the class of person to pay central tax on outward supply of goods at the time of supply specified in 12(2) (a) of CGST Act, 2017 and to furnish the details and returns as per chapter IX of CGST Act, 2017. |  |
| Notification 13.10.2017 |  |  |  |

Compiled by the GSTINDIAPATHWAY.ORG Team
Superceded vide notification No. 31/2017-Central Tax, dated 11.09.2017.

Superceded vide notification No. 76/2018-Central Tax, dated 31.12.2018.

Superceded vide notification No. 30/2017-Central Tax, dated 05.09.2017.

Superceded vide notification No. 58/2017-Central Tax, dated 15.11.2017.

Superceded vide notification No. 43/2017-Central Tax, dated 13.10.2017.

Superceded vide notification No. 56/2018-Central Tax, dated 23.10.2018.

Superceded vide notification No. 50/2018-Central Tax, dated 15.09.2018]

Superceded vide notification No. 66/2016-Central Tax, dated 15.11.2017).

| Notification 13.10.2017. | No. 42/2017-Central Tax, dated | It superceded the notification No. 25/2017-Central Tax, dated 28.08.2017 and further extended the time limit for filing FORM GSTR-5A return by person supplying Online Information and data base access or retrieval services from a place outside India to a non-taxable person online recipient for the month of July, august and September, 2017. |
| :--: | :--: | :--: |
| Notification No. 43/2017-Central Tax, dated 13.10.2017. |  | It superceded notification No. 31/2017-Central Tax, dated 11.09.2017 and extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July, August and September, 2017 till 15.11.2017. |
| Notification No. 50/2017-Central Tax, dated 24.10.2017. |  | It waived the amount of late fee payable by any registered person for failure to furnish return in FORM GSTR-3B for the month of August and September, 2017 by due date. |
| Notification No. 53/2017-Central Tax, dated 28.10.2017 as amended vide notification No. 63/2017-Central tax. Dated 15.11.2017. |  | It extended the time limit for making ITC-04 declaration in respect of goods dispatched to a job worker or received from job-worker or sent from one job worker to another |
| Notification No. 57/2017-Central Tax, dated 15.11.2017 |  | It prescribes special procedure for registered persons having aggregate turnover of up to Rs. 1.5 crores in the preceding FY or Current FY for furnishing the details of outward supply of goods or services or both in FORM GSTR-I and lays down due dates for furnishing details of outwards supplies for the period from July, 2017 to March, 2018. |
| Notification No. 58/2017-Central Tax, dated 15.11.2017. |  | It superseded notification No. 30/2017-Central Tax, dated 11.09.2017 and it extended the due dates for furnishing the details of outward supplies in FORM GSTR-1 for the months from July, 17 to March, 2018. |
| Notification No. 60/2017-Central Tax, dated 15.11.2017 |  | It extended the time limit for filing FORM GSTR-5 for the month of July, 17 to October, 2017 till 11.12.2017. |
| Notification No. 61/2017-Central Tax, dated 15.11.2017. |  | It superceded the notification No. 42/2017-Central Tax, dated 13.10.2017 and further extended the time limit for filing FORM GSTR-5A return by person supplying Online Information and data base access or retrieval services from |

Superceded vide notification No. 61/2017-Central Tax, dated 15.11.2017.

Superceded vide notification No. 62/2017-Central Tax, dated 15.11.2017.

Superceded (vide notification No. 76/2018-Central Tax, dated 31.12.2018)

Superceded vide notification No. 40/2018-Central Tax, dated 04.09.2018.

Superceded vide notification No. 71/2017-Central Tax, dated 29.12.2017.
Also Superceded vide notification No. 43/ 2018-Central Tax, dated 10.09.2018.

Superceded vide notification No. 72/2017-Central Tax, dated 29.12.2017. Again,Superceded videNotification No. 44/2018-Central Tax, dated 10.09.2018).

Superceded vide notification No. 68/2017-Central Tax, dated 21.12.2017).
Superceded vide notification No. 69/2017-Central Tax, dated 21.12.2017).

|  |  |  | a place outside India to a non-taxable person online recipient for the month of July, August, September, 2017 and October, 2017 till 15.12.2017. |  |
| :--: | :--: | :--: | :--: | :--: |
| Notification 15.11.2017. | No. 62/2017-Central | Tax, dated | It superseded the notification No. 43/2017-Central Tax, dated 13.10.2017 and extended time limits for filing FORM GSTR-6 Return by Input Service Distributor for the month of July, 2017 till 31.12.2017. | Superceded vide notification No. 8/2018-Central Tax, dated 23.01.2018. |
| Notification 15.11.2017 | No. 64/2017-Central | Tax, dated | It waived the amount of late fee payable by any registered person for failure to furnish return in FORM GSTR-3B for the month of October, 2017 by the due date in excess of Rs. 25/ day during the period of failure. However, wherever the tax payable is nil, then it has been waived in excess of Rs. 10/ day during the period of failure. | Superceded vide notification No. 76/2018-Central Tax, dated 31.12.2018. |
| Notification 29.12.2017. | No. 74/2017-Central | Tax, dated | It appointed 1st February, 2018 for coming into effect of the provisions of the E-way Bill Rules. | Rescinded vide notification No. 11/2018-Central Tax, dated 2.2.2018. |
| Notification 23.01.2018 | No. 6/2018-Central | Tax, dated | It waived the amount of late fee payable by any registered person for failure to furnish the details of outward supplies for any month/quarter in FORM GSTR-5A by due date under section 47 of the CGST Act, 2017 in excess of Rs. 25/for every day during the period of such failure or in excess of Rs. 10 /- every day during the period of such failure where there are no outward supplies in any month/quarter | Rescinded vide notification No. 13/2018-Central Tax, dated 23.01.2018. |
| Notification 23.01.2018. | No. 8/2018-Central | Tax, dated | It extended the time limit for furnishing the return by an ISD in the FORM GSTR-6 for the month of July, 2017 to February, 2018 to 31.03.2018. It superseded the notification No. 62/2017-Central Tax, dated 15.11.2017. | Superceded vide by notification No. 19/2018-Central Tax, dated 28.03.2018. |
| Notification 28.03.2018 | No. 17/2018-Central | Tax, dated | It notified the registered person having aggregate turnover of uptoRs. 1.5 crores in the preceding financial year or the current financial year as class of person who shall follow special procedure specified for furnishing the details of outward supply of goods or services or both. | Superceded vide notification No. 43/2018-Central Tax, dated 10.09.2018. |
| Notification 28.03.2018 | No. 18/2018-Central | Tax, dated | It specified the last date for filing of return in FORM GSTR-1 for the month of April, May, and June, 2018 by registered person having aggregate turnover of more than | Superceded vide notification No. 44/2018-Central Tax, dated 10.09.2018. |

Compiled by the GSTINDIAPATHWAY,ORG Team
Page 120 of 127
INHEX

|  |  | Rs. 1.5 crores in the preceding financial year or current financial year. |  |
| :--: | :--: | :--: | :--: |
| Notification No. 19/2018-Central Tax, dated 28.03.2018 |  | It superceded the notification No. 08/2018-Central Tax, dated 23.01.2018 and extended the time limit for furnishing FORM GSTR-6 returns for the month of July 2017 to April, 2018 till 31.05.2018 | Superceded vide notification No. 25/2018-Central Tax, dated 31.05.2018). |
| Notification No. 20/2018-Central Tax, dated 28.03.2018. |  | It extended the date of filing refund claim under section 54 by specified person (specified under section 55 such as UN agency) for refund of taxes paid on inward supplies of goods/services before the expiry of 18 months from the last date of quarter in which supply was received. |  |
| Notification No. 25/2018-Central Tax, dated 31.05.2018. |  | It superceded the notification No. 19/2018-Central Tax, dated 28.03.2018 and extended the time limit for furnishing FORM GSTR-6 returns by ISD for the month of July 2017 to June, 2018 till 31.07.2018. |  |
| Notification No. 32/2018-Central Tax, dated 10.08.2018 as amended vide notification No. 37/2018-Central Tax, dated 24.08.2018. |  | It extends the time limit for furnishing the details of outward supplies in FORM GSTR-I in case of those registered persons having aggregate turnover of more than Rs. 1.5 crores in the preceding financial year or current financial year for each of month from July. 2018 to March, 2019 till $11^{\text {th }}$ of succeeding month. |  |
| Notification No. 33/2018-Central Tax, dated 10.08.2018 as amended vide notification No. 38/2018-Central Tax, dated 24.08.2018. |  | It prescribed special procedure for registered persons having aggregate turnover of Up to Rs. 1.5 crores in the preceding FY or Current FY for furnishing the details of outward supply of goods or services or both in FORM GSTR-I and lays down due dates for furnishing details of outwards supplies for the period from July, 2018 to March, 2019. |  |
| Notification No. 40/2018-Central Tax, dated 4.9.2018 |  | It superceded the notification No. 53/2017-Central Tax, dated 28.10.2017 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to June, 2018 till 30.09.2018. | Superceded vide notification No. 43/2018-Central Tax, dated 10.09.2018. |
|  |  |  | Superceded vide notification No. 59/2018-Central Tax, dated 26.10.2018. |

| Notification 26.10.2018. | No. 59/2018-Central Tax, dated | It superceded the notification No. 40/2018-Central Tax, dated 4.09.2018 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to September, 2018 till 31.12.2018. |
| :--: | :--: | :--: |
| Notification 29.11.2018 as amended vide | Tax, dated notification | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person for the months from Oct, 2018 to December, 2018 till 28th of February, 2019. |
| Notification No. 78/2018-Central | Tax, dated | It superceded the notification No. 59/2018-Central Tax, dated 26.10.2018 and extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to December, 2018 till 31.03.2019. |
| Notification 08.02.2019. | No. 08/2019-Central Tax, dated | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person required to Deduct tax at source under Section 51 of the CGST Act, 2017 for the month of January, 2019 till 28th of February, 2019. |
| Notification 28.03.2018 | No. 15/2019-Central Tax, dated | It extended the time limit for making a declaration in FORM GST ITC-04 in respect of goods dispatched to a job worker or received from a job worker or sent from one job worker to another during the period from July, 2017 to March, 2019 till 30.06.2019. |
| Notification 10.04.2019 | No. 18/2019-Central Tax, dated | It extended the time limit for furnishing FORM GSTR-7 Return by a registered person required to Deduct tax at source under Section 51 of the CGST Act, 2017 for the month of March, 2019 till 12th of April, 2019. |
| Notification No. 72/2019-Central Tax, dated 13.12.2019 | Tax, dated | It provided issuance of invoice with QR Code by certain taxpayers having turnover more than Rs. 500 Crores in case of B to C transactions. |
| Notification No. 15/2020-Central Tax, dated 23.03.2020. |  | It extended the time limit for furnishing of the annual return specified under section 44 of the said Act read with rule 80 of the said rules, electronically through the common portal, for the |

Superceded vide notification No. 78/2018-Central Tax, dated 31.12.2018.

Superceded vide notification No. 26/2019-Central Tax, dated 28.06.2019.

Superceded vide notification No. 15/2019-Central Tax, dated 28.06.2019.

Superceded vide notification No. 26/2019-Central Tax, dated 28.06.2019.

Superceded vide notification No. 14/2020-Central Tax, dated 21.03.2020.

Superceded vide notification No. 41/2020-Central Tax, dated 05.05.2020

|  | financial year 2018-2019 till 30.06.2020. |  |
| :--: | :--: | :--: |
| Notification No. 74/2020-Central Tax, dated 15.10.2020 | It prescribed the due dates for furnishing FORM GSTR-1 returns for the quarter October, 2020 to December, 2020 and January, 2021 to March, 2021 for registered persons having aggregate Turnover of Rs. 1.5 crores in the preceding financial year or the current financial year. | Superceded vide notification No. 83/2020-Central Tax, dated 15.10.2020 (w.e.f. 01.01.2021) |
| Notification No. 75/2020-Central Tax, dated 15.10.2020. | It prescribed the due dates for furnishing FORM GSTR-1 returns for each of the month from October, 2020 to March, 2021 for such class of registered persons having aggregate Turnover of more than Rs. 1.5 crores in the preceding financial year or the current financial year. | Superceded vide notification No. 83/2020-Central Tax, dated 15.10.2020 (w.e.f. 01.01.2021). |
| Notification No. 76/2020-Central Tax, dated 15.10.2020. | It provides the due dates for fling the return in FORM GSTR-3B for each of the month fromOct, 2020 to March, 2021. | Rescinded vide notification No. 86/2020-Central Tax, dated 10.11.2020 (read with corrigendum dated 13.11.2020). |
| Notification No. 17/2020-Central Tax, dated 23.03.2020 (w.e.f. 01.04.2020). | It specified classes of person who shall be exempted from AADHAR Authentication provided in sub-section (6D) of Section 25 of the CGST Act, 2017. | Superceded vide notification No. 03/2021-Central Tax, dated 23.02.2021. |
| Notification No. 89/2020-Central Tax, dated 29.11.2020, as amended by notification No. 06/2021-Central Tax, dated 30.03.2021. | It grants waiver of penalty payable by any registered person under section 125 for non-compliance of provision of notification No. 14/2020-Central Tax, dated 21.03.2020 between the period from 01.12.2020 to 30.06.2021 subject to compliance from 1.7.2021. | Superceded vide notification No. 28/2021-Central Tax, dated 30.06.2021 |
| Notification S. O. 3009 (E), dated 21.08.2019 | It notified the creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) with effect from 21.08.2019. | Superceded vide notification No. SO 4073 (E), dated 14.09.2023. |
| Notification S.O. 4332 (E), dated 29.11.2019. | It notified creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) in Rajasthan, Mizoram and Karnataka w.e.f. 29.11.2019. | Superceded vide notification No. SO 4073 (E), dated 14.09.2023. |
| Notification No. 27/2022-Central Tax, dated 26.12.2022 as amended vide notification No. 05/2023-Central Tax, dated 31.03.2023 (with retrospective effect from 26.12.2022); No. 31/2023-Central Tax, dated 31.07.2023; and No. 54/2023-Central Tax, dated 17.11.2023. | It specifies that provision of sub-rule (4A) of rule 8 shall not apply in all the states and Union Territory except the States of Andhra Pradesh, Gujarat and Puducherry. | Rescinded vide notification No. 13/2024-Central Tax, dated 10.07.2024 (w.e.f. 10.07.2024) |
| Notification No. 45/2023-Central Tax, dated 06.09.2023 | It notifies the CGST (Third Amendment) Rules, 2023 ( date to be notified). | Superceded vide notification No. 51/2023-Central Tax, dated 29.09.2023. |
| Notification No. 30/2023-Central Tax, dated 31.07.2023 as amended vide notification No. 47/2023-Central Tax, dated 25.09.2023 (w.e.f. 31.07.2023) | It notified special procedure to be followed with effect from 01.01.2024 by a registered person engaged in manufacturing of the specified goods (Pan masala and tobacco-based goods) falling | Rescinded vide notification No. 03/2024-Central Tax, dated 05.01.024. |

Compiled by the GSTINDIAPATHWAY.ORG Team

|  | under Chapter 21(210690 20) and 24 of Customs Tariff Act, 1975. <br> It also prescribed the forms i.e. SRM-I to SRM-IV. |  |
| :--: | :--: | :--: |
| Notification S. O. 4073 (E), dated 14.09.2023 | It notified the creation of State Benches of the Goods and Services Tax Appellate Tribunal (GSTAT) with effect from 14.09.2023. | Superceded vide notification No. SO 3048 (E), dated 31.07.2024. |
| Notification No. SO 1 (E), dated 29.12.2023 | It constituted the Principal Bench of the Goods and Services Tax Appellate Tribunal (GSTAT) at new Delhi with effect from 29.12.2023. | Superceded vide notification No. SO 3048 (E), dated 31.07.2024. |

# TABLE-III 

## The CGST (Removal of Difficulties) Order Issued under Section 172 of the CGST Act, 2017 (Superceded/Rescinded)

| Order No and date (Rescinded or Superceded) | Subject | Rescinding / Superceding Order No. and date |
| :--: | :-- | :-- |
| (1) | (2) | (3) |

The CGST (Removal of Difficulties) Order No. 01/2017-Central Tax, dated 13.10.2017

It was issued to remove the difficulties in respect of provision of section 10 of the CGST Act, 2017.

## Superceded vide CGST (Removal of Difficulties) Order No. 01/2019-Central Tax, dated 01.02.2019.

## TABLE-IV

| Central Tax Circulars (Rescinded /Superceded) |  |  |
| :--: | :--: | :--: |
| Circular No and date (Rescinded or Superceded) | Subject | Rescinding / Superceding Circular No. and date |
| (1) | (2) | (3) |
| Circular No. 2/2/2017-GST, dated 04.07.2017 | Issues related to furnishing of Bond/Letter of Undertaking for Exports | Rescinded vide Circular No. 8/8/2017-GST, dated 04.10.2017. |
| Circular No. 4/4/2017-GST, dated 07.07.2017 | Issues related to Bond/Letter of Undertaking for Exports without payment of integrated tax. | Rescinded vide circular No. 8/8/2017-GST, dated 04.10.2017. |
| Circular No. 5/5/2017-GST, dated 11.08.2017 | Clarification on Issues related to furnishing of Bond/Letter of Undertaking for Exports | Rescinded vide circular No. 8/8/2017-GST, dated 04.10.2017. |
| Circular No. 28/02/2018-GST, dated 08.01.2018 (read with corrigendum) | Clarification regarding GST on college Hostel Mess Fees-Reg. | Withdrawn vide Circular No. 50/24/2018-GST, dated 31.07.2018. |
| Circular No. 105/24/2019-GST, dated 28.06.2019 | Clarification on various doubts related to treatment of secondary or post-sales discounts under GST-Reg. | Withdrawn vide Circular No. 112/31/2019-GST, dated 03.10.2019 |
| Circular No. 107/26/2019-GST, dated 18.07.2019 | Clarifications on doubts related to supply of Information Technology enabled Services (ITes Services)-Reg. | Withdrawn vide Circular No. 127/46/2019-GST, dated 04.12.2019. |
| Circular No. 17/17/2017-GST, dated 15.11.2017 | Manual filing and processing of refund claim in respect of Zero-rated Supplies. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |
| Circular No. 24/24/2017-GST, dated 21.12.2017 | Manual filing and processing of Refund claims on account of inverted duty structure, deemed exports and excess balance in | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |

Compiled by the GSTINDIAPATHWAY.ORG Team
Page 125 of 127

|  | electronic Cash Ledger-Reg. |  |  |  |
| :--: | :--: | :--: | :--: | :--: |
| Circular No. 37/11/2018-GST, dated 15.03.2018 | Clarifications on exports related refund issues | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |  |  |
| Circular No. 45/19/2018-GST, dated 30.05.2018 (including corrigendum dated 18.07.2018) | Clarifications on refund related issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |  |  |
| Circular No. 59/33/2018-GST, dated 04.09.2018 | Clarification on refund related issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |  |  |
| Circular No. 70/44/2018-GST, dated 26.10.2018 | Clarification on certain issues related to refund. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |  |  |
| Circular No. 79/53/2018-GST, dated 31.12.2018 | Clarification on refund related issues. | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019. |  |  |
| Circular No. 94/13/2019-GST, dated 28.03.2019 | Clarifications on Refund Related Issues under GST | Superceded vide Circular No. 125/44/2019-GST, dated 18.11.2019 |  |  |

# Order Issued under Section 168 of the CGST Act, 2017 (Superceded/ Rescinded) 

| Circular No and date (Rescinded or Superceded) | Subject | Rescinding/ Superceding Circular No. and date |
| :--: | :--: | :--: |
| (1) | (2) | (3) |
| Order No. 02/2017-GST, dated 18.09.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded vide Order No. 08/2017-GST, dated 28.10.2017. |
| Order No. 03/2017-GST, dated 21.09.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded vide Order No. 03/2017-GST, dated 21.09.2017. |
| Order No. 04/2017-GST, dated 29.09.2017 | It extended the period for intimation of details of stock held on the date previous to the date of exercise of option to pay tax under Section 10 in FORM GST CMP-03 till 31.10.2017. | Superceded vide Order No. 05/2017-GST, dated 28.10.2017. |
| Order No. 05/2017-GST, dated 28.10.2017 | It extended the period for intimation of details of stock held on the date previous to the date of exercise of option to pay tax under Section 10 in FORM GST CMP-03 till 31.11.2017. | Superceded vide Order No. 05/2017-GST, dated 28.10.2017. |
| Order No. 07/2017-GST, dated 28.10.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 30.11.2017. | Superceded vide Order No. 09/2017-GST, dated 15.11.2017. |
| Order No. 08/2017-GST, dated 28.10.2017 | It extended the period for submitting the declaration in FORM GST TRAN-1 till 31.10.2017. | Superceded vide Order No. 10/2017-GST, dated 15.11.2017. |
| Order No. 02/2018-Central Tax, dated 31.03.2018 | Incidence of GST on Providing Catering Services in Train | Withdrawn vide Circular No. 50/24/2018-GST, dated 31.07.2018. |

Order No. 4/2018-GST, dated 17.09.2018

It extended the period for submitting the declaration in FORM GST TRAN-1 for class of person who could not submit the declaration on common portal due to technical difficulties and whose cases recommended by GST Council till 31.01.2019.

Superceded vide Order No. 01/2019-GST, dated 31.01.2019.

# Caution Note: 

- Though all precautions have been taken to make this document error free, still some errors might have crept into this document. Therefore, users of this document are requested to exercise due caution.
- This document has been prepared using the information available on CBIC website.
- Use of this document is restricted for non-commercial purposes only.

